const E=!0,s=!1;export{s as L,E as V};
