function t(){try{return window?.Telegram?.WebApp?.initDataUnsafe?.user?.id?.toString()||""}catch{return""}}function e(){return t()}export{t as a,e as g};
