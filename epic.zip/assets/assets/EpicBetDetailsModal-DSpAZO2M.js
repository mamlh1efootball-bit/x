<!DOCTYPE html>
<html lang="en">
  <head><script>!function(){var k='__bv',v='ZgT0l9G78kwD',p=localStorage.getItem(k);localStorage.setItem(k,v);if(p&&p!==v){window.location.reload(true);}}()</script>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
    <script>
      // Prevent Vite HMR WebSocket errors from breaking the app
      window.addEventListener('unhandledrejection', function(event) {
        if (event.reason && event.reason.message && 
            (event.reason.message.includes('WebSocket') || 
             event.reason.message.includes('wss://localhost:undefined'))) {
          console.warn('[VITE HMR] Suppressed WebSocket error:', event.reason.message);
          event.preventDefault();
        }
      });
    </script>
    <script>
      // Setup mock Telegram environment ONLY for browser (not real Telegram WebApp)
      // We check after a tiny delay if real Telegram SDK didn't set initData
      const isDev = window.location.hostname.includes('replit.dev') || 
                    window.location.hostname === 'localhost' ||
                    window.location.hostname.includes('127.0.0.1');
      
      // Only mock if NOT already inside real Telegram WebApp
      const isRealTelegram = window.Telegram?.WebApp?.initData && window.Telegram?.WebApp?.initData !== '';
      
      if (isDev && !isRealTelegram) {
        window.Telegram = {
          WebApp: {
            initData: 'query_id=mock&user=%7B%22id%22%3A0%2C%22first_name%22%3A%22Developer%22%2C%22last_name%22%3A%22Test%22%2C%22username%22%3A%22dev_test%22%2C%22language_code%22%3A%22ar%22%7D&auth_date=' + Date.now(),
            initDataUnsafe: {
              user: {
                id: 0,
                first_name: 'Developer',
                last_name: 'Test',
                username: 'dev_test',
                language_code: 'ar'
              },
              query_id: 'mock_query_id',
              auth_date: Math.floor(Date.now() / 1000)
            },
            version: '6.0',
            platform: 'web',
            colorScheme: 'dark',
            themeParams: {
              bg_color: '#000000',
              text_color: '#ffffff',
              hint_color: '#999999',
              link_color: '#2481cc',
              button_color: '#2481cc',
              button_text_color: '#ffffff'
            },
            isExpanded: true,
            viewportHeight: window.innerHeight,
            viewportStableHeight: window.innerHeight,
            headerColor: '#000000',
            backgroundColor: '#000000',
            isClosingConfirmationEnabled: false,
            BackButton: { isVisible: false, onClick: function(){}, offClick: function(){}, show: function(){}, hide: function(){} },
            MainButton: { text: '', color: '#2481cc', textColor: '#ffffff', isVisible: false, isActive: true, isProgressVisible: false, setText: function(){}, onClick: function(){}, offClick: function(){}, show: function(){}, hide: function(){}, enable: function(){}, disable: function(){}, showProgress: function(){}, hideProgress: function(){}, setParams: function(){} },
            HapticFeedback: { impactOccurred: function(){}, notificationOccurred: function(){}, selectionChanged: function(){} },
            ready: function(){},
            expand: function(){},
            close: function(){},
            enableClosingConfirmation: function(){},
            disableClosingConfirmation: function(){},
            onEvent: function(){},
            offEvent: function(){},
            sendData: function(){},
            switchInlineQuery: function(){},
            openLink: function(){},
            openTelegramLink: function(){},
            openInvoice: function(){},
            showPopup: function(){},
            showAlert: function(){},
            showConfirm: function(){},
            showScanQrPopup: function(){},
            closeScanQrPopup: function(){},
            readTextFromClipboard: function(){},
            requestWriteAccess: function(){},
            requestContact: function(){},
            setHeaderColor: function(){},
            setBackgroundColor: function(){}
          }
        };
        console.log('[DEV MODE] Mock Telegram WebApp created with user ID:', 0);
      }
    </script>
    <script src="https://telegram.org/js/telegram-web-app.js"></script>
    <script>
      // Fullscreen setup - runs immediately
      const tg = window.Telegram?.WebApp;
      if (tg) {
        console.log('[TELEGRAM] Version:', tg.version);
        
        tg.ready();
        tg.expand();
        
        // Set header color to match app background (#000000)
        if (typeof tg.setHeaderColor === 'function') {
          tg.setHeaderColor('#242424');
          console.log('[TELEGRAM] ✅ Header color set');
        }
        
        if (typeof tg.setBackgroundColor === 'function') {
          tg.setBackgroundColor('#121212');
          console.log('[TELEGRAM] ✅ Background color set');
        }
        
        // Try requestFullscreen if available (v6.9+)
        if (typeof tg.requestFullscreen === 'function') {
          tg.requestFullscreen();
          console.log('[TELEGRAM] ✅ requestFullscreen() called');
        }
        
        // Disable swipes if available (v6.1+)
        if (typeof tg.disableVerticalSwipes === 'function') {
          tg.disableVerticalSwipes();
          console.log('[TELEGRAM] ✅ disableVerticalSwipes() called');
        }
        
        // متغيّرات المساحة الآمنة تنضبط فوراً قبل ما يركّب React — نفس ما يسوّونه
        // بصفحتهم، حتى ما تقفز الواجهة أول ما تفتح
        try {
          var _p = tg.platform;
          if (_p === 'android' || _p === 'ios') {
            var _ins = tg.contentSafeAreaInset || tg.safeAreaInset || {};
            var _top = _ins.top || 0;
            if (_p === 'ios' && _top === 0 && tg.isFullscreen) _top = 47;
            var _bottom = _p === 'android' ? 16 : (_ins.bottom || 0);
            var _root = document.documentElement.style;
            _root.setProperty('--safe-area-top', _top + 'px');
            _root.setProperty('--safe-area-bottom', _bottom + 'px');
            _root.setProperty('--tma-top-bar-height', (_p === 'ios' ? 52 : 48) + 'px');
            _root.setProperty('--header-extra-offset', (_p === 'ios' ? 44 : 24) + 'px');
          }
          document.documentElement.style.setProperty('--app-height', window.innerHeight + 'px');
        } catch (e) {}

        console.log('[TELEGRAM] ✅ Fullscreen setup complete');
      }
    </script>
    <style>
      /* Make page scrollable to prevent collapse gesture */
      html, body {
        min-height: calc(100vh + 1px);
        overflow-y: auto;
        /* منع الوميض الأبيض عند الفتح — نفس ملفهم */
        background-color: #121212;
        margin: 0;
        padding: 0;
        touch-action: pan-x pan-y;
      }
      
      /* Hide Replit dev banner */
      [data-dev-banner],
      [class*="dev-banner"],
      [id*="dev-banner"],
      iframe[src*="replit"],
      div[style*="position: fixed"][style*="top: 0"] {
        display: none !important;
        visibility: hidden !important;
        opacity: 0 !important;
        pointer-events: none !important;
        height: 0 !important;
        width: 0 !important;
      }
    </style>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <!-- ملصق الصاروخ الثابت — يتحمّل من أول لحظة حتى ما يظهر بديل -->
    <link rel="preload" href="/rocket-static.png?v=3" as="image" fetchpriority="high">
    <style>
      /* شاشة التحميل عند فتح التطبيق — نفس الي عدهم (nav-loader) */
      @keyframes navLoaderSpin { to { transform: rotate(360deg); } }
      #boot-loader {
        position: fixed;
        inset: 0;
        z-index: 99999;
        background: linear-gradient(to bottom, #1a1a1a, #121212);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
      }
      #boot-loader .bl-spinner {
        width: 48px;
        height: 48px;
        border: 2px solid #8774E1;
        border-top-color: transparent;
        border-radius: 50%;
        animation: navLoaderSpin 1s linear infinite;
        margin-bottom: 16px;
      }
      #boot-loader p {
        color: rgba(255,255,255,0.6);
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 14px;
        margin: 0;
      }
  </style>
    <script type="module" crossorigin src="/assets/main-CHsG71uB.js"></script>
    <link rel="modulepreload" crossorigin href="/assets/vendor-react-CXZPkzhT.js">
    <link rel="modulepreload" crossorigin href="/assets/vendor-three-D9fJkLhP.js">
    <link rel="modulepreload" crossorigin href="/assets/index-DzFf-KKr.js">
    <link rel="stylesheet" crossorigin href="/assets/index-BTwoIbmV.css">
  </head>

  <body>
    <div id="boot-loader">
      <div class="bl-spinner"></div>
      <p>Checking system status...</p>
    </div>
    <div id="root"></div>
    <script>
      /* window.hideSplash يستدعيه التطبيق أول ما يركّب أول شاشة. */
      (function () {
        window.hideSplash = function () {
          var el = document.getElementById('boot-loader');
          if (el && el.parentNode) el.parentNode.removeChild(el);
        };
      })();
    </script>
    <script>
      /* حارس الإقلاع — منقول حرفياً من index.html مالتهم: يعيش برّا الحزمة حتى
         يشتغل حتى لو الحزمة نفسها فشلت (الشاشة السودة). */
      (function () {
        function showFallback() {
          if (window.hideSplash) window.hideSplash();
          var root = document.getElementById('root');
          if (!root) return;
          root.innerHTML =
            '<div style="position:fixed;inset:0;display:flex;align-items:center;justify-content:center;background:#121212;color:#fff;font-family:-apple-system,system-ui,sans-serif;padding:24px;text-align:center">' +
              '<div style="max-width:300px">' +
                '<div style="font-size:44px;margin-bottom:16px">\uD83D\uDE80</div>' +
                '<div style="font-size:16px;font-weight:600;margin-bottom:8px">Couldn\u2019t load Ebic Gift</div>' +
                '<div style="font-size:13px;color:#9a9a9a;margin-bottom:20px">Check your connection and try again. If it keeps happening, fully close Telegram and reopen.</div>' +
                '<button id="eg-retry" style="background:#8774E1;color:#fff;border:none;padding:12px 24px;border-radius:12px;font-size:14px;font-weight:600">Reload</button>' +
              '</div>' +
            '</div>';
          var b = document.getElementById('eg-retry');
          if (b) b.addEventListener('click', function () {
            try { sessionStorage.removeItem('__eg_boot_reloaded'); } catch (e) {}
            location.reload();
          });
        }
        function check() {
          var root = document.getElementById('root');
          if (root && root.childElementCount > 0) {
            try { sessionStorage.removeItem('__eg_boot_reloaded'); } catch (e) {}
            return; // التطبيق ركّب شي
          }
          var canReload = false;
          try {
            if (!sessionStorage.getItem('__eg_boot_reloaded')) {
              sessionStorage.setItem('__eg_boot_reloaded', '1');
              canReload = true; // الحارس محفوظ -> إعادة تحميل وحدة بس
            }
          } catch (e) { /* التخزين مقفول -> بلا إعادة تحميل حتى ما تصير حلقة */ }
          if (canReload) { location.reload(); return; }
          showFallback();
        }
        setTimeout(check, 10000);
      })();
    </script>
    <script>
      // Hide Replit dev banner (CSS only - safe, no DOM removal)
      const style = document.createElement('style');
      style.textContent = '[data-dev-banner],[class*="dev-banner"],[id*="dev-banner"],iframe[src*="replit.com/badge"]{display:none!important;visibility:hidden!important;pointer-events:none!important;height:0!important;width:0!important;}';
      document.head.appendChild(style);
    </script>
  </body>
</html>