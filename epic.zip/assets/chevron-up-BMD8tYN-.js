import{Y as e}from"./index-DzFf-KKr.js";const r=e("ChevronUp",[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]]);export{r as C};
