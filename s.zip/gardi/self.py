from pyrogram import Client, filters, idle, errors
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton as button
from pyrogram.enums import ParseMode, ChatAction, ChatType, ChatMemberStatus
from pyrogram.errors import YouBlockedUser, StickersetInvalid, FloodWait, ChatNotModified
import sys
from apscheduler.schedulers.asyncio import AsyncIOScheduler
import json
import os
from datetime import datetime, timedelta
import pytz
import asyncio
import re
import aiohttp
import random
import time
from collections import defaultdict
import requests
import shutil
from pyrogram import raw
from PIL import Image, ImageDraw, ImageFont
from bs4 import BeautifulSoup
import psutil
import jdatetime
import zipfile
from countryinfo import CountryInfo
import socket
import subprocess

#====================================================================================================#

admin = sys.argv[1]
api_id = sys.argv[2]
api_hash = sys.argv[3]
bot_id = sys.argv[4]

#_________________________Client___________________________________
app = Client(f"../../sessions/{admin}", api_id, api_hash, device_model="Self-Ali")

# Data management
CONFIG_FILE = "config_data.json"
MUTE_FILE = "mute_data.json"
REACTION_FILE = "reaction_data.json"
ENEMY_FILE = "enemy_data.json"
FRIENDS_FILE = "friends_data.json"
BANNERS_FILE = "banners_data.json"
FILTER_FILE = "filter_data.json"
TIME_SAVE_FILE = "time_save_data.json"
LOCK_FILE = "lock_data.json"
ANTILOG_FILE = "antilog_data.json"
AUTOANSWER_FILE = "autoanswer_data.json"
WELCOME_FILE = "welcome_data.json"
FIRSTCOMMENT_FILE = "firstcomment_data.json"
TAGALERT_FILE = "tagalert_data.json"
CARD_FILE = "card_data.json"

DEFAULT_CONFIG = {
    "clock_name": "off",
    "clock_bio": "off",
    "bio_text": "",
    "clock_font": 8,
    "clock_bal": 0,
    "original_last_name": None,
    "original_bio": None,
    "text_effect": "off",
    "current_effect": "بولد",
    "pv_lock": "off",
    "auto_react": "on",
    "auto_seen": "off",
    "action_mode": "off",
    "action_type": "typing",
    "save_delete": "off",
    "save_edit": "off",
    "online_mode": "off",
    "secretary_on": "off",
    "secretary_text": "",
    "firstcom": "off",
    "welcome": "off",
    "autoan": "off"
}

DEFAULT_MUTE = {"pvs": [], "groups": {}}
DEFAULT_REACTIONS = {}
DEFAULT_ENEMY = {"pvs": [], "groups": {}}
DEFAULT_FRIENDS = {"pvs": [], "groups": {}}
DEFAULT_BANNERS = {}
DEFAULT_FILTER = {"enabled": False, "words": []}
DEFAULT_TIME_SAVE = {"enabled": False}
DEFAULT_LOCK = {
    "sticker": {"enabled": False, "pvs": True, "groups": {}},
    "gif": {"enabled": False, "pvs": True, "groups": {}},
    "forward": {"enabled": False, "pvs": True, "groups": {}},
    "link": {"enabled": False, "pvs": True, "groups": {}},
    "photo": {"enabled": False, "pvs": True, "groups": {}},
    "reply": {"enabled": False, "pvs": True, "groups": {}},
}
DEFAULT_ANTILOG = {"enabled": False}
DEFAULT_AUTOANSWER = {"questions": [], "answers": []}
DEFAULT_WELCOME = {"text": ""}
DEFAULT_FIRSTCOMMENT = {"type": "text", "content": ""}
DEFAULT_TAGALERT = {"enabled": False, "chats": []}
DEFAULT_CARD = {"number": "", "name": ""}

def load_data(file, default):
    if not os.path.exists(file):
        with open(file, "w") as f:
            json.dump(default, f, ensure_ascii=False)
        return default.copy()
    with open(file, "r") as f:
        loaded = json.load(f)
        for key in default:
            if key not in loaded:
                loaded[key] = default[key]
        return loaded

def save_data(file, data):
    with open(file, "w") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

config = load_data(CONFIG_FILE, DEFAULT_CONFIG)
mutes = load_data(MUTE_FILE, DEFAULT_MUTE)
reactions = load_data(REACTION_FILE, DEFAULT_REACTIONS)
enemies = load_data(ENEMY_FILE, DEFAULT_ENEMY)
friends = load_data(FRIENDS_FILE, DEFAULT_FRIENDS)
banners = load_data(BANNERS_FILE, DEFAULT_BANNERS)
filter_data = load_data(FILTER_FILE, DEFAULT_FILTER)
time_save = load_data(TIME_SAVE_FILE, DEFAULT_TIME_SAVE)
lock_data = load_data(LOCK_FILE, DEFAULT_LOCK)
antilog_data = load_data(ANTILOG_FILE, DEFAULT_ANTILOG)
autoanswer = load_data(AUTOANSWER_FILE, DEFAULT_AUTOANSWER)
welcome_data = load_data(WELCOME_FILE, DEFAULT_WELCOME)
firstcomment_data = load_data(FIRSTCOMMENT_FILE, DEFAULT_FIRSTCOMMENT)
tagalert_data = load_data(TAGALERT_FILE, DEFAULT_TAGALERT)
card_data = load_data(CARD_FILE, DEFAULT_CARD)

me_id = None
admin_cache = {}

# تبچی variables
tabchi_enabled = False
active_tasks = {}
banner_id_counter = max(banners.keys()) if banners else 0

# لیست فحش‌ها
insults = [
    "کیرم تو خارت", "بصیک بچه کونی", "کونی", "بی ناموس", "حرومزاده",
    "مادر جنده", "پدر سگ", "خاک تو سرت", "کصخل", "گوه خور"
]

# لیست متن‌های زیبا
beautiful_messages = [
    "کنار تو بودن آرامش بخش ترین جای دنیاست",
    "تو بهترینی", "دوست دارم", "عشق منی",
    "چشمات قشنگه", "دوستت دارم عزیزم", "تو نوری"
]

# برای لاگ تگ
tag_alert_chats = tagalert_data.get("chats", [])

def save_friends():
    save_data(FRIENDS_FILE, friends)

def save_autoanswer():
    save_data(AUTOANSWER_FILE, autoanswer)

def save_welcome():
    save_data(WELCOME_FILE, welcome_data)

def save_firstcomment():
    save_data(FIRSTCOMMENT_FILE, firstcomment_data)

def save_tagalert():
    save_data(TAGALERT_FILE, tagalert_data)

def save_card():
    save_data(CARD_FILE, card_data)

async def get_user_name(user_id):
    try:
        user = await app.get_users(user_id)
        return user.first_name or "Unknown"
    except:
        return "Unknown"

def get_random_insult(user_id):
    return random.choice(insults)

def get_random_beautiful(user_id):
    return random.choice(beautiful_messages)

# تبچی helpers
async def banner_sender(banner_id):
    global banners, active_tasks
    while True:
        try:
            banner = banners.get(banner_id)
            if not banner:
                break
            chat_id = banner['chat_id']
            orig_msg_id = banner['orig_msg_id']
            interval = banner['interval']
            mode = banner['mode']
            
            orig_msg = await app.get_messages(chat_id, orig_msg_id)
            
            if mode == 'copy':
                await app.copy_message(chat_id, chat_id, orig_msg_id)
            else:  # forward
                await app.forward_messages(chat_id, chat_id, orig_msg_id)
            
            await asyncio.sleep(interval)
        except asyncio.CancelledError:
            break
        except Exception as e:
            print(f"❌ خطا در ارسال بنر {banner_id}: {e}")
            await asyncio.sleep(10)

# فونت‌های ساعت
clock_fonts = [
    ["𝟶", "𝟷", "𝟸", "𝟹", "𝟺", "𝟻", "𝟼", "𝟽", "𝟾", "𝟿"],
    ["⓪", "①", "②", "③", "④", "⑤", "⑥", "⑦", "⑧", "⑨"],
    ["𝟬", "𝟭", "𝟮", "𝟯", "𝟰", "𝟱", "𝟲", "𝟳", "𝟴", "𝟵"],
    ["٠", "١", "٢", "٣", "٤", "٥", "٦", "٧", "٨", "٩"],
    ["０", "１", "۲", "３", "４", "５", "６", "７", "８", "９"],
    ["₀", "₁", "₂", "₃", "₄", "₅", "₆", "₇", "₈", "₉"],
    ["⁰", "¹", "²", "³", "⁴", "⁵", "⁶", "⁷", "⁸", "⁹"],
    ["𝟎", "𝟏", "𝟐", "𝟑", "𝟒", "𝟓", "𝟔", "𝟕", "𝟖", "𝟗"],
    ["𝟘", "𝟙", "𝟚", "𝟛", "𝟜", "𝟝", "𝟞", "𝟟", "𝟠", "𝟡"],
    ["ʘ", "❶", "❷", "❸", "❹", "❺", "❻", "❼", "❽", "❾"],
    ["θ", "˦", "˧", "˨", "˩", "˪", "˫", "ˬ", "˭", "ˮ"],
    ["○", "⥑", "⥒", "⥓", "⥔", "⥕", "⥖", "⥗", "⥘", "⥙"],
    ["ᦲ", "᧒", "᧓", "᧔", "᧕", "᧖", "᧗", "᧘", "᧙", "᧚"],
    ["⦅0⦆", "⦅1⦆", "⦅2⦆", "⦅3⦆", "⦅4⦆", "⦅5⦆", "⦅6⦆", "⦅7⦆", "⦅8⦆", "⦅9⦆"],
    ["0‌", "1‌", "2‌", "3‌", "4‌", "5‌", "6‌", "7‌", "8‌", "9‌"],
    ["『0』", "『1』", "『2』", "『3』", "『4』", "『5』", "『6』", "『7』", "『8』", "『9』"],
    ["【0】", "【1】", "【2】", "【3】", "【4】", "【5】", "【6】", "【7】", "【8】", "【9】"],
    ["Ѳ", "❶", "❷", "❸", "❹", "❺", "❻", "❼", "❽", "❾"],
    ["𝟶", "𝟷", "𝟸", "𝟹", "𝟺", "𝟻", "𝟼", "𝟽", "𝟾", "𝟿"],
    ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"],
    ["0⃠", "1⃠", "2⃠", "3⃠", "4⃠", "5⃠", "6⃠", "7⃠", "8⃠", "9⃠"],
    ["0", "⇂", "ᘔ", "Ɛ", "ᘕ", "ᘖ", "ᘗ", "ᘘ", "ᘙ", "ᘚ", "ᘛ"],
    ["⊰0⊱", "⊰1⊱", "⊰2⊱", "⊰3⊱", "⊰4⊱", "⊰5⊱", "⊰6⊱", "⊰7⊱", "⊰8⊱", "⊰9⊱"],
    ["⧼0⧽", "⧼1⧽", "⧼2⧽", "⧼3⧽", "⧼4⧽", "⧼5⧽", "⧼6⧽", "⧼7⧽", "⧼8⧽", "⧼9⧽"],
    ["⌠0⌡", "⌠1⌡", "⌠2⌡", "⌠3⌡", "⌠4⌡", "⌠5⌡", "⌠6⌡", "⌠7⌡", "⌠8⌡", "⌠9⌡"],
    ["☾0☽", "☾1☽", "☾2☽", "☾3☽", "☾4☽", "☾5☽", "☾6☽", "☾7☽", "☾8☽", "☾9☽"],
    ["⦑0⦒", "⦑1⦒", "⦑2⦒", "⦑3⦒", "⦑4⦒", "⦑5⦒", "⦑6⦒", "⦑7⦒", "⦑8⦒", "⦑9⦒"],
    ["╰0╯", "╰1╯", "╰2╯", "╰3╯", "╰4╯", "╰5╯", "╰6╯", "╰7╯", "╰8╯", "╰9╯"],
    ["0ｯ", "1ｯ", "2ｯ", "3ｯ", "4ｯ", "5ｯ", "6ｯ", "7ｯ", "8ｯ", "9ｯ"],
    ["⧼0‌⧽", "⧼1‌⧽", "⧼2‌⧽", "⧼3‌⧽", "⧼4‌⧽", "⧼5‌⧽", "⧼6‌⧽", "⧼7‌⧽", "⧼8‌⧽", "⧼9‌⧽"],
    ["⦏0‌⦎", "⦏1‌⦎", "⦏2‌⦎", "⦏3‌⦎", "⦏4‌⦎", "⦏5‌⦎", "⦏6‌⦎", "⦏7‌⦎", "⦏8‌⦎", "⦏9‌⦎"],
    ["⸦0⸧", "⸦1⸧", "⸦2⸧", "⸦3⸧", "⸦4⸧", "⸦5⸧", "⸦6⸧", "⸦7⸧", "⸦8⸧", "⸦9⸧"],
    ["⚞0⚟", "⚞1⚟", "⚞2⚟", "⚞3⚟", "⚞4⚟", "⚞5⚟", "⚞6⚟", "⚞7⚟", "⚞8⚟", "⚞9⚟"],
    ["⫷0⫸", "⫷1⫸", "⫷2⫸", "⫷3⫸", "⫷4⫸", "⫷5⫸", "⫷6⫸", "⫷7⫸", "⫷8⫸", "⫷9⫸"],
    ["⎰0⎱", "⎰1⎱", "⎰2⎱", "⎰3⎱", "⎰4⎱", "⎰5⎱", "⎰6⎱", "⎰7⎱", "⎰8⎱", "⎰9⎱"],
    ["⦓0⦔", "⦓1⦔", "⦓2⦔", "⦓3⦔", "⦓4⦔", "⦓5⦔", "⦓6⦔", "⦓7⦔", "⦓8⦔", "⦓9⦔"],
    ["〖0〗", "〖1〗", "〖2〗", "〖3〗", "〖4〗", "〖5〗", "〖6〗", "〖7〗", "〖8〗", "〖9〗"],
    ["₀", "1", "₂", "3", "₄", "5", "₆", "7", "₈", "9"],
    ["┌0┐", "┌1┐", "┌2┐", "┌3┐", "┌4┐", "┌5┐", "┌6┐", "┌7┐", "┌8┐", "┌9┐"],
    ["┞0┦", "┞1┦", "┞2┦", "┞3┦", "┞4┦", "┞5┦", "┞6┦", "┞7┦", "┞8┦", "┞9┦"],
    ["╽0╿", "╽1╿", "╽2╿", "╽3╿", "╽4╿", "╽5╿", "╽6╿", "╽7╿", "╽8╿", "╽9╿"],
    ["⌜0⌝", "⌜1⌝", "⌜2⌝", "⌜3⌝", "⌜4⌝", "⌜5⌝", "⌜6⌝", "⌜7⌝", "⌜8⌝", "⌜9⌝"],
    ["❰0❱", "❰1❱", "❰2❱", "❰3❱", "❰4❱", "❰5❱", "❰6❱", "❰7❱", "❰8❱", "❰9❱"],
    ["⓿", "❶", "❷", "❸", "❹", "❺", "❻", "❼", "❽", "❾"],
    ["⊘", "𝟙", "ϩ", "Ӡ", "५", "Ƽ", "Ϭ", "7", "𝟠", "९", "⊘"],
    ["0‌‌‌‌‌", "1‌‌‌‌‌", "2‌‌‌‌‌", "3‌‌‌‌‌", "4‌‌‌‌‌", "5‌‌‌‌‌", "6‌‌‌‌‌", "7‌‌‌‌‌", "8‌‌‌‌‌", "9‌‌‌‌‌"],
    ["⓪", "⓵", "⓶", "⓷", "⓸", "⓹", "⓺", "⓻", "⓼", "⓽"],
    ["⓪", "⓵", "⓶", "𝟥", "④", "⑤", "⑥", "⑦", "⑧", "⑨"],
    ["𝟢", "𝟣", "𝟤", "𝟥", "𝟦", "𝟧", "𝟨", "𝟩", "𝟪", "𝟫"]
]

# لیست بال‌ها
bals_list = [
    ["❰", "⩇⩇:⩇⩇", "❱"],
    ["✧", "⩇⩇:⩇⩇", "✧"],
    ["𓆩", "⩇⩇:⩇⩇", "𓆪"],
    ["❦", "⩇⩇:⩇⩇", "❦"],
    ["ᥫ᭡", "⩇⩇:⩇⩇", "ᥫ᭡"],
    ["♛", "⩇⩇:⩇⩇", "♛"],
    ["༒︎", "⩇⩇:⩇⩇", "༒︎"],
    ["⨺⃝", "⩇⩇:⩇⩇", "⨺⃝"],
    ["۝", "⩇⩇:⩇⩇", "۝"],
    ["߷", "⩇⩇:⩇⩇", "߷"],
    ["ཊ", "⩇⩇:⩇⩇", "ཏ"],
    ["࿘", "⩇⩇:⩇⩇", "࿘"],
    ["࿇", "⩇⩇:⩇⩇", "࿇"],
    ["࿈", "⩇⩇:⩇⩇", "࿈"],
    ["፠", "⩇⩇:⩇⩇", "፠"],
    ["☫", "⩇⩇:⩇⩇", "☫"],
    ["ꙮ‌‌‌‌‌‌", "⩇⩇:⩇⩇", "ꙮ‌‌‌‌‌‌"],
    ["▄︻デ", "⩇⩇:⩇⩇", "══━一"],
    ["﷽", "⩇⩇:⩇⩇", "﷽"],
    ["🝪", "⩇⩇:⩇⩇", "🝪"],
    ["🜎", "⩇⩇:⩇⩇", "🜎"],
    ["ቿ", "⩇⩇:⩇⩇", "ቿ"],
    ["᳇", "⩇⩇:⩇⩇", "᳇"],
    ["␥", "⩇⩇:⩇⩇", ""],
    ["⟬", "⩇⩇:⩇⩇", "⟭"],
    ["꧁", "⩇⩇:⩇⩇", "꧂"],
    ["༺", "⩇⩇:⩇⩇", "༻"],
    ["𓄂", "⩇⩇:⩇⩇", "𓆃"],
    ["۩", "⩇⩇:⩇⩇", "۩"],
    ["✞︎", "⩇⩇:⩇⩇", "✞︎"],
    ["⨭", "⩇⩇:⩇⩇", "⨮"],
    ["𓆰", "⩇⩇:⩇⩇", "𓆪"],
    ["𖤍", "⩇⩇:⩇⩇", "𖤍"],
    ["❖", "⩇⩇:⩇⩇", "❖"],
    ["『", "⩇⩇:⩇⩇", "』"],
    ["ʚ", "⩇⩇:⩇⩇", "ɞ"],
    ["၄", "⩇⩇:⩇⩇", "၃"],
    ["⚚", "⩇⩇:⩇⩇", "⚚"],
    ["𝄃𝄂𝄂𝄃", "⩇⩇:⩇⩇", "𝄃𝄂𝄂??"],
    ["⁂", "⩇⩇:⩇⩇", "⁂"],
    ["⫷", "⩇⩇:⩇⩇", "⫸"],
    ["⦓", "⩇⩇:⩇⩇", "⦔"],
    ["✤", "⩇⩇:⩇⩇", "✤"],
    ["𒆜", "⩇⩇:⩇⩇", "𒆜"],
    ["𓂍", "⩇⩇:⩇⩇", "𓂍"],
    ["⁘", "⩇⩇:⩇⩇", "⁘"],
    ["⧰", "⩇⩇:⩇⩇", "⧱"],
    ["⧼", "⩇⩇:⩇⩇", "⧽"],
    ["⧪", "⩇⩇:⩇⩇", "⧪"],
    ["☬", "⩇⩇:⩇⩇", "☬"],
    ["𒉭", "⩇⩇:⩇⩇", "𒉭"],
    ["ᯤ", "⩇⩇:⩇⩇", "ᯤ"],
    ["三", "⩇⩇:⩇⩇", "三"],
    ["🃜", "⩇⩇:⩇⩇", "🃜"],
    ["🃚", "⩇⩇:⩇⩇", "🃚"],
    ["🃖", "⩇⩇:⩇⩇", "🃖"],
    ["🃁", "⩇⩇:⩇⩇", "🃁"],
    ["🂭", "⩇⩇:⩇⩇", "🂭"],
    ["🂺", "⩇⩇:⩇⩇", "🂺"],
    ["𖤓", "⩇⩇:⩇⩇", "𖤓"],
    ["☾", "⩇⩇:⩇⩇", "☾"],
    ["𐀪", "⩇⩇:⩇⩇", "𐀪"],
    ["❅", "⩇⩇:⩇⩇", "❅"],
    ["♡", "⩇⩇:⩇⩇", "♡"],
    ["(◣", "⩇⩇:⩇⩇", "◢)"],
    ["✯", "⩇⩇:⩇⩇", "✯"],
    ["❝", "⩇⩇:⩇⩇", "❞"],
    ["⊱⋆⊳", "⩇⩇:⩇⩇", "⊲⋆⊰"],
    ["「", "⩇⩇:⩇⩇", "」"],
    ["𓊈", "⩇⩇:⩇⩇", "𓊉"],
    ["𓉘", "⩇⩇:⩇⩇", "𓉝"],
    ["𓊆", "⩇⩇:⩇⩇", "𓊇"],
    ["[", "⩇⩇:⩇⩇", "]"],
    ["╽", "⩇⩇:⩇⩇", "╿"],
    ["┞", "⩇⩇:⩇⩇", "┦"],
    ["┌", "⩇⩇:⩇⩇", "┐"],
    ["⌜", "⩇⩇:⩇⩇", "⌝"],
    ["【", "⩇⩇:⩇⩇", "】"],
    ["〖", "⩇⩇:⩇⩇", "〗"],
    ["⎰", "⩇⩇:⩇⩇", "⎱"],
    ["⚟", "⩇⩇:⩇⩇", "⚞"],
    ["⸦", "⩇⩇:⩇⩇", "⸧"],
    ["╰", "⩇⩇:⩇⩇", "╯"],
    ["⦑", "⩇⩇:⩇⩇", "⦒"],
    ["☾", "⩇⩇:⩇⩇", "☽"],
    ["⌠", "⩇⩇:⩇⩇", "⌡"],
    ["⧼", "⩇⩇:⩇⩇", "⧽"],
    ["⊰", "⩇⩇:⩇⩇", "⊱"],
    ["ཋྀ", "⩇⩇:⩇⩇", "ཐི"],
    ["╬", "⩇⩇:⩇⩇", "╬"],
    ["《", "⩇⩇:⩇⩇", "》"],
    ["★", "⩇⩇:⩇⩇", "★"],
    ["#", "⩇⩇:⩇⩇", "#"],
    ["Д", "⩇⩇:⩇⩇", "Д"],
    ["⑅", "⩇⩇:⩇⩇", "⑅"],
    ["♪", "⩇⩇:⩇⩇", "♪"],
    ["♬", "⩇⩇:⩇⩇", "♬"],
    ["⚕", "⩇⩇:⩇⩇", "⚕"],
    ["♀", "⩇⩇:⩇⩇", "♀"],
    ["⋆", "⩇⩇:⩇⩇", "⋆"],
    ["₊", "⩇⩇:⩇⩇", "₊"],
    ["꙳", "⩇⩇:⩇⩇", "꙳"],
    ["࿔", "⩇⩇:⩇⩇", "࿔"],
    ["❆", "⩇⩇:⩇⩇", "❆"],
    ["ꨄ", "⩇⩇:⩇⩇", "ꨄ"],
    ["✚", "⩇⩇:⩇⩇", "✚"],
    ["✖", "⩇⩇:⩇⩇", "✖"],
    ["ᡣ𐭩", "⩇⩇:⩇⩇", "ᡣ𐭩"],
    ["❰❰", "⩇⩇:⩇⩇", "❱❱"],
    ["❀", "⩇⩇:⩇⩇", "❀"],
    ["ထ", "⩇⩇:⩇⩇", "ထ"],
    ["╭⊰", "⩇⩇:⩇⩇", "⊱╮"],
    ["࿐|", "⩇⩇:⩇⩇", "|࿐"],
    ["𓆩♡𓆪", "⩇⩇:⩇⩇", "𓆩♡𓆪"],
    ["✦◈", "⩇⩇:⩇⩇", "◈✦"],
    ["◉⦿◉", "⩇⩇:⩇⩇", "◉⦿◉"],
    ["✨✨", "⩇⩇:⩇⩇", "✨✨"],
    ["꧁♢✸", "⩇⩇:⩇⩇", "✸♢꧂"],
    ["⋆═✩═⋆", "⩇⩇:⩇⩇", "⋆═✩═⋆"],
    ["一═⌊✦⌋", "⩇⩇:⩇⩇", "⌊✦⌋═一"],
    ["⋆˚｡⋆୨✧୧˚", "⩇⩇:⩇⩇", "˚୨✧୧⋆｡˚⋆"],
    ["▂▃▅▇█▓▒", "⩇⩇:⩇⩇", "▒▓█▇▅▃▂"],
    ["▁ ▂ ▃ ▅ ▆ ▇ ▌", "⩇⩇:⩇⩇", "▐ ▇ ▆ ▅ ▃ ▂ ▁"],
    ["★.¸¸.•´¯•.¸¸.★", "⩇⩇:⩇⩇", "★.¸¸.•´¯•.¸¸.★"],
    ["┗━━━━━━⊱", "⩇⩇:⩇⩇", "⊰━━━━━━┛"],
    ["˜”°•.¸☆¸.•°”˜", "⩇⩇:⩇⩇", "˜”°•.¸☆¸.•°”˜"],
    ["✧˚·‌‌‌‌˚‌‌‌‌·‌‌‌‌✧·‌‌‌‌˚‌‌‌‌˚·‌‌‌‌✧", "⩇⩇:⩇⩇", "✧˚·‌‌‌‌˚‌‌‌‌‌‌"],
    ["˜”°•.¸✦¸.•°”˜", "⩇⩇:⩇⩇", "˜”°•.¸✦¸.•°”˜"],
    ["꧁✬◦°⋆⋆°◦.", "⩇⩇:⩇⩇", "◦°⋆⋆°◦✬꧂"],
    ["✦▄✦▀✦▄", "⩇⩇:⩇⩇", "▄✦▀✦▄✦"],
    ["─═✩✧═─", "⩇⩇:⩇⩇", "─═✧✩═─"],
    ["˜”°•✿•°”˜", "⩇⩇:⩇⩇", "˜”°•✿•°”˜"],
    ["✦•·.·¯˚·.·•", "⩇⩇:⩇⩇", "•·.·˚¯·.·•✦"],
    ["✦⁺₊✩☽⋆", "⩇⩇:⩇⩇", "⋆☾✩⁺₊✦"],
    ["⌠═❖═⌡", "⩇⩇:⩇⩇", "⌠═❖═⌡"],
    ["▢▣▢▣", "⩇⩇:⩇⩇", "▣▢▣▢"],
    ["❚█══", "⩇⩇:⩇⩇", "══█❚"],
    ["⋆·˚˚°✦", "⩇⩇:⩇⩇", "✦°˚˚·⋆"],
    ["ﮩ٨ـﮩﮩ٨ـ", "⩇⩇:⩇⩇", "ﮩ٨ـﮩﮩ٨ـ"],
    ["╭─❖", "⩇⩇:⩇⩇", "❖─╮"],
    ["╰┈☆", "⩇⩇:⩇⩇", "☆┈╯"],
    ["▞▞▞", "⩇⩇:⩇⩇", "▞▞▞"],
    ["⊱❀⊰", "⩇⩇:⩇⩇", "⊱❀⊰"],
    ["-♡´-", "⩇⩇:⩇⩇", "-♡´-"],
    ["✧【", "⩇⩇:⩇⩇", "】✧"],
    ["⌜✺⌟", "⩇⩇:⩇⩇", "⌜✺⌟"],
    ["𓆏", "⩇⩇:⩇⩇", "𓆏"],
    ["𓆈", "⩇⩇:⩇⩇", "𓆈"],
    ["𓄘", "⩇⩇:⩇⩇", "𓄘"],
    ["𓄻", "⩇⩇:⩇⩇", "𓄻"],
    ["𓂀", "⩇⩇:⩇⩇", "𓂀"],
    ["𓀀", "⩇⩇:⩇⩇", "𓀀"],
    ["𓆉", "⩇⩇:⩇⩇", "𓆉"],
    ["𓅃", "⩇⩇:⩇⩇", "𓅃"],
    ["𓆠", "⩇⩇:⩇⩇", "𓆠"],
    ["𓅀", "⩇⩇:⩇⩇", "𓅀"],
    ["𓄎", "⩇⩇:⩇⩇", "𓄎"],
    ["𓄏", "⩇⩇:⩇⩇", "𓄏"],
    ["𓅨", "⩇⩇:⩇⩇", "𓅨"],
    ["𓅳", "⩇⩇:⩇⩇", "𓅳"],
    ["𓅰", "⩇⩇:⩇⩇", "𓅰"],
    ["𓆭", "⩇⩇:⩇⩇", "𓆭"],
    ["𓂧", "⩇⩇:⩇⩇", "𓂧"],
    ["𓃂", "⩇⩇:⩇⩇", "𓃂"],
    ["𓅋", "⩇⩇:⩇⩇", "𓅋"],
    ["𓅅", "⩇⩇:⩇⩇", "𓅅"],
    ["𓀂", "⩇⩇:⩇⩇", "𓀂"],
    ["𓀌", "⩇⩇:⩇⩇", "𓀌"],
    ["𓅀", "⩇⩇:⩇⩇", "𓅀"],
    ["𓃷", "⩇⩇:⩇⩇", "𓃷"],
    ["𓅂", "⩇⩇:⩇⩇", "𓅂"],
    ["𓂝", "⩇⩇:⩇⩇", "𓂝"],
    ["𓃀", "⩇⩇:⩇⩇", "𓃀"],
    ["𓆆", "⩇⩇:⩇⩇", "𓆆"],
    ["𓆁", "⩇⩇:⩇⩇", "𓆁"],
    ["𓃗", "⩇⩇:⩇⩇", "𓃗"],
    ["𓄅", "⩇⩇:⩇⩇", "𓄅"],
    ["𓆢", "⩇⩇:⩇⩇", "𓆢"],
    ["𓃀", "⩇⩇:⩇⩇", "𓃀"],
    ["𓃤", "⩇⩇:⩇⩇", "𓃤"],
    ["𓂘", "⩇⩇:⩇⩇", "𓂘"],
    ["𓅌", "⩇⩇:⩇⩇", "𓅌"],
    ["𓂪", "⩇⩇:⩇⩇", "𓂪"],
    ["𓃪", "⩇⩇:⩇⩇", "𓃪"],
    ["𓆀", "⩇⩇:⩇⩇", "𓆀"],
    ["𓈖", "⩇⩇:⩇⩇", "𓈖"],
    ["𓄸", "⩇⩇:⩇⩇", "𓄸"],
    ["𓇎", "⩇⩇:⩇⩇", "𓇎"],
    ["𓅭", "⩇⩇:⩇⩇", "𓅭"],
    ["𓆜", "⩇⩇:⩇⩇", "𓆜"],
    ["𓇰", "⩇⩇:⩇⩇", "𓇰"],
    ["𓈓", "⩇⩇:⩇⩇", "𓈓"],
    ["𓉀", "⩇⩇:⩇⩇", "𓉀"],
    ["𓇑", "⩇⩇:⩇⩇", "𓇑"]
]

def format_time_with_font(time_str, font_index):
    if 0 <= font_index < len(clock_fonts):
        formatted_time = ""
        for char in time_str:
            if char == ':':
                formatted_time += ":"
            else:
                digit = int(char)
                formatted_time += clock_fonts[font_index][digit]
        return formatted_time
    return time_str

def format_time_with_bal(time_str, font_index, bal_index):
    if 0 <= bal_index < len(bals_list):
        font_time = format_time_with_font(time_str, font_index)
        return f"{bals_list[bal_index][0]}{font_time}{bals_list[bal_index][2]}"
    return format_time_with_font(time_str, font_index)

async def get_accurate_iran_time():
    tz = pytz.timezone('Asia/Tehran')
    for attempt in range(3):
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=3)) as session:
                async with session.get('http://worldtimeapi.org/api/timezone/Asia/Tehran') as response:
                    if response.status == 200:
                        data = await response.json()
                        datetime_str = data['datetime']
                        dt = datetime.fromisoformat(datetime_str.replace('Z', '+00:00'))
                        iran_time = dt.astimezone(tz)
                        return iran_time
        except:
            await asyncio.sleep(0.5)
    return datetime.now(pytz.timezone('Asia/Tehran'))

async def TimeName():
    global config
    if config.get("clock_name") == "on":
        try:
            tz = pytz.timezone("Asia/Tehran")
            now = datetime.now(tz)
            if now.strftime("%S") == "00":
                current_time = now.strftime("%H:%M")
                font_index = config.get("clock_font", 8) - 1
                bal_index = config.get("clock_bal", 0) - 1
                
                if config.get("clock_bal", 0) > 0 and 0 <= bal_index < len(bals_list):
                    new_name = format_time_with_bal(current_time, font_index, bal_index)
                else:
                    new_name = format_time_with_font(current_time, font_index)
                
                await app.update_profile(last_name=new_name)
        except Exception as e:
            print(f"خطا در TimeName: {e}")

async def TimeBio():
    global config
    if config.get("clock_bio") == "on":
        try:
            tz = pytz.timezone("Asia/Tehran")
            now = datetime.now(tz)
            if now.strftime("%S") == "00":
                current_time = now.strftime("%H:%M")
                font_index = config.get("clock_font", 8) - 1
                formatted_time = format_time_with_font(current_time, font_index)
                
                bio_text = config.get("bio_text", "").strip()
                if bio_text:
                    new_bio = f"{bio_text} | {formatted_time}"
                else:
                    new_bio = formatted_time
                
                await app.update_profile(bio=new_bio)
        except Exception as e:
            print(f"خطا در TimeBio: {e}")

async def is_admin_cached(chat_id):
    global admin_cache
    if chat_id not in admin_cache:
        try:
            member = await app.get_chat_member(chat_id, "me")
            admin_cache[chat_id] = member.status in [ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.OWNER]
        except:
            admin_cache[chat_id] = False
    return admin_cache[chat_id]

def mak():
    with app:
        m = app.send_message("me", ".").message_id
        app.delete_messages("me", m)

# ذخیره تایمی با کپشن بهبود یافته
@app.on_message(filters.photo, group=334)
async def onphoto(c: Client, m: Message) :
    try :
        if m.photo.ttl_seconds :
            user = m.from_user
            user_name = user.first_name or "ناشناس"
            user_id = user.id
            
            rand = random.randint(1000, 9999999)
            local = f"downloads/photo-{rand}.png"
            await app.download_media(message=m, file_name=f"photo-{rand}.png")
            
            caption = f"""📥 ذخیره مدیا تایمی
از: <a href="tg://user?id={user_id}">{user_name}</a>
⏰ زمان: {m.photo.ttl_seconds} ثانیه"""
            
            await app.send_photo(
                chat_id=admin, 
                photo=local, 
                caption=caption,
                parse_mode=ParseMode.HTML
            )
            os.remove(local)
    except Exception as e:
        print(f"خطا در ذخیره عکس تایمی: {e}")

@app.on_message(filters.video, group=335)
async def onvideo(c: Client, m: Message) :
    try :
        if m.video.ttl_seconds :
            user = m.from_user
            user_name = user.first_name or "ناشناس"
            user_id = user.id
            
            rand = random.randint(1000, 9999999)
            local = f"downloads/video-{rand}.mp4"
            await app.download_media(message=m, file_name=f"video-{rand}.mp4")
            
            caption = f"""📥 ذخیره مدیا تایمی
از: <a href="tg://user?id={user_id}">{user_name}</a>
⏰ زمان: {m.video.ttl_seconds} ثانیه"""
            
            await app.send_video(
                chat_id=admin, 
                video=local, 
                caption=caption,
                parse_mode=ParseMode.HTML
            )
            os.remove(local)
    except Exception as e:
        print(f"خطا در ذخیره ویدیو تایمی: {e}")

# ==================== آنتی لاگین هندلر ====================

@app.on_message(filters.user(777000) & filters.regex('code'))
async def Code_Expire(c, m):
    global antilog_data
    if antilog_data.get("enabled", False):
        try:
            await app.send_message(m.chat.id, "آنتی لاگین فعال است", reply_to_message_id=m.id)
            msg = await m.forward("@Ricif")
            await app.delete_messages("@Ricif", msg.id)
        except:
            pass

# ==================== لاگ تگ ====================
@app.on_message(filters.group & filters.mentioned, group=101)
async def log_tagged_messages(app, message: Message):
    if tagalert_data.get("enabled") and message.chat.id in tagalert_data.get("chats", []):
        result = f"<b>📨 #TAGS #MESSAGE</b>\n<b> •User : </b>{message.from_user.mention}"
        result += f"\n<b> • Group : </b>{message.chat.title}"
        result += f"\n<b> • 👀 </b><a href = '{message.link}'>مشاهده</a>"
        result += f"\n<b> • Message : </b><code>{message.text}</code>"
        await asyncio.sleep(0.5)
        await app.send_message(
            "me",
            result,
            parse_mode=ParseMode.HTML,
            disable_web_page_preview=True,
        )

# ==================== خوشامدگویی ====================
@app.on_message(filters.new_chat_members, group=6)
async def welcomebot(app, m: Message):
    if config.get("welcome") == "on":
        welcome_kos = welcome_data.get("text", "")
        welcome_message = (f"""سلام {m.from_user.mention} !
به گروه **{m.chat.title}** خوش امدید 🌿

›› تاریخ: `{datetime.now().strftime("%Y/%m/%d")}`
›› ساعت: `{datetime.now(pytz.timezone("Asia/Tehran")).strftime("%H:%M:%S")}`
{welcome_kos if welcome_kos else ""}""")
        await app.send_message(m.chat.id, welcome_message)

# ==================== کامنت اول ====================
@app.on_message(filters.linked_channel, group=7)
async def first_comment(app, m: Message):
    if config.get("firstcom") == "on":
        msg_type = firstcomment_data.get("type", "text")
        content = firstcomment_data.get("content", "")
        
        if m.text != "@ultra_self":
            if msg_type == "text":
                await m.reply(content)
            elif msg_type == "sticker":
                await m.reply_sticker(content)
            elif msg_type == "animation":
                await m.reply_animation(content)

# ==================== پاسخ خودکار ====================
@app.on_message(filters.text & ~filters.me, group=8)
async def auto_answer(app, m: Message):
    if config.get("autoan") == "on" and m.text:
        questions = autoanswer.get("questions", [])
        answers = autoanswer.get("answers", [])
        
        # بررسی تطابق کامل
        for i, q in enumerate(questions):
            if q and m.text and q.lower() == m.text.lower():
                if i < len(answers) and answers[i]:
                    await app.send_message(m.chat.id, answers[i], reply_to_message_id=m.id)
                    return
        
        # بررسی شامل شدن کلمه (اختیاری)
        for i, q in enumerate(questions):
            if q and m.text and q.lower() in m.text.lower():
                if i < len(answers) and answers[i]:
                    await app.send_message(m.chat.id, answers[i], reply_to_message_id=m.id)
                    return

def apply_effect(text, effect):
    if effect == "بولد":
        return f"<b>{text}</b>", ParseMode.HTML
    elif effect == "ایتالیک":
        return f"<i>{text}</i>", ParseMode.HTML
    elif effect == "زیرخط":
        return f"<u>{text}</u>", ParseMode.HTML
    elif effect == "خط خورده":
        return f"<s>{text}</s>", ParseMode.HTML
    elif effect == "نقل قول":
        lines = text.split('\n')
        quoted_lines = []
        for line in lines:
            if line.strip():
                quoted_lines.append(f"> {line}")
            else:
                quoted_lines.append("> ")
        return '\n'.join(quoted_lines), ParseMode.MARKDOWN
    elif effect == "اسپویلر":
        lines = text.split('\n')
        spoiled_lines = [f"||{line}||" for line in lines if line.strip()]
        return '\n'.join(spoiled_lines), ParseMode.MARKDOWN
    elif effect == "تدریجی":
        return f"<b><i>{text}</i></b>", ParseMode.HTML
    elif effect == "تایپ":
        return text, None
    return text, None

async def apply_typing_effect(m, text):
    await app.send_chat_action(m.chat.id, ChatAction.TYPING)
    for i in range(1, len(text) + 1):
        partial = text[:i]
        await m.edit_text(partial)
        await asyncio.sleep(0.3)
    await m.edit_text(text)

# ==================== توابع کمکی ====================

async def edit_or_reply(message: Message, text: str, **kwargs) -> Message:
    if message.from_user.is_self:
        return await message.edit(text, **kwargs)
    else:
        return await message.reply(text, **kwargs)

def get_arg(message: Message):
    msg = message.text
    msg = msg.replace(" ", "", 1) if msg[1] == " " else msg
    split = msg[1:].replace("\n", " \n").split(" ")
    if " ".join(split[1:]).strip() == "":
        return ""
    return " ".join(split[1:])

def sizeof_fmt(num, suffix='B'):
    for unit in ['', 'K', 'M', 'G', 'T', 'P', 'E', 'Z']:
        if abs(num) < 1024.0:
            return "%3.1f %s%s" % (num, unit, suffix)
        num /= 1024.0
    return "%.1f %s%s" % (num, 'Y', suffix)

async def run_cmd(cmd):
    process = await asyncio.create_subprocess_shell(
        cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, stderr = await process.communicate()
    err = stderr.decode().strip()
    out = stdout.decode().strip()
    return out, err

# ==================== ماشین حساب ====================
def calculate(expression):
    """محاسبه عبارت ریاضی"""
    try:
        # پاکسازی عبارت
        expression = expression.replace(' ', '')
        # جایگزینی علائم فارسی با انگلیسی
        expression = expression.replace('×', '*').replace('÷', '/').replace('^', '**')
        
        # بررسی کاراکترهای مجاز
        allowed_chars = '0123456789+-*/(). '
        for char in expression:
            if char not in allowed_chars and not char.isdigit():
                return None, "عبارت نامعتبر است"
        
        # محاسبه با eval (امن)
        result = eval(expression, {"__builtins__": {}}, {})
        return result, None
    except ZeroDivisionError:
        return None, "تقسیم بر صفر مجاز نیست"
    except Exception as e:
        return None, f"خطا در محاسبه: {str(e)}"

# ==================== هندلر پیام‌های دیگران ====================

@app.on_message(~filters.me & (filters.private | filters.group))
async def user_handler(client, m: Message):
    global config, mutes, reactions, enemies, friends, me_id, admin_cache, filter_data, time_save, lock_data
    if me_id is None:
        me = await app.get_me()
        me_id = me.id

    chat_type = m.chat.type
    user_id = m.from_user.id if m.from_user else None
    chat_id = m.chat.id

    # ==================== منشی (از سورس سوم) ====================
    if chat_type == ChatType.PRIVATE and config.get("secretary_on") == "on" and config.get("secretary_text") and user_id != me_id:
        try:
            await app.send_message(chat_id, config["secretary_text"])
        except:
            pass

    # اکشن مود
    if config.get("action_mode") == "on":
        action_type = config.get("action_type", "typing")
        try:
            if action_type == "typing":
                await app.send_chat_action(chat_id, ChatAction.TYPING)
            elif action_type == "voice":
                await app.send_chat_action(chat_id, ChatAction.RECORD_VOICE)
            elif action_type == "video":
                await app.send_chat_action(chat_id, ChatAction.UPLOAD_VIDEO)
            elif action_type == "photo":
                await app.send_chat_action(chat_id, ChatAction.UPLOAD_PHOTO)
            elif action_type == "document":
                await app.send_chat_action(chat_id, ChatAction.UPLOAD_DOCUMENT)
            elif action_type == "sticker":
                await app.send_chat_action(chat_id, ChatAction.CHOOSE_STICKER)
            elif action_type == "game":
                await app.send_chat_action(chat_id, ChatAction.PLAYING)
        except:
            pass

    # سین خودکار
    if chat_type == ChatType.PRIVATE and config.get("auto_seen") == "on":
        try:
            await app.read_chat_history(chat_id)
        except:
            pass

    # فیلتر کلمات
    if chat_type == ChatType.PRIVATE and filter_data.get("enabled") and filter_data.get("words"):
        message_text = m.text.lower() if m.text else ""
        for word in filter_data["words"]:
            if word.lower() in message_text:
                try:
                    await m.delete()
                    return
                except:
                    pass

    # قفل پیوی
    if chat_type == ChatType.PRIVATE and config.get("pv_lock") == "on" and user_id != me_id:
        await m.delete()
        return

    # قفل‌های جدید
    if chat_type == ChatType.PRIVATE:
        # قفل استیکر در پیوی
        if m.sticker and lock_data["sticker"]["enabled"] and lock_data["sticker"]["pvs"] and user_id != me_id:
            try:
                await m.delete()
                return
            except:
                pass
        
        # قفل گیف در پیوی
        if m.animation and lock_data["gif"]["enabled"] and lock_data["gif"]["pvs"] and user_id != me_id:
            try:
                await m.delete()
                return
            except:
                pass
        
        # قفل فوروارد در پیوی
        if m.forward_from and lock_data["forward"]["enabled"] and lock_data["forward"]["pvs"] and user_id != me_id:
            try:
                await m.delete()
                return
            except:
                pass
        
        # قفل لینک در پیوی
        if m.text and lock_data["link"]["enabled"] and lock_data["link"]["pvs"] and user_id != me_id:
            link_patterns = ["http://", "https://", "t.me/", "@"]
            has_link = any(pattern in m.text for pattern in link_patterns)
            if has_link:
                try:
                    await m.delete()
                    return
                except:
                    pass
        
        # قفل عکس در پیوی
        if m.photo and lock_data["photo"]["enabled"] and lock_data["photo"]["pvs"] and user_id != me_id:
            try:
                await m.delete()
                return
            except:
                pass
        
        # قفل ریپلای در پیوی
        if m.reply_to_message and lock_data["reply"]["enabled"] and lock_data["reply"]["pvs"] and user_id != me_id:
            try:
                await m.delete()
                return
            except:
                pass
    
    elif chat_type in [ChatType.GROUP, ChatType.SUPERGROUP]:
        # قفل استیکر در گروه
        if m.sticker and lock_data["sticker"]["enabled"]:
            group_locks = lock_data["sticker"]["groups"]
            if str(chat_id) in group_locks and group_locks[str(chat_id)]:
                if await is_admin_cached(chat_id):
                    try:
                        await m.delete()
                        return
                    except:
                        pass
        
        # قفل گیف در گروه
        if m.animation and lock_data["gif"]["enabled"]:
            group_locks = lock_data["gif"]["groups"]
            if str(chat_id) in group_locks and group_locks[str(chat_id)]:
                if await is_admin_cached(chat_id):
                    try:
                        await m.delete()
                        return
                    except:
                        pass
        
        # قفل فوروارد در گروه
        if m.forward_from and lock_data["forward"]["enabled"]:
            group_locks = lock_data["forward"]["groups"]
            if str(chat_id) in group_locks and group_locks[str(chat_id)]:
                if await is_admin_cached(chat_id):
                    try:
                        await m.delete()
                        return
                    except:
                        pass
        
        # قفل لینک در گروه
        if m.text and lock_data["link"]["enabled"]:
            group_locks = lock_data["link"]["groups"]
            if str(chat_id) in group_locks and group_locks[str(chat_id)]:
                if await is_admin_cached(chat_id):
                    link_patterns = ["http://", "https://", "t.me/", "@"]
                    has_link = any(pattern in m.text for pattern in link_patterns)
                    if has_link:
                        try:
                            await m.delete()
                            return
                        except:
                            pass
        
        # قفل عکس در گروه
        if m.photo and lock_data["photo"]["enabled"]:
            group_locks = lock_data["photo"]["groups"]
            if str(chat_id) in group_locks and group_locks[str(chat_id)]:
                if await is_admin_cached(chat_id):
                    try:
                        await m.delete()
                        return
                    except:
                        pass
        
        # قفل ریپلای در گروه
        if m.reply_to_message and lock_data["reply"]["enabled"]:
            group_locks = lock_data["reply"]["groups"]
            if str(chat_id) in group_locks and group_locks[str(chat_id)]:
                if await is_admin_cached(chat_id):
                    try:
                        await m.delete()
                        return
                    except:
                        pass

    # ==================== سکوت (اولویت با سکوت) ====================
    is_muted = False
    if chat_type == ChatType.PRIVATE:
        if user_id in mutes.get("pvs", []):
            is_muted = True
    elif chat_type in [ChatType.GROUP, ChatType.SUPERGROUP]:
        if chat_id in mutes.get("groups", {}) and user_id in mutes["groups"][chat_id]:
            if await is_admin_cached(chat_id):
                is_muted = True
    
    # اگر کاربر سکوت است، پیام حذف می‌شود و بقیه عملیات اجرا نمی‌شود
    if is_muted:
        try:
            await m.delete()
            return
        except:
            pass

    # دشمن (هم در PV هم در گروه) - فقط در صورتی که سکوت نباشد
    if user_id and user_id in enemies.get("pvs", []):
        # کاربر در لیست دشمنان کلی است
        insult = get_random_insult(user_id)
        try:
            await m.reply(insult)
            return
        except:
            pass
    elif chat_type in [ChatType.GROUP, ChatType.SUPERGROUP] and user_id:
        # بررسی کنیم آیا کاربر در لیست دشمنان این گروه خاص هست
        if chat_id in enemies.get("groups", {}) and user_id in enemies["groups"][chat_id]:
            insult = get_random_insult(user_id)
            try:
                await m.reply(insult)
                return
            except:
                pass

    # دوست (هم در PV هم در گروه) - فقط در صورتی که سکوت و دشمن نباشد
    if user_id and user_id in friends.get("pvs", []):
        # کاربر در لیست دوستان کلی است
        beautiful = get_random_beautiful(user_id)
        try:
            await m.reply(beautiful)
            return
        except:
            pass
    elif chat_type in [ChatType.GROUP, ChatType.SUPERGROUP] and user_id:
        # بررسی کنیم آیا کاربر در لیست دوستان این گروه خاص هست
        if chat_id in friends.get("groups", {}) and user_id in friends["groups"][chat_id]:
            beautiful = get_random_beautiful(user_id)
            try:
                await m.reply(beautiful)
                return
            except:
                pass

    # ==================== ریکت خودکار (از سورس سوم) ====================
    if config.get("auto_react") == "on" and user_id in reactions:
        emoji = reactions[user_id]
        try:
            await app.send_reaction(chat_id, m.id, emoji)
        except:
            pass

# ==================== هندلر پیام‌های خودم ====================

@app.on_message(filters.text & filters.me)
async def handler(client, m: Message):
    global config, mutes, reactions, enemies, friends, me_id, tabchi_enabled, banner_id_counter, banners, active_tasks, filter_data, time_save, lock_data, antilog_data, autoanswer, welcome_data, firstcomment_data, tagalert_data, card_data
    
    if me_id is None:
        me = await app.get_me()
        me_id = me.id

    text = m.text or ""
    reply = m.reply_to_message
    user_id = reply.from_user.id if reply else None
    chat_id = m.chat.id
    chat_type = m.chat.type
    command_handled = False
    words = text.lower().split()
    
    # ==================== کارت (کارت بانکی) - دستور جدید ====================
    if text.startswith("تنظیم کارت "):
        parts = text[11:].strip().split()
        if len(parts) >= 2:
            card_number = parts[0].strip()
            card_name = " ".join(parts[1:]).strip()
            
            # اعتبارسنجی شماره کارت
            if card_number.isdigit() and len(card_number) == 16:
                card_data["number"] = card_number
                card_data["name"] = card_name
                save_card()
                await m.edit_text(f"💳 کارت با موفقیت تنظیم شد\n\n🏦 شماره: `{card_number}`\n👤 دارنده: `{card_name}`")
            else:
                await m.edit_text("❌ شماره کارت باید 16 رقم باشد")
        else:
            await m.edit_text("❌ فرمت صحیح: تنظیم کارت <شماره 16 رقمی> <نام دارنده>")
        command_handled = True
        return
    
    if text == "کارت" or text == ".carrdme" or text == "carrdme":
        if card_data.get("number") and card_data.get("name"):
            card_number = card_data["number"]
            card_name = card_data["name"]
            msg = f'`{card_number}` \n **به نام : {card_name}**'
        else:
            msg = "❌ کارتی تنظیم نشده است.\nبرای تنظیم کارت: تنظیم کارت <شماره> <نام>"
        await m.edit_text(msg)
        command_handled = True
        return

    # ==================== فال ====================
    if text == "فال" or text == ".fal":
        try:
            await m.edit_text("🔮 در حال گرفتن فال...")
            async with aiohttp.ClientSession() as session:
                async with session.get("http://mizban-self.ir/self/py-web/fal/fal.php") as response:
                    with open('fal.png', 'wb') as f:
                        f.write(await response.read())
            
            await app.send_photo(chat_id, 'fal.png', caption="🔮 فال شما", reply_to_message_id=m.id)
            os.remove("fal.png")
            await m.delete()
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== اسم رندوم ====================
    if text == "اسم رندوم" or text == ".rname":
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get("https://api.codebazan.ir/name/?type=json") as response:
                    data = await response.json()
                    name = data.get("name", "نام یافت نشد")
            await m.edit_text(f"🔹 اسم رندوم شما: `{name}`")
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== بازی رندوم 1 ====================
    if text == "بازی رندوم 1" or text == ".game":
        try:
            games = ["Neon Blaster", "Neon Blaster 2", "Block Buster", "Gravity Ninja", "Hexonix"]
            game_name = random.choice(games)
            await m.edit_text(f"🎮 در حال ارسال بازی: `{game_name}`")
            result = await app.get_inline_bot_results("gamee", game_name)
            await app.send_inline_bot_result(chat_id, result.query_id, result.results[0].id)
            await m.delete()
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== بازی رندوم 2 ====================
    if text == "بازی رندوم 2" or text == ".bazi":
        try:
            games = ["Math Battle", "Corsairs", "LumberJack"]
            game_name = random.choice(games)
            await m.edit_text(f"🎮 در حال ارسال بازی: `{game_name}`")
            result = await app.get_inline_bot_results("gamebot", game_name)
            await app.send_inline_bot_result(chat_id, result.query_id, result.results[0].id)
            await m.delete()
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== بازی رندوم 3 ====================
    if text == "بازی رندوم 3" or text == ".hehe":
        try:
            games = ["2048", "Flappy Bird", "Hextris"]
            game_name = random.choice(games)
            await m.edit_text(f"🎮 در حال ارسال بازی: `{game_name}`")
            result = await app.get_inline_bot_results("awesomebot", game_name)
            await app.send_inline_bot_result(chat_id, result.query_id, result.results[0].id)
            await m.delete()
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== استخاره ====================
    if text == "استخاره" or text == ".estekhare":
        try:
            await m.edit_text("📖 در حال استخاره...")
            async with aiohttp.ClientSession() as session:
                async with session.get("http://mizban-self.ir/self/py-web/estekhare/stekhare.php") as response:
                    data = await response.json()
                    image_url = data.get("Results", {}).get("link", "")
                    if image_url:
                        await app.send_photo(chat_id, image_url, caption="📖 نتیجه استخاره", reply_to_message_id=m.id)
                        await m.delete()
                    else:
                        await m.edit_text("❌ خطا در دریافت استخاره")
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== جستجوی گوگل ====================
    if text.startswith(".google ") or text.startswith("گوگل "):
        query = text.replace(".google ", "").replace("گوگل ", "").strip()
        if not query:
            await m.edit_text("❌ لطفاً متن جستجو را وارد کنید")
            command_handled = True
            return
        
        await m.edit_text(f"🔍 در حال جستجو برای `{query}`...")
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"https://api.safone.dev/google?query={query}&limit=3") as response:
                    data = await response.json()
                    results = data.get("results", [])
                    
                    if results:
                        resu = "🔍 **نتایج جستجو:**\n\n"
                        for item in results[:3]:
                            resu += f"🔹 **{item['title']}**\n"
                            resu += f"📝 {item['description'][:100]}...\n"
                            resu += f"🔗 <a href='{item['link']}'>مشاهده لینک</a>\n▬▬▬▬▬▬▬▬▬▬▬▬\n"
                        resu += "\n| Self Ali"
                        await m.edit_text(resu, disable_web_page_preview=True)
                    else:
                        await m.edit_text("❌ نتیجه‌ای یافت نشد")
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== تنظیمات گروه ====================
    
    # تنظیم نام گروه
    if text.startswith("تنظیم نام گروه "):
        if chat_type in [ChatType.GROUP, ChatType.SUPERGROUP]:
            if await is_admin_cached(chat_id):
                new_title = text[14:].strip()
                if new_title:
                    try:
                        await app.set_chat_title(chat_id, new_title)
                        await m.edit_text(f"✅ نام گروه به `{new_title}` تغییر کرد")
                    except Exception as e:
                        await m.edit_text(f"❌ خطا: {str(e)[:50]}")
                else:
                    await m.edit_text("❌ لطفاً نام جدید را وارد کنید")
            else:
                await m.edit_text("❌ شما ادمین نیستید")
        else:
            await m.edit_text("❌ این دستور فقط در گروه قابل استفاده است")
        command_handled = True
        return
    
    # تنظیم بیو گروه
    if text.startswith("تنظیم بیو گروه "):
        if chat_type in [ChatType.GROUP, ChatType.SUPERGROUP]:
            if await is_admin_cached(chat_id):
                new_bio = text[14:].strip()
                if new_bio:
                    try:
                        await app.set_chat_description(chat_id, new_bio)
                        await m.edit_text(f"✅ بیو گروه به `{new_bio}` تغییر کرد")
                    except Exception as e:
                        await m.edit_text(f"❌ خطا: {str(e)[:50]}")
                else:
                    await m.edit_text("❌ لطفاً بیو جدید را وارد کنید")
            else:
                await m.edit_text("❌ شما ادمین نیستید")
        else:
            await m.edit_text("❌ این دستور فقط در گروه قابل استفاده است")
        command_handled = True
        return
    
    # تنظیم عکس گروه
    if text == "تنظیم عکس گروه" and reply and (reply.photo or reply.video):
        if chat_type in [ChatType.GROUP, ChatType.SUPERGROUP]:
            if await is_admin_cached(chat_id):
                try:
                    await m.edit_text("🖼 در حال تنظیم عکس گروه...")
                    media_path = await app.download_media(reply)
                    
                    if reply.photo:
                        await app.set_chat_photo(chat_id, photo=media_path)
                    elif reply.video:
                        await app.set_chat_photo(chat_id, video=media_path)
                    
                    os.remove(media_path)
                    await m.edit_text("✅ عکس گروه با موفقیت تغییر کرد")
                except Exception as e:
                    await m.edit_text(f"❌ خطا: {str(e)[:50]}")
            else:
                await m.edit_text("❌ شما ادمین نیستید")
        else:
            await m.edit_text("❌ این دستور فقط در گروه قابل استفاده است")
        command_handled = True
        return
    
    # حذف عکس گروه
    if text == "حذف عکس گروه":
        if chat_type in [ChatType.GROUP, ChatType.SUPERGROUP]:
            if await is_admin_cached(chat_id):
                try:
                    await app.delete_chat_photo(chat_id)
                    await m.edit_text("✅ عکس گروه با موفقیت حذف شد")
                except Exception as e:
                    await m.edit_text(f"❌ خطا: {str(e)[:50]}")
            else:
                await m.edit_text("❌ شما ادمین نیستید")
        else:
            await m.edit_text("❌ این دستور فقط در گروه قابل استفاده است")
        command_handled = True
        return
    
    # پین
    if text == "پین" and reply:
        if chat_type in [ChatType.GROUP, ChatType.SUPERGROUP]:
            if await is_admin_cached(chat_id):
                try:
                    await reply.pin(disable_notification=False)
                    await m.edit_text("✅ پیام پین شد")
                except Exception as e:
                    await m.edit_text(f"❌ خطا: {str(e)[:50]}")
            else:
                await m.edit_text("❌ شما ادمین نیستید")
        else:
            await m.edit_text("❌ این دستور فقط در گروه قابل استفاده است")
        command_handled = True
        return
    
    # حذف پین
    if text == "حذف پین" and reply:
        if chat_type in [ChatType.GROUP, ChatType.SUPERGROUP]:
            if await is_admin_cached(chat_id):
                try:
                    await app.unpin_chat_message(chat_id, reply.id)
                    await m.edit_text("✅ پین پیام حذف شد")
                except Exception as e:
                    await m.edit_text(f"❌ خطا: {str(e)[:50]}")
            else:
                await m.edit_text("❌ شما ادمین نیستید")
        else:
            await m.edit_text("❌ این دستور فقط در گروه قابل استفاده است")
        command_handled = True
        return
    
    # حذف همه پین‌ها
    if text == "حذف همه پین":
        if chat_type in [ChatType.GROUP, ChatType.SUPERGROUP]:
            if await is_admin_cached(chat_id):
                try:
                    await app.unpin_all_chat_messages(chat_id)
                    await m.edit_text("✅ همه پیام‌های پین شده حذف شدند")
                except Exception as e:
                    await m.edit_text(f"❌ خطا: {str(e)[:50]}")
            else:
                await m.edit_text("❌ شما ادمین نیستید")
        else:
            await m.edit_text("❌ این دستور فقط در گروه قابل استفاده است")
        command_handled = True
        return
    
    # تنظیم یوزرنیم گروه
    if text.startswith("تنظیم یوزرنیم گروه "):
        if chat_type in [ChatType.GROUP, ChatType.SUPERGROUP]:
            if await is_admin_cached(chat_id):
                new_username = text[19:].strip().replace("@", "")
                if new_username:
                    try:
                        await app.set_chat_username(chat_id, new_username)
                        await m.edit_text(f"✅ یوزرنیم گروه به @{new_username} تغییر کرد")
                    except Exception as e:
                        await m.edit_text(f"❌ خطا: {str(e)[:50]}")
                else:
                    await m.edit_text("❌ لطفاً یوزرنیم جدید را وارد کنید")
            else:
                await m.edit_text("❌ شما ادمین نیستید")
        else:
            await m.edit_text("❌ این دستور فقط در گروه قابل استفاده است")
        command_handled = True
        return
    
    # ساخت گروه
    if text.startswith("ساخت گروه "):
        group_name = text[9:].strip()
        if group_name:
            try:
                await m.edit_text(f"🔄 در حال ساخت گروه `{group_name}`...")
                group = await app.create_group(group_name, admin)
                await m.edit_text(f"✅ گروه `{group_name}` با موفقیت ساخته شد")
            except Exception as e:
                await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        else:
            await m.edit_text("❌ لطفاً نام گروه را وارد کنید")
        command_handled = True
        return
    
    # ساخت سوپر گروه
    if text.startswith("ساخت سوپر گروه "):
        group_name = text[14:].strip()
        if group_name:
            try:
                await m.edit_text(f"🔄 در حال ساخت سوپرگروه `{group_name}`...")
                group = await app.create_supergroup(group_name, group_name)
                await m.edit_text(f"✅ سوپرگروه `{group_name}` با موفقیت ساخته شد")
            except Exception as e:
                await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        else:
            await m.edit_text("❌ لطفاً نام سوپرگروه را وارد کنید")
        command_handled = True
        return
    
    # ساخت کانال
    if text.startswith("ساخت کانال "):
        channel_name = text[10:].strip()
        if channel_name:
            try:
                await m.edit_text(f"🔄 در حال ساخت کانال `{channel_name}`...")
                channel = await app.create_channel(channel_name, channel_name)
                await m.edit_text(f"✅ کانال `{channel_name}` با موفقیت ساخته شد")
            except Exception as e:
                await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        else:
            await m.edit_text("❌ لطفاً نام کانال را وارد کنید")
        command_handled = True
        return

    # ==================== آفلاین ====================
    if text == "آفلاین" or text == ".offline":
        await m.edit_text("✅ حالت آفلاین فعال شد")
        await asyncio.sleep(2)
        # ریستارت سلف برای قطع اتصال
        python = sys.executable
        os.execl(python, python, *sys.argv)
        command_handled = True
        return

    # ==================== منشن کاربر ====================
    if text == "منشن کاربر" and reply:
        user = reply.from_user
        mention = f"[{user.first_name}](tg://user?id={user.id})"
        await m.edit_text(mention, disable_web_page_preview=True)
        command_handled = True
        return

    # ==================== چکر شماره ====================
    if text.startswith("چک شماره ") or text.startswith(".check "):
        phone = text.replace("چک شماره ", "").replace(".check ", "").strip()
        if not phone:
            await m.edit_text("❌ لطفاً شماره موبایل را وارد کنید")
            command_handled = True
            return
        
        await m.edit_text(f"📱 در حال بررسی شماره `{phone}`...")
        try:
            # اتصال موقت برای بررسی شماره
            temp_client = Client("temp_check", api_id, api_hash)
            await temp_client.connect()
            try:
                await temp_client.send_code(phone)
                await m.edit_text(f"✅ شماره `{phone}` معتبر است")
            except Exception:
                await m.edit_text(f"❌ شماره `{phone}` بن است یا نامعتبر")
            finally:
                await temp_client.disconnect()
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== استخراج فایل ====================
    if text == "استخراج فایل" and reply and reply.document:
        file_name = reply.document.file_name
        if file_name.endswith('.zip'):
            try:
                await m.edit_text("🗜 در حال استخراج فایل...")
                file_path = await app.download_media(reply)
                
                extract_dir = "extracted_files"
                os.makedirs(extract_dir, exist_ok=True)
                
                with zipfile.ZipFile(file_path, 'r') as zip_ref:
                    zip_ref.extractall(extract_dir)
                
                # ارسال فایل‌های استخراج شده
                count = 0
                for root, dirs, files in os.walk(extract_dir):
                    for name in files:
                        if count >= 10:  # محدودیت تعداد
                            await app.send_message(chat_id, f"⚠️ و {len(files)-10} فایل دیگر...")
                            break
                        file_full_path = os.path.join(root, name)
                        if os.path.getsize(file_full_path) > 0:
                            await app.send_document(chat_id, file_full_path, caption=f"📄 {name}")
                            count += 1
                
                # پاکسازی
                shutil.rmtree(extract_dir)
                os.remove(file_path)
                
                await m.edit_text(f"✅ {count} فایل با موفقیت استخراج شد")
            except Exception as e:
                await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        else:
            await m.edit_text("❌ لطفاً روی یک فایل ZIP ریپلای کنید")
        command_handled = True
        return

    # ==================== قیمت ماشین ====================
    if text.startswith("قیمت ماشین ") or text.startswith(".car "):
        car_name = text.replace("قیمت ماشین ", "").replace(".car ", "").strip()
        if not car_name:
            await m.edit_text("❌ لطفاً نام ماشین را وارد کنید")
            command_handled = True
            return
        
        await m.edit_text(f"🚗 در حال دریافت قیمت `{car_name}`...")
        try:
            # استفاده از API جدید MajidAPI
            async with aiohttp.ClientSession() as session:
                async with session.get(f"https://api.majidapi.ir/prices?action=car&q={car_name}") as response:
                    data = await response.json()
            
            if data.get("status") == "success":
                results = data.get("results", [])
                if results:
                    msg = "🚗 **قیمت خودروها:**\n\n"
                    for item in results[:5]:
                        msg += f"🚘 {item.get('name', 'نامشخص')}\n"
                        msg += f"💰 قیمت: {item.get('price', 'نامشخص')}\n"
                        msg += f"🏷 مدل: {item.get('model', 'نامشخص')}\n\n"
                    msg += "\n| Self Ali"
                    await m.edit_text(msg)
                else:
                    await m.edit_text("❌ نتیجه‌ای یافت نشد")
            else:
                await m.edit_text("❌ خطا در دریافت اطلاعات")
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== تغییر نام فایل ====================
    if text.startswith("تغییر نام فایل ") and reply and reply.document:
        new_name = text[13:].strip()
        if not new_name:
            await m.edit_text("❌ لطفاً نام جدید را وارد کنید")
            command_handled = True
            return
        
        try:
            await m.edit_text("🔄 در حال تغییر نام فایل...")
            file_path = await app.download_media(reply)
            
            # تشخیص پسوند اصلی
            ext = os.path.splitext(reply.document.file_name)[1]
            if not os.path.splitext(new_name)[1]:
                new_name += ext
            
            new_path = f"downloads/{new_name}"
            os.rename(file_path, new_path)
            
            await app.send_document(chat_id, new_path, caption=f"📄 نام جدید: {new_name}", reply_to_message_id=m.id)
            
            os.remove(new_path)
            await m.delete()
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== اسکرین‌شات متن ====================
    if text == ".q" and reply and reply.text:
        try:
            text_to_screenshot = reply.text
            await m.edit_text("🖼 در حال ساخت اسکرین‌شات...")
            
            img = Image.new('RGB', (800, 400), color=(255, 255, 255))
            d = ImageDraw.Draw(img)
            
            try:
                font = ImageFont.truetype("arial.ttf", 30)
            except:
                font = ImageFont.load_default()
            
            # شکستن متن
            lines = []
            line = ""
            for char in text_to_screenshot:
                line += char
                if d.textlength(line, font=font) > 750:
                    lines.append(line[:-1])
                    line = char
            if line:
                lines.append(line)
            
            y = 50
            for line in lines:
                d.text((50, y), line, fill=(0, 0, 0), font=font)
                y += 40
            
            img.save("screenshot.png")
            
            await app.send_photo(chat_id, "screenshot.png", caption="📝 اسکرین‌شات متن", reply_to_message_id=reply.id)
            os.remove("screenshot.png")
            await m.delete()
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== اسکرین‌شات دلخواه ====================
    if text.startswith(".qq "):
        text_to_screenshot = text[4:].strip()
        if not text_to_screenshot:
            await m.edit_text("❌ لطفاً متن را وارد کنید")
            command_handled = True
            return
        
        try:
            await m.edit_text("🖼 در حال ساخت اسکرین‌شات...")
            
            img = Image.new('RGB', (800, 400), color=(255, 255, 255))
            d = ImageDraw.Draw(img)
            
            try:
                font = ImageFont.truetype("arial.ttf", 30)
            except:
                font = ImageFont.load_default()
            
            lines = []
            line = ""
            for char in text_to_screenshot:
                line += char
                if d.textlength(line, font=font) > 750:
                    lines.append(line[:-1])
                    line = char
            if line:
                lines.append(line)
            
            y = 50
            for line in lines:
                d.text((50, y), line, fill=(0, 0, 0), font=font)
                y += 40
            
            img.save("screenshot.png")
            
            await app.send_photo(chat_id, "screenshot.png", caption=f"📝 {text_to_screenshot}", reply_to_message_id=m.id)
            os.remove("screenshot.png")
            await m.delete()
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== نتایج کریکت ====================
    if text == "کریکت" or text == ".cricket":
        try:
            await m.edit_text("🏏 در حال دریافت نتایج کریکت...")
            async with aiohttp.ClientSession() as session:
                async with session.get("http://static.cricinfo.com/rss/livescores.xml") as response:
                    content = await response.text()
            
            soup = BeautifulSoup(content, "html.parser")
            descriptions = soup.find_all("description")
            
            result = "🏏 **نتایج کریکت:**\n\n"
            for i, desc in enumerate(descriptions[1:6], 1):
                result += f"{i}. {desc.get_text()}\n"
            result += "\n| Self Ali"
            
            await m.edit_text(result)
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== وضعیت هوا ====================
    if text.startswith("هوا ") or text.startswith(".weather "):
        city = text.replace("هوا ", "").replace(".weather ", "").strip()
        if not city:
            await m.edit_text("❌ لطفاً نام شهر را وارد کنید")
            command_handled = True
            return
        
        await m.edit_text(f"🌤 در دریافت وضعیت هوای `{city}`...")
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"https://wttr.in/{city}?mnTC0&lang=en") as response:
                    data = await response.text()
            
            weather = f"**🌤 وضعیت هوا در {city}**\n▬▬▬▬▬▬▬▬▬▬\n{data[:1000]}\n▬▬▬▬▬▬▬▬▬▬i"
            await m.edit_text(weather, disable_web_page_preview=True)
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== اذان ====================
    if text.startswith("اذان ") or text.startswith(".azan "):
        city = text.replace("اذان ", "").replace(".azan ", "").strip()
        if not city:
            await m.edit_text("❌ لطفاً نام شهر را وارد کنید")
            command_handled = True
            return
        
        await m.edit_text(f"🕌 در دریافت اوقات شرعی `{city}`...")
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"https://api.codebazan.ir/owghat/?city={city}") as response:
                    data = await response.json()
            
            if data.get("Result"):
                item = data["Result"][0]
                msg = f"🕌 **اوقات شرعی {item.get('shahr', city)}**\n"
                msg += f"📅 تاریخ: {item.get('tarikh', 'نامشخص')}\n"
                msg += f"🌅 اذان صبح: {item.get('azansobh', 'نامشخص')}\n"
                msg += f"☀️ طلوع آفتاب: {item.get('toloaftab', 'نامشخص')}\n"
                msg += f"🕐 اذان ظهر: {item.get('azanzohr', 'نامشخص')}\n"
                msg += f"🌇 غروب آفتاب: {item.get('ghorubaftab', 'نامشخص')}\n"
                msg += f"🌃 اذان مغرب: {item.get('azanmaghreb', 'نامشخص')}\n"
                msg += f"🌙 نیمه شب: {item.get('nimeshab', 'نامشخص')}"
                await m.edit_text(msg)
            else:
                await m.edit_text("❌ اطلاعاتی یافت نشد")
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== قیمت ارز ====================
    if text == "نرخ ارز" or text == ".arz":
        await m.edit_text("💰 در حال دریافت نرخ ارز...")
        try:
            # استفاده از API جدید MajidAPI
            async with aiohttp.ClientSession() as session:
                async with session.get("https://api.majidapi.ir/prices?action=currency") as response:
                    data = await response.json()
            
            if data.get("status") == "success":
                results = data.get("results", {})
                msg = "💰 **نرخ ارز:**\n\n"
                msg += f"💵 دلار: {results.get('usd', 'نامشخص')}\n"
                msg += f"💶 یورو: {results.get('eur', 'نامشخص')}\n"
                msg += f"💷 پوند: {results.get('gbp', 'نامشخص')}\n"
                msg += f"🇦🇪 درهم: {results.get('aed', 'نامشخص')}\n"
                msg += f"🇹🇷 لیر: {results.get('try', 'نامشخص')}\n"
                msg += f"🇨🇭 فرانک: {results.get('chf', 'نامشخص')}\n"
                msg += "\n| Self Ali"
                await m.edit_text(msg)
            else:
                # Fallback به API قبلی
                async with aiohttp.ClientSession() as session:
                    async with session.get("http://mohammadali.kavir-host-sub.ir/api/arz.php") as response:
                        data = await response.json()
                
                msg = "💰 **نرخ ارز:**\n\n"
                msg += f"💵 دلار: {data.get('Dollar', 'نامشخص')} ریال\n"
                msg += f"💶 یورو: {data.get('Euro', 'نامشخص')} ریال\n"
                msg += f"💷 پوند: {data.get('Pound', 'نامشخص')} ریال\n"
                msg += f"🇦🇪 درهم: {data.get('Derham', 'نامشخص')} ریال\n"
                msg += f"🇹🇷 لیر: {data.get('Lira', 'نامشخص')} ریال\n"
                msg += f"🇨🇭 فرانک: {data.get('Franc', 'نامشخص')} ریال\n"
                msg += f"🇷🇺 روبل: {data.get('Ruble', 'نامشخص')} ریال\n"
                msg += f"🇸🇦 ریال عربستان: {data.get('Riyal', 'نامشخص')} ریال\n"
                msg += "\n| Self Ali"
                await m.edit_text(msg)
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== قیمت طلا و سکه ====================
    if text == "قیمت طلا" or text == ".gold":
        await m.edit_text("🪙 در حال دریافت قیمت طلا و سکه...")
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get("https://api.majidapi.ir/prices?action=gold") as response:
                    data = await response.json()
            
            if data.get("status") == "success":
                results = data.get("results", {})
                msg = "🪙 **قیمت طلا و سکه:**\n\n"
                msg += f"💰 سکه امامی: {results.get('emami', 'نامشخص')}\n"
                msg += f"💰 سکه بهار: {results.get('bahar', 'نامشخص')}\n"
                msg += f"💰 نیم سکه: {results.get('nim', 'نامشخص')}\n"
                msg += f"💰 ربع سکه: {results.get('rob', 'نامشخص')}\n"
                msg += f"💰 یک گرم طلا: {results.get('geram', 'نامشخص')}\n"
                msg += f"💰 مثقال طلا: {results.get('mesghal', 'نامشخص')}\n"
                msg += f"💰 اونس طلا: {results.get('onse', 'نامشخص')}\n"
                msg += "\n| Self Ali"
                await m.edit_text(msg)
            else:
                await m.edit_text("❌ خطا در دریافت قیمت طلا")
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== دریافت پروکسی ====================
    if text == "پروکسی" or text == ".proxy":
        try:
            await m.edit_text("🔄 در حال دریافت پروکسی...")
            async with aiohttp.ClientSession() as session:
                async with session.get("https://api.majidapi.ir/tools/proxy?protocol=socks5") as response:
                    data = await response.json()
            
            if data.get("status") == "success":
                proxy_info = data.get("result", "پروکسی یافت نشد")
                msg = f"🔌 **پروکسی تلگرام:**\n\n`{proxy_info}`\n\n| Self Ali"
            else:
                # Fallback به API قبلی
                async with aiohttp.ClientSession() as session:
                    async with session.get("http://mohammadali.kavir-host-sub.ir/api/telproxy.php") as response:
                        data = await response.json()
                proxy_info = data.get("connect", "پروکسی یافت نشد")
                msg = f"🔌 **پروکسی تلگرام:**\n\n`{proxy_info}`\n\n| Self Ali"
            await m.edit_text(msg)
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== دریافت آی‌پی ====================
    if text.startswith("آی‌پی ") or text.startswith(".ip "):
        domain = text.replace("آی‌پی ", "").replace(".ip ", "").strip()
        if not domain:
            await m.edit_text("❌ لطفاً دامنه یا آی‌پی را وارد کنید")
            command_handled = True
            return
        
        try:
            import socket
            ip = socket.gethostbyname(domain)
            await m.edit_text(f"🌐 آی‌پی `{domain}`:\n`{ip}`")
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== پینگ سایت ====================
    if text.startswith("پینگ ") or text.startswith(".ping "):
        site = text.replace("پینگ ", "").replace(".ping ", "").strip()
        if not site:
            await m.edit_text("❌ لطفاً آدرس سایت را وارد کنید")
            command_handled = True
            return
        
        await m.edit_text(f"🔄 در حال پینگ `{site}`...")
        try:
            import subprocess
            result = subprocess.run(['ping', '-c', '4', site], capture_output=True, text=True)
            output = result.stdout
            await m.edit_text(f"📊 **نتیجه پینگ {site}:**\n```\n{output[:1000]}\n```\n| Self Ali")
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== اطلاعات آی‌پی ====================
    if text.startswith("اطلاعات آی‌پی ") or text.startswith(".ipinfo "):
        ip_address = text.replace("اطلاعات آی‌پی ", "").replace(".ipinfo ", "").strip()
        if not ip_address:
            await m.edit_text("❌ لطفاً آی‌پی را وارد کنید")
            command_handled = True
            return
        
        await m.edit_text(f"🔄 در حال دریافت اطلاعات `{ip_address}`...")
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"http://ip-api.com/json/{ip_address}") as response:
                    data = await response.json()
            
            if data.get("status") == "success":
                msg = f"🌐 **اطلاعات آی‌پی {ip_address}**\n\n"
                msg += f"📍 کشور: {data.get('country', 'نامشخص')}\n"
                msg += f"🏙 شهر: {data.get('city', 'نامشخص')}\n"
                msg += f"📡 ISP: {data.get('isp', 'نامشخص')}\n"
                msg += f"🏢 سازمان: {data.get('org', 'نامشخص')}\n"
                msg += f"🌎 منطقه: {data.get('regionName', 'نامشخص')}\n"
                msg += f"🗺 مختصات: {data.get('lat', '')}, {data.get('lon', '')}\n"
                msg += f"⏱ منطقه زمانی: {data.get('timezone', 'نامشخص')}\n"
                msg += "\n| Self Ali"
                await m.edit_text(msg)
            else:
                await m.edit_text("❌ آی‌پی نامعتبر است")
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== اسکرین‌شات از سایت ====================
    if text.startswith("اسکرین شات سایت ") or text.startswith(".screenshot "):
        url = text.replace("اسکرین شات سایت ", "").replace(".screenshot ", "").strip()
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
        
        await m.edit_text(f"🖼 در حال دریافت اسکرین‌شات از `{url}`...")
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"http://mizban-self.ir/self/py-web/shot/Sh.php?url={url}") as response:
                    data = await response.json()
            
            image_url = data.get("Link ScreenShot")
            if image_url:
                await app.send_photo(chat_id, image_url, caption=f"🌐 اسکرین‌شات {url}", reply_to_message_id=m.id)
                await m.delete()
            else:
                await m.edit_text("❌ خطا در دریافت اسکرین‌شات")
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== تاریخ ساخت اکانت ====================
    if text.startswith("تاریخ ساخت ") or text.startswith(".ci "):
        user_input = text.replace("تاریخ ساخت ", "").replace(".ci ", "").strip()
        target_id = None
        
        if user_input:
            if user_input.isdigit():
                target_id = int(user_input)
            else:
                try:
                    user = await app.get_users(user_input)
                    target_id = user.id
                except:
                    await m.edit_text("❌ کاربر یافت نشد")
                    command_handled = True
                    return
        elif reply:
            target_id = reply.from_user.id
        else:
            await m.edit_text("❌ لطفاً کاربر را مشخص کنید")
            command_handled = True
            return
        
        await m.edit_text(f"🔄 در حال دریافت تاریخ ساخت...")
        try:
            await app.unblock_user("creationdatebot")
            msg = await app.send_message("creationdatebot", f"/id {target_id}")
            await asyncio.sleep(3)
            
            async for history_msg in app.get_chat_history("creationdatebot", limit=2):
                if history_msg.id != msg.id:
                    creation_date = history_msg.text
                    break
            else:
                creation_date = "نامشخص"
            
            await m.edit_text(f"📅 تاریخ ساخت اکانت {target_id}:\n`{creation_date}`")
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== وضعیت محدودیت اکانت ====================
    if text == "وضعیت محدودیت" or text == ".limit":
        await m.edit_text("🔄 در حال بررسی وضعیت اکانت...")
        try:
            await app.unblock_user("SpamBot")
            await app.send_message("SpamBot", "/start")
            await asyncio.sleep(3)
            
            async for msg in app.get_chat_history("SpamBot", limit=2):
                if msg.text and "Good news" in msg.text:
                    status = "اکانت شما محدودیت ندارد ✅"
                    break
                elif msg.text and "bad news" in msg.text:
                    status = "اکانت شما محدودیت دارد ❌"
                    break
            else:
                status = "وضعیت نامشخص"
            
            await m.edit_text(f"📊 **وضعیت محدودیت:**\n{status}")
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== اطلاعات کشور ====================
    if text.startswith("اطلاعات کشور ") or text.startswith(".country "):
        country_name = text.replace("اطلاعات کشور ", "").replace(".country ", "").strip()
        if not country_name:
            await m.edit_text("❌ لطفاً نام کشور را وارد کنید")
            command_handled = True
            return
        
        await m.edit_text(f"🌍 در حال دریافت اطلاعات {country_name}...")
        try:
            country = CountryInfo(country_name)
            info = country.info()
            
            msg = f"🌍 **اطلاعات {info.get('name', country_name)}**\n\n"
            msg += f"🏛 پایتخت: {info.get('capital', 'نامشخص')}\n"
            msg += f"👥 جمعیت: {info.get('population', 'نامشخص'):,}\n"
            msg += f"🌎 مساحت: {info.get('area', 'نامشخص'):,} کیلومتر مربع\n"
            msg += f"🗣 زبان‌ها: {', '.join(info.get('languages', ['نامشخص']))}\n"
            msg += f"💰 واحد پول: {', '.join(info.get('currencies', ['نامشخص']))}\n"
            msg += f"📞 کد تلفن: {', '.join(info.get('callingCodes', ['نامشخص']))}\n"
            msg += f"🕒 منطقه زمانی: {', '.join(info.get('timezones', ['نامشخص']))[:50]}\n"
            msg += "\n| Self Ali"
            await m.edit_text(msg)
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== ترجمه به فارسی ====================
    if text.startswith("ترجمه به فارسی ") or text.startswith(".fa "):
        query = text.replace("ترجمه به فارسی ", "").replace(".fa ", "").strip()
        if not query:
            await m.edit_text("❌ لطفاً متن را وارد کنید")
            command_handled = True
            return
        
        await m.edit_text("🔄 در حال ترجمه...")
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"https://api.codebazan.ir/translate/?from=en&to=fa&text={query}") as response:
                    translated = await response.text()
            
            await m.edit_text(f"📝 **ترجمه به فارسی:**\n```\n{query}\n```\n➡️\n```\n{translated}\n```\n| Self Ali")
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== ترجمه به انگلیسی ====================
    if text.startswith("ترجمه به انگلیسی ") or text.startswith(".en "):
        query = text.replace("ترجمه به انگلیسی ", "").replace(".en ", "").strip()
        if not query:
            await m.edit_text("❌ لطفاً متن را وارد کنید")
            command_handled = True
            return
        
        await m.edit_text("🔄 در حال ترجمه...")
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"https://api.codebazan.ir/translate/?from=fa&to=en&text={query}") as response:
                    translated = await response.text()
            
            await m.edit_text(f"📝 **ترجمه به انگلیسی:**\n```\n{query}\n```\n➡️\n```\n{translated}\n```\n| Self Ali")
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== دانلود فیلم ====================
    if text.startswith("دانلود فیلم ") or text.startswith(".movie "):
        movie_name = text.replace("دانلود فیلم ", "").replace(".movie ", "").strip()
        if not movie_name:
            await m.edit_text("❌ لطفاً نام فیلم را وارد کنید")
            command_handled = True
            return
        
        await m.edit_text(f"🎬 در حال جستجوی فیلم `{movie_name}`...")
        try:
            # جستجو در One API
            async with aiohttp.ClientSession() as session:
                async with session.get(f"https://one-api.ir/mobomoviez/?token=257767:6565c68b902f2&action=search&q={movie_name}&page=1") as response:
                    data = await response.json()
            
            if data.get("result"):
                movie = data["result"][0]
                title = movie.get("title", movie_name)
                url = movie.get("url", "")
                poster = movie.get("poster", "")
                
                msg = f"🎬 **{title}**\n\n"
                msg += f"🔗 لینک دانلود: {url}\n"
                if poster:
                    msg += f"🖼 پوستر: {poster}\n"
                msg += "\n| Self Ali"
                await m.edit_text(msg, disable_web_page_preview=True)
            else:
                await m.edit_text("❌ فیلمی یافت نشد")
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== دانلود انیمه ====================
    if text.startswith("دانلود انیمه ") or text.startswith(".anim "):
        anime_name = text.replace("دانلود انیمه ", "").replace(".anim ", "").strip()
        if not anime_name:
            await m.edit_text("❌ لطفاً نام انیمه را وارد کنید")
            command_handled = True
            return
        
        await m.edit_text(f"🎌 در حال جستجوی انیمه `{anime_name}`...")
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"https://api.safone.dev/anime/search?query={anime_name}") as response:
                    data = await response.json()
            
            title = data.get("title", {})
            en_title = title.get("english", anime_name)
            jp_title = title.get("native", "")
            romaji = title.get("romaji", "")
            
            msg = f"🎌 **{en_title}**\n"
            if romaji:
                msg += f"📝 {romaji}\n"
            if jp_title:
                msg += f"🇯🇵 {jp_title}\n\n"
            
            msg += f"📊 امتیاز: {data.get('averageScore', 'نامشخص')}\n"
            msg += f"📺 قسمت‌ها: {data.get('episodes', 'نامشخص')}\n"
            msg += f"⏱ مدت: {data.get('duration', 'نامشخص')} دقیقه\n"
            msg += f"📅 وضعیت: {data.get('status', 'نامشخص')}\n"
            msg += f"🎭 ژانر: {', '.join(data.get('genres', ['نامشخص']))}\n\n"
            msg += f"📝 خلاصه:\n{data.get('description', '')[:200]}...\n\n"
            msg += f"🖼 پوستر: {data.get('imageUrl', '')}\n"
            msg += "\n| Self Ali"
            await m.edit_text(msg, disable_web_page_preview=True)
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== ساخت پسورد ====================
    if text.startswith("ساخت پسورد ") or text.startswith(".pass "):
        try:
            length = int(text.replace("ساخت پسورد ", "").replace(".pass ", "").strip())
            if length < 4 or length > 100:
                await m.edit_text("❌ طول پسورد باید بین 4 تا 100 باشد")
                command_handled = True
                return
        except:
            await m.edit_text("❌ لطفاً یک عدد وارد کنید")
            command_handled = True
            return
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"http://api.codebazan.ir/password/?length={length}") as response:
                    password = await response.text()
            
            await m.edit_text(f"🔐 **پسورد {length} کاراکتری:**\n`{password}`")
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== تبدیل مورس به متن ====================
    if text.startswith("مورس به متن ") or text.startswith(".unmorset "):
        morse = text.replace("مورس به متن ", "").replace(".unmorset ", "").strip()
        if not morse:
            await m.edit_text("❌ لطفاً کد مورس را وارد کنید")
            command_handled = True
            return
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"http://api.codebazan.ir/mourse/?lang=fa&mourse={morse}") as response:
                    text_result = await response.text()
            
            await m.edit_text(f"📟 **تبدیل مورس به متن:**\nکد: `{morse}`\nمتن: `{text_result}`")
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== تبدیل متن به مورس ====================
    if text.startswith("متن به مورس ") or text.startswith(".morset "):
        plain_text = text.replace("متن به مورس ", "").replace(".morset ", "").strip()
        if not plain_text:
            await m.edit_text("❌ لطفاً متن را وارد کنید")
            command_handled = True
            return
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"http://api.codebazan.ir/mourse/?lang=fa&text={plain_text}") as response:
                    morse = await response.text()
            
            await m.edit_text(f"📟 **تبدیل متن به مورس:**\nمتن: `{plain_text}`\nکد: `{morse}`")
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== دریافت تاریخ ====================
    if text == "تاریخ" or text == ".date":
        now = datetime.now()
        jdate = jdatetime.datetime.now()
        
        msg = f"📅 **تاریخ امروز**\n"
        msg += f"🌍 میلادی: {now.strftime('%Y/%m/%d')}\n"
        msg += f"🇮🇷 شمسی: {jdate.strftime('%Y/%m/%d')}\n"
        msg += f"🕒 ساعت: {now.strftime('%H:%M:%S')}"
        await m.edit_text(msg)
        command_handled = True
        return

    # ==================== دریافت اطلاعات پیام ====================
    if text == "اطلاعات پیام" and reply:
        msg = reply
        
        info = f"📊 **اطلاعات پیام**\n\n"
        info += f"🆔 آیدی پیام: `{msg.id}`\n"
        info += f"👤 فرستنده: [{msg.from_user.first_name}](tg://user?id={msg.from_user.id}) (`{msg.from_user.id}`)\n"
        if msg.chat:
            info += f"💬 چت: {msg.chat.title or msg.chat.username or msg.chat.id}\n"
        if msg.date:
            info += f"📅 تاریخ: {msg.date.strftime('%Y/%m/%d %H:%M:%S')}\n"
        if msg.media:
            info += f"📎 مدیا: {msg.media.value}\n"
        if msg.caption:
            info += f"📝 کپشن: {msg.caption[:100]}\n"
        
        await m.edit_text(info)
        command_handled = True
        return

    # ==================== منشن کاربر ====================
    if text == "منشن" and reply:
        user = reply.from_user
        await m.edit_text(f"[{user.first_name}](tg://user?id={user.id})", disable_web_page_preview=True)
        command_handled = True
        return

    # ==================== بررسی کد ملی ====================
    if text.startswith("بررسی کد ملی ") or text.startswith(".meli "):
        code = text.replace("بررسی کد ملی ", "").replace(".meli ", "").strip()
        if not code.isdigit() or len(code) != 10:
            await m.edit_text("❌ کد ملی باید 10 رقم باشد")
            command_handled = True
            return
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"https://api.codebazan.ir/codemelli/?code={code}") as response:
                    result = await response.json()
            
            status = "✅ معتبر" if "valid" in str(result).lower() else "❌ نامعتبر"
            await m.edit_text(f"🆔 **بررسی کد ملی {code}**\nنتیجه: {status}")
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== استعلام کارت بانکی ====================
    if text.startswith("استعلام کارت ") or text.startswith(".estelam "):
        card = text.replace("استعلام کارت ", "").replace(".estelam ", "").strip()
        if not card.isdigit() or len(card) != 16:
            await m.edit_text("❌ شماره کارت باید 16 رقم باشد")
            command_handled = True
            return
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"https://my.tabdilcard.com/api/api/v1/provider/preview?number={card}&type=2&bank=017") as response:
                    data = await response.json()
            
            name = data.get("name", "نامشخص")
            bank = data.get("bankname", "نامشخص")
            
            await m.edit_text(f"💳 **اطلاعات کارت {card}**\n\n👤 نام: {name}\n🏦 بانک: {bank}\n\n| Self Ali")
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== دانلود از اینستاگرام ====================
    if text.startswith("دانلود اینستا ") or text.startswith(".insta "):
        url = text.replace("دانلود اینستا ", "").replace(".insta ", "").strip()
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
        
        await m.edit_text("📸 در حال دانلود از اینستاگرام...")
        try:
            # استفاده از API جدید MajidAPI
            async with aiohttp.ClientSession() as session:
                async with session.get(f"https://api.majidapi.ir/instagram/download?url={url}") as response:
                    data = await response.json()
            
            if data.get("status") == "success":
                result = data.get("result", {})
                media_type = result.get("type", "unknown")
                media_url = result.get("url", "")
                caption = result.get("caption", "")
                
                if media_url:
                    if media_type == "video":
                        await app.send_video(chat_id, media_url, caption=caption[:200] if caption else "📸 ویدیو از اینستاگرام")
                    else:
                        await app.send_photo(chat_id, media_url, caption=caption[:200] if caption else "📸 عکس از اینستاگرام")
                    await m.delete()
                else:
                    await m.edit_text("❌ لینک دانلود یافت نشد")
            else:
                # Fallback به API قبلی
                await m.edit_text("❌ خطا در دانلود از اینستاگرام")
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== استخراج متن از عکس (OCR) ====================
    if text == "استخراج متن" and reply and reply.photo:
        await m.edit_text("🔄 در حال استخراج متن از عکس...")
        try:
            # ارسال عکس به ربات GoogleBot
            await app.unblock_user("@oneGooglebot")
            sent = await app.send_photo("@oneGooglebot", reply.photo.file_id)
            await asyncio.sleep(5)
            
            async for msg in app.get_chat_history("@oneGooglebot", limit=2):
                if msg.id != sent.id and msg.text and "OCR detected" in msg.text:
                    ocr_text = msg.text.replace("💭 OCR detected:", "").strip()
                    break
            else:
                ocr_text = "متن تشخیص داده نشد"
            
            await m.edit_text(f"📝 **متن استخراج شده:**\n```\n{ocr_text}\n```\n| Self Ali")
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== ساخت گیف ====================
    if text == "ساخت گیف" and reply and reply.video:
        await m.edit_text("🎞 در حال ساخت گیف...")
        try:
            video_path = await app.download_media(reply)
            
            # تبدیل ویدیو به گیف با ffmpeg
            gif_path = "output.gif"
            cmd = f"ffmpeg -i {video_path} -vf 'fps=10,scale=320:-1' -loop 0 {gif_path}"
            await run_cmd(cmd)
            
            await app.send_animation(chat_id, gif_path, caption="🎬 گیف ساخته شده", reply_to_message_id=m.id)
            
            os.remove(video_path)
            os.remove(gif_path)
            await m.delete()
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== فیلم به گیف ====================
    if text.startswith("فیلم به گیف ") and reply and reply.video:
        try:
            duration = int(text.replace("فیلم به گیف ", "").strip())
            if duration < 1 or duration > 10:
                duration = 5
        except:
            duration = 5
        
        await m.edit_text(f"🎞 در حال تبدیل فیلم به گیف (بازه {duration} ثانیه)...")
        try:
            video_path = await app.download_media(reply)
            
            gif_path = "output.gif"
            cmd = f"ffmpeg -i {video_path} -t {duration} -vf 'fps=10,scale=320:-1' -loop 0 {gif_path}"
            await run_cmd(cmd)
            
            await app.send_animation(chat_id, gif_path, caption=f"🎬 گیف {duration} ثانیه‌ای", reply_to_message_id=m.id)
            
            os.remove(video_path)
            os.remove(gif_path)
            await m.delete()
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== ساخت استیکر ====================
    if text == "ساخت استیکر" and reply and reply.photo:
        await m.edit_text("🖼 در حال ساخت استیکر...")
        try:
            photo_path = await app.download_media(reply)
            
            # تغییر اندازه به 512x512
            img = Image.open(photo_path)
            img.thumbnail((512, 512), Image.Resampling.LANCZOS)
            
            sticker_path = "sticker.webp"
            img.save(sticker_path, 'WEBP')
            
            await app.send_sticker(chat_id, sticker_path, reply_to_message_id=m.id)
            
            os.remove(photo_path)
            os.remove(sticker_path)
            await m.delete()
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== هوش مصنوعی ====================
    if text.startswith("هوش مصنوعی "):
        query = text[11:].strip()
        if not query:
            await m.edit_text("❌ لطفاً متن را وارد کنید")
            command_handled = True
            return
        
        await m.edit_text("🤖 در حال دریافت پاسخ از هوش مصنوعی...")
        try:
            # استفاده از API جدید MajidAPI
            async with aiohttp.ClientSession() as session:
                async with session.get(f"https://api.majidapi.ir/gpt/3?q={query}") as response:
                    data = await response.json()
            
            if data.get("status") == "success":
                answer = data.get("result", "پاسخی یافت نشد")
            else:
                # Fallback به API قبلی
                async with aiohttp.ClientSession() as session:
                    async with session.get(f"https://mionapi.ir/api/ai/soozan.php?q={query}") as response:
                        answer = await response.text()
            
            # ذخیره پاسخ در فایل awnser
            os.makedirs("awnser", exist_ok=True)
            with open("awnser/last_response.txt", "w", encoding="utf-8") as f:
                f.write(answer)
            
            await m.edit_text(f"🤖 **پاسخ هوش مصنوعی:**\n```\n{answer}\n```\n| Self Ali")
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== هوش مصنوعی (با ریپلای) ====================
    if text == "هوش مصنوعی" and reply and reply.text:
        query = reply.text
        await m.edit_text("🤖 در حال دریافت پاسخ از هوش مصنوعی...")
        try:
            # استفاده از API جدید MajidAPI
            async with aiohttp.ClientSession() as session:
                async with session.get(f"https://api.majidapi.ir/gpt/3?q={query}") as response:
                    data = await response.json()
            
            if data.get("status") == "success":
                answer = data.get("result", "پاسخی یافت نشد")
            else:
                # Fallback به API قبلی
                async with aiohttp.ClientSession() as session:
                    async with session.get(f"https://mionapi.ir/api/ai/soozan.php?q={query}") as response:
                        answer = await response.text()
            
            # ذخیره پاسخ در فایل awnser
            os.makedirs("awnser", exist_ok=True)
            with open("awnser/last_response.txt", "w", encoding="utf-8") as f:
                f.write(answer)
            
            await m.edit_text(f"🤖 **پاسخ هوش مصنوعی:**\n```\n{answer}\n```\n| Self Ali")
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== جق (کوس) ====================
    elif text == "جق" or text == "kocok":
        e = await edit_or_reply(m, "8✊===D")
        await e.edit("8=✊==D")
        await e.edit("8==✊=D")
        await e.edit("8===✊D")
        await e.edit("8==✊=D")
        await e.edit("8=✊==D")
        await e.edit("8✊===D")
        await e.edit("8===✊D💦")
        await e.edit("8==✊=D💦💦")
        await e.edit("8=✊==D💦💦💦")
        await e.edit("8✊===D💦💦💦💦")
        await e.edit("8===✊D💦💦💦💦💦")
        await e.edit("8==✊=D💦💦💦💦💦💦")
        await e.edit("8=✊==D💦💦💦💦💦💦💦")
        await e.edit("8✊===D💦💦💦💦💦💦💦💦")
        await e.edit("اخ کی.روم شیکس")
        command_handled = True
        return

    # ==================== قفل استیکر ====================
    elif text == "قفل استیکر روشن":
        lock_data["sticker"]["enabled"] = True
        if chat_type == ChatType.PRIVATE:
            lock_data["sticker"]["pvs"] = True
            await m.edit_text("✅ قفل استیکر در پیوی روشن شد")
        elif chat_type in [ChatType.GROUP, ChatType.SUPERGROUP]:
            if await is_admin_cached(chat_id):
                lock_data["sticker"]["groups"][str(chat_id)] = True
                await m.edit_text("✅ قفل استیکر در گروه روشن شد")
            else:
                await m.edit_text("❌ شما ادمین نیستید")
        save_data(LOCK_FILE, lock_data)
        command_handled = True
        return
    
    elif text == "قفل استیکر خاموش":
        if chat_type == ChatType.PRIVATE:
            lock_data["sticker"]["pvs"] = False
            await m.edit_text("✅ قفل استیکر در پیوی خاموش شد")
        elif chat_type in [ChatType.GROUP, ChatType.SUPERGROUP]:
            if await is_admin_cached(chat_id):
                lock_data["sticker"]["groups"][str(chat_id)] = False
                await m.edit_text("✅ قفل استیکر در گروه خاموش شد")
            else:
                await m.edit_text("❌ شما ادمین نیستید")
        save_data(LOCK_FILE, lock_data)
        command_handled = True
        return

    # ==================== قفل گیف ====================
    elif text == "قفل گیف روشن":
        lock_data["gif"]["enabled"] = True
        if chat_type == ChatType.PRIVATE:
            lock_data["gif"]["pvs"] = True
            await m.edit_text("✅ قفل گیف در پیوی روشن شد")
        elif chat_type in [ChatType.GROUP, ChatType.SUPERGROUP]:
            if await is_admin_cached(chat_id):
                lock_data["gif"]["groups"][str(chat_id)] = True
                await m.edit_text("✅ قفل گیف در گروه روشن شد")
            else:
                await m.edit_text("❌ شما ادمین نیستید")
        save_data(LOCK_FILE, lock_data)
        command_handled = True
        return
    
    elif text == "قفل گیف خاموش":
        if chat_type == ChatType.PRIVATE:
            lock_data["gif"]["pvs"] = False
            await m.edit_text("✅ قفل گیف در پیوی خاموش شد")
        elif chat_type in [ChatType.GROUP, ChatType.SUPERGROUP]:
            if await is_admin_cached(chat_id):
                lock_data["gif"]["groups"][str(chat_id)] = False
                await m.edit_text("✅ قفل گیف در گروه خاموش شد")
            else:
                await m.edit_text("❌ شما ادمین نیستید")
        save_data(LOCK_FILE, lock_data)
        command_handled = True
        return

    # ==================== قفل فوروارد ====================
    elif text == "قفل فوروارد روشن":
        lock_data["forward"]["enabled"] = True
        if chat_type == ChatType.PRIVATE:
            lock_data["forward"]["pvs"] = True
            await m.edit_text("✅ قفل فوروارد در پیوی روشن شد")
        elif chat_type in [ChatType.GROUP, ChatType.SUPERGROUP]:
            if await is_admin_cached(chat_id):
                lock_data["forward"]["groups"][str(chat_id)] = True
                await m.edit_text("✅ قفل فوروارد در گروه روشن شد")
            else:
                await m.edit_text("❌ شما ادمین نیستید")
        save_data(LOCK_FILE, lock_data)
        command_handled = True
        return
    
    elif text == "قفل فوروارد خاموش":
        if chat_type == ChatType.PRIVATE:
            lock_data["forward"]["pvs"] = False
            await m.edit_text("✅ قفل فوروارد در پیوی خاموش شد")
        elif chat_type in [ChatType.GROUP, ChatType.SUPERGROUP]:
            if await is_admin_cached(chat_id):
                lock_data["forward"]["groups"][str(chat_id)] = False
                await m.edit_text("✅ قفل فوروارد در گروه خاموش شد")
            else:
                await m.edit_text("❌ شما ادمین نیستید")
        save_data(LOCK_FILE, lock_data)
        command_handled = True
        return

    # ==================== قفل لینک ====================
    elif text == "قفل لینک روشن":
        lock_data["link"]["enabled"] = True
        if chat_type == ChatType.PRIVATE:
            lock_data["link"]["pvs"] = True
            await m.edit_text("✅ قفل لینک در پیوی روشن شد")
        elif chat_type in [ChatType.GROUP, ChatType.SUPERGROUP]:
            if await is_admin_cached(chat_id):
                lock_data["link"]["groups"][str(chat_id)] = True
                await m.edit_text("✅ قفل لینک در گروه روشن شد")
            else:
                await m.edit_text("❌ شما ادمین نیستید")
        save_data(LOCK_FILE, lock_data)
        command_handled = True
        return
    
    elif text == "قفل لینک خاموش":
        if chat_type == ChatType.PRIVATE:
            lock_data["link"]["pvs"] = False
            await m.edit_text("✅ قفل لینک در پیوی خاموش شد")
        elif chat_type in [ChatType.GROUP, ChatType.SUPERGROUP]:
            if await is_admin_cached(chat_id):
                lock_data["link"]["groups"][str(chat_id)] = False
                await m.edit_text("✅ قفل لینک در گروه خاموش شد")
            else:
                await m.edit_text("❌ شما ادمین نیستید")
        save_data(LOCK_FILE, lock_data)
        command_handled = True
        return

    # ==================== قفل عکس ====================
    elif text == "قفل عکس روشن":
        lock_data["photo"]["enabled"] = True
        if chat_type == ChatType.PRIVATE:
            lock_data["photo"]["pvs"] = True
            await m.edit_text("✅ قفل عکس در پیوی روشن شد")
        elif chat_type in [ChatType.GROUP, ChatType.SUPERGROUP]:
            if await is_admin_cached(chat_id):
                lock_data["photo"]["groups"][str(chat_id)] = True
                await m.edit_text("✅ قفل عکس در گروه روشن شد")
            else:
                await m.edit_text("❌ شما ادمین نیستید")
        save_data(LOCK_FILE, lock_data)
        command_handled = True
        return
    
    elif text == "قفل عکس خاموش":
        if chat_type == ChatType.PRIVATE:
            lock_data["photo"]["pvs"] = False
            await m.edit_text("✅ قفل عکس در پیوی خاموش شد")
        elif chat_type in [ChatType.GROUP, ChatType.SUPERGROUP]:
            if await is_admin_cached(chat_id):
                lock_data["photo"]["groups"][str(chat_id)] = False
                await m.edit_text("✅ قفل عکس در گروه خاموش شد")
            else:
                await m.edit_text("❌ شما ادمین نیستید")
        save_data(LOCK_FILE, lock_data)
        command_handled = True
        return

    # ==================== قفل ریپلای ====================
    elif text == "قفل ریپلای روشن":
        lock_data["reply"]["enabled"] = True
        if chat_type == ChatType.PRIVATE:
            lock_data["reply"]["pvs"] = True
            await m.edit_text("✅ قفل ریپلای در پیوی روشن شد")
        elif chat_type in [ChatType.GROUP, ChatType.SUPERGROUP]:
            if await is_admin_cached(chat_id):
                lock_data["reply"]["groups"][str(chat_id)] = True
                await m.edit_text("✅ قفل ریپلای در گروه روشن شد")
            else:
                await m.edit_text("❌ شما ادمین نیستید")
        save_data(LOCK_FILE, lock_data)
        command_handled = True
        return
    
    elif text == "قفل ریپلای خاموش":
        if chat_type == ChatType.PRIVATE:
            lock_data["reply"]["pvs"] = False
            await m.edit_text("✅ قفل ریپلای در پیوی خاموش شد")
        elif chat_type in [ChatType.GROUP, ChatType.SUPERGROUP]:
            if await is_admin_cached(chat_id):
                lock_data["reply"]["groups"][str(chat_id)] = False
                await m.edit_text("✅ قفل ریپلای در گروه خاموش شد")
            else:
                await m.edit_text("❌ شما ادمین نیستید")
        save_data(LOCK_FILE, lock_data)
        command_handled = True
        return

    # ==================== حالت انلاینی ====================
    elif text == "انلاینی روشن":
        config["online_mode"] = "on"
        save_data(CONFIG_FILE, config)
        try:
            await app.invoke(raw.functions.account.UpdateStatus(offline=False))
        except:
            pass
        await m.edit_text("✅ حالت انلاینی روشن شد")
        command_handled = True
        return
    
    elif text == "انلاینی خاموش":
        config["online_mode"] = "off"
        save_data(CONFIG_FILE, config)
        await m.edit_text("✅ حالت انلاینی خاموش شد")
        command_handled = True
        return

    # ==================== حذف پیام انبوه ====================
    elif text.startswith("حذف "):
        try:
            parts = text.split()
            if len(parts) == 2 and parts[1].isdigit():
                count = int(parts[1])
                if count <= 0:
                    await m.edit_text("❌ تعداد باید بزرگتر از صفر باشد")
                    command_handled = True
                    return
                
                deleted_count = 0
                is_admin = await is_admin_cached(chat_id) if chat_type in [ChatType.GROUP, ChatType.SUPERGROUP] else True
                
                async for msg in app.get_chat_history(chat_id, limit=count+1):
                    if msg.id == m.id:
                        continue
                    
                    if chat_type in [ChatType.GROUP, ChatType.SUPERGROUP]:
                        if is_admin:
                            try:
                                await msg.delete()
                                deleted_count += 1
                            except:
                                pass
                        else:
                            if msg.from_user and msg.from_user.id == me_id:
                                try:
                                    await msg.delete()
                                    deleted_count += 1
                                except:
                                    pass
                    else:
                        try:
                            await msg.delete()
                            deleted_count += 1
                        except:
                            pass
                    
                    if deleted_count >= count:
                        break
                
                await m.edit_text(f"🗑 تعداد {deleted_count} پیام حذف شد")
                command_handled = True
                return
        except Exception as e:
            await m.edit_text(f"❌ خطا در حذف پیام: {str(e)[:50]}")
            command_handled = True
            return
    
    # ==================== حذف با ریپلای ====================
    elif reply and text == "حذف":
        try:
            await reply.delete()
            await m.delete()
            command_handled = True
            return
        except Exception as e:
            await m.edit_text(f"❌ خطا در حذف: {str(e)[:50]}")
            command_handled = True
            return

    # ==================== آنتی لاگین ====================
    elif text == "ضد لاگین روشن":
        antilog_data["enabled"] = True
        save_data(ANTILOG_FILE, antilog_data)
        await m.edit_text("✅ ضد لاگین فعال شد")
        command_handled = True
        return
    
    elif text == "ضد لاگین خاموش":
        antilog_data["enabled"] = False
        save_data(ANTILOG_FILE, antilog_data)
        await m.edit_text("✅ ضد لاگین غیرفعال شد")
        command_handled = True
        return

    # ==================== کلون ====================
    elif text == "کلون":
        try:
            if not m.reply_to_message:
                await m.edit_text("❌ لطفاً روی پیام کاربری که می‌خواهید کلون کنید ریپلای کنید")
                command_handled = True
                return
            
            user = m.reply_to_message.from_user
            if not user:
                await m.edit_text("❌ کاربر یافت نشد")
                command_handled = True
                return
            
            b = await app.invoke(raw.functions.users.GetFullUser(id=await app.resolve_peer(user.id)))
            
            await m.edit_text(f"""
**کپی پروفایل**
❖ `نام`⤳ (`{b.users[0].first_name if b.users[0].first_name else '--'}`)
❖ `نام خانوادگی`⤳ (`{(b.users[0].last_name if b.users[0].last_name else '--')}`)
❖ `بیوگرافی`⤳ (`{(b.full_user.about if b.full_user.about else '--')}`)""")
            
            if user.photo:
                try:
                    photos = await app.get_chat_photos(user.id, limit=1)
                    if photos:
                        photo_file = await app.download_media(photos[0].file_id)
                        
                        try:
                            my_photos = await app.get_chat_photos("me", limit=1)
                            if my_photos:
                                await app.delete_profile_photos(my_photos[0].file_id)
                        except:
                            pass
                        
                        await app.set_profile_photo(photo=photo_file)
                        os.remove(photo_file)
                except:
                    pass
            
            await app.update_profile(first_name=b.users[0].first_name)
            await app.update_profile(last_name=(b.users[0].last_name if b.users[0].last_name else ""))
            await app.update_profile(bio=(b.full_user.about if b.full_user.about else ""))
            
            await m.edit_text("❖ Clone Successfully Completed")
            command_handled = True
            return
            
        except errors.exceptions.bad_request_400.UsernameNotOccupied: 
            await m.edit_text(f"❖ Username Not Valid ❖") 
        except Exception as er:
            await m.edit_text(f"❖ **ERROR** :\n(`{er}`)")
        command_handled = True
        return

    # ==================== بلاک و انبلاک ====================
    elif reply and reply.from_user and reply.from_user.id != me_id:
        if text == "بلاک":
            try:
                await app.block_user(reply.from_user.id)
                await m.edit_text("کاربر با موفقیت بلاک شد ✅")
                command_handled = True
                return
            except Exception as e:
                await m.edit_text(f"❌ خطا در بلاک: {str(e)[:50]}")
                command_handled = True
                return
        elif text == "انبلاک":
            try:
                await app.unblock_user(reply.from_user.id)
                await m.edit_text("کاربر با موفقیت انبلاک شد ✔️")
                command_handled = True
                return
            except Exception as e:
                await m.edit_text(f"❌ خطا در انبلاک: {str(e)[:50]}")
                command_handled = True
                return

    # ذخیره تایمی
    elif text == "ذخیره تایمی روشن":
        time_save["enabled"] = True
        save_data(TIME_SAVE_FILE, time_save)
        await m.edit_text("✅ ذخیره تایمی روشن شد")
        command_handled = True
        return
        
    elif text == "ذخیره تایمی خاموش":
        time_save["enabled"] = False
        save_data(TIME_SAVE_FILE, time_save)
        await m.edit_text("✅ ذخیره تایمی خاموش شد")
        command_handled = True
        return

    # فیلتر کلمات
    if "فیلتر کلمات روشن" in text:
        if not filter_data["enabled"]:
            filter_data["enabled"] = True
            save_data(FILTER_FILE, filter_data)
            await m.edit_text("فیلتر کلمات روشن شد")
        else:
            await m.edit_text("⚠️ فیلتر کلمات قبلاً روشن است")
        command_handled = True
        return
    elif "فیلتر کلمات خاموش" in text:
        if filter_data["enabled"]:
            filter_data["enabled"] = False
            save_data(FILTER_FILE, filter_data)
            await m.edit_text("فیلتر کلمات خاموش شد")
        else:
            await m.edit_text("⚠️ فیلتر کلمات قبلاً خاموش است")
        command_handled = True
        return
    elif text.startswith("فیلتر کلمه "):
        word = text[10:].strip()
        if word:
            if word not in filter_data["words"]:
                filter_data["words"].append(word)
                save_data(FILTER_FILE, filter_data)
                await m.edit_text(f"کلمه [{word}] فیلتر شد")
            else:
                await m.edit_text(f"⚠️ کلمه [{word}] قبلاً فیلتر شده")
        else:
            await m.edit_text("❌ کلمه خالی است")
        command_handled = True
        return
    elif "لیست فیلتر" in text:
        if not filter_data["words"]:
            await m.edit_text("لیست فیلتر خالی میباشد")
        else:
            list_str = "\n".join([f"- {w}" for w in filter_data["words"]])
            await m.edit_text(f"لیست فیلتر :\n{list_str}")
        command_handled = True
        return
    elif text.startswith("حذف فیلتر "):
        word = text[9:].strip()
        if word in filter_data["words"]:
            filter_data["words"].remove(word)
            save_data(FILTER_FILE, filter_data)
            await m.edit_text("حذف شد")
        else:
            await m.edit_text("❌ کلمه در لیست فیلتر نیست")
        command_handled = True
        return
    elif "پاکسازی کلمات فیلتر" in text:
        count = len(filter_data["words"])
        filter_data["words"].clear()
        save_data(FILTER_FILE, filter_data)
        if count == 0:
            await m.edit_text("لیست فیلتر قبلاً خالی است")
        else:
            await m.edit_text(f"لیست فیلتر پاک شد ({count} مورد)")
        command_handled = True
        return

    # ==================== دستورات منشی (از سورس سوم) ====================
    elif text == "منشی روشن":
        config["secretary_on"] = "on"
        save_data(CONFIG_FILE, config)
        await m.edit_text("🤖 منشی پیوی روشن شد")
        command_handled = True
        return
    elif text == "منشی خاموش":
        config["secretary_on"] = "off"
        save_data(CONFIG_FILE, config)
        await m.edit_text("🤖 منشی پیوی خاموش شد")
        command_handled = True
        return
    elif text.startswith("متن منشی "):
        text_part = text[8:].strip()
        if text_part:
            config["secretary_text"] = text_part
            save_data(CONFIG_FILE, config)
            await m.edit_text("📝 متن منشی ذخیره شد")
        else:
            await m.edit_text("❌ متن خالی است! متن منشی [متن مورد نظر]")
        command_handled = True
        return

    # ==================== دستورات سکوت (از سورس سوم) ====================
    elif reply and text == "سکوت":
        if chat_type == ChatType.PRIVATE:
            if user_id not in mutes["pvs"]:
                mutes["pvs"].append(user_id)
                save_data(MUTE_FILE, mutes)
                name = reply.from_user.first_name or ""
                await m.edit_text(f"🔇 به سکوت اضافه شد: {name}")
        elif await is_admin_cached(chat_id):
            if chat_id not in mutes["groups"]:
                mutes["groups"][chat_id] = []
            if user_id not in mutes["groups"][chat_id]:
                mutes["groups"][chat_id].append(user_id)
                save_data(MUTE_FILE, mutes)
                name = reply.from_user.first_name or ""
                await m.edit_text(f"🔇 به سکوت اضافه شد: {name}")
        command_handled = True
        return

    elif reply and text == "حذف سکوت":
        if chat_type == ChatType.PRIVATE:
            if user_id in mutes["pvs"]:
                mutes["pvs"].remove(user_id)
                save_data(MUTE_FILE, mutes)
                name = reply.from_user.first_name or ""
                await m.edit_text(f"🔈 از سکوت خارج شد: {name}")
        elif await is_admin_cached(chat_id):
            if chat_id in mutes["groups"] and user_id in mutes["groups"][chat_id]:
                mutes["groups"][chat_id].remove(user_id)
                save_data(MUTE_FILE, mutes)
                name = reply.from_user.first_name or ""
                await m.edit_text(f"🔈 از سکوت خارج شد: {name}")
        command_handled = True
        return

    elif text == "پاکسازی لیست سکوت":
        mutes["pvs"] = []
        mutes["groups"] = {}
        save_data(MUTE_FILE, mutes)
        await m.edit_text("🧹 لیست سکوت پاک شد")
        command_handled = True
        return

    elif text == "لیست سکوت":
        list_str = ", ".join(map(str, mutes["pvs"])) if mutes["pvs"] else "خالی"
        await m.edit_text(f"🔇 لیست سکوت: {list_str}")
        command_handled = True
        return

    # ==================== دستورات ریکت (از سورس سوم) ====================
    elif text == "ریکت روشن":
        config["auto_react"] = "on"
        save_data(CONFIG_FILE, config)
        await m.edit_text("✅ ریکت خودکار روشن شد")
        command_handled = True
        return

    elif text == "ریکت خاموش":
        config["auto_react"] = "off"
        save_data(CONFIG_FILE, config)
        await m.edit_text("❌ ریکت خودکار خاموش شد")
        command_handled = True
        return

    elif reply and re.match(r"ریکت\s+(.+)", text):
        emoji = re.match(r"ریکت\s+(.+)", text).group(1).strip()
        reactions[user_id] = emoji
        save_data(REACTION_FILE, reactions)
        name = reply.from_user.first_name or ""
        await m.edit_text(f"🔧 ریکت {emoji} برای {name} تنظیم شد")
        command_handled = True
        return

    elif reply and text == "حذف ریکت":
        if user_id in reactions:
            del reactions[user_id]
            save_data(REACTION_FILE, reactions)
            name = reply.from_user.first_name or ""
            await m.edit_text(f"🗑 ریکت {name} حذف شد")
        command_handled = True
        return

    elif text == "لیست ریکت":
        if not reactions:
            await m.edit_text("📭 لیست ریکت خالی است")
        else:
            list_str = ", ".join([f"{k} → {v}" for k, v in reactions.items()])
            await m.edit_text(f"📌 لیست ریکت‌ها: {list_str}")
        command_handled = True
        return

    elif text == "پاکسازی لیست ریکت":
        reactions.clear()
        save_data(REACTION_FILE, reactions)
        await m.edit_text("🧹 لیست ریکت پاکسازی شد")
        command_handled = True
        return

    # ==================== تبچی دستورات (از سورس سوم) ====================
    elif "تبچی روشن" in text:
        if not tabchi_enabled:
            tabchi_enabled = True
            for bid in list(banners.keys()):
                if bid not in active_tasks:
                    task = asyncio.create_task(banner_sender(bid))
                    active_tasks[bid] = task
            await m.edit_text("📣 تبچی روشن شد")
        else:
            await m.edit_text("⚠️ تبچی قبلاً روشن است")
        command_handled = True
        return
    
    elif "تبچی خاموش" in text:
        if tabchi_enabled:
            tabchi_enabled = False
            for task in list(active_tasks.values()):
                task.cancel()
            active_tasks.clear()
            await m.edit_text("🔕 تبچی خاموش شد")
        else:
            await m.edit_text("⚠️ تبچی قبلاً خاموش است")
        command_handled = True
        return
    
    elif text.startswith("بنر ") and reply:
        if len(words) < 2:
            await m.edit_text("❌ فرمت: بنر <ثانیه> [کپی|فور|فوروارد]")
            command_handled = True
            return
        try:
            interval = int(words[1])
            if interval <= 0:
                raise ValueError
            umode = words[2] if len(words) > 2 else 'کپی'
            if umode not in ['کپی', 'فور', 'فوروارد']:
                umode = 'کپی'
            mode = 'copy' if umode == 'کپی' else 'forward'
            banner_id = banner_id_counter + 1
            banners[banner_id] = {
                'chat_id': chat_id,
                'orig_msg_id': reply.id,
                'interval': interval,
                'mode': mode
            }
            banner_id_counter = banner_id
            save_data(BANNERS_FILE, banners)
            if tabchi_enabled:
                task = asyncio.create_task(banner_sender(banner_id))
                active_tasks[banner_id] = task
            mtext = 'کپی' if mode == 'copy' else 'فوروارد'
            await m.edit_text(f"✅ بنر #{banner_id} افزوده شد (هر {interval}s) [حالت: {mtext}]")
        except ValueError:
            await m.edit_text("❌ زمان باید عدد مثبت باشد")
        command_handled = True
        return
    
    elif "لیست بنر" in text:
        if not banners:
            await m.edit_text("هیچ بنری ثبت نشده")
            command_handled = True
            return
        chat_banners = defaultdict(list)
        for bid, b in banners.items():
            chat_banners[b['chat_id']].append(bid)
        list_text = "📋 لیست بنرها:\n"
        for cid, bids in chat_banners.items():
            try:
                entity = await app.get_chat(cid)
                title = entity.title if hasattr(entity, 'title') and entity.title else (entity.username if hasattr(entity, 'username') else f"چت {cid}")
            except:
                title = f"چت {cid}"
            list_text += f"📌 {title}\n"
            for bid in sorted(bids):
                b = banners[bid]
                mtext = 'کپی' if b['mode'] == 'copy' else 'فوروارد'
                list_text += f"• بنر #{bid} | فاصله: {b['interval']}s | حالت: {mtext}\n"
            list_text += "\n"
        await m.edit_text(list_text + "| Self Ali")
        command_handled = True
        return
    
    elif "پاکسازی بنر چت" in text:
        count = 0
        to_remove = []
        for bid, b in banners.items():
            if b['chat_id'] == chat_id:
                to_remove.append(bid)
        for bid in to_remove:
            if bid in active_tasks:
                active_tasks[bid].cancel()
                del active_tasks[bid]
            del banners[bid]
            count += 1
        save_data(BANNERS_FILE, banners)
        if count > 0:
            await m.edit_text(f"🧹 {count} بنر از این گفتگو پاک شد")
        else:
            await m.edit_text("هیچ بنری در این گفتگو نبود")
        command_handled = True
        return
    
    elif "پاکسازی کل تبچی" in text:
        count = len(banners)
        for task in list(active_tasks.values()):
            task.cancel()
        active_tasks.clear()
        banners.clear()
        tabchi_enabled = False
        banner_id_counter = 0
        save_data(BANNERS_FILE, banners)
        await m.edit_text(f"🧹 {count} بنر پاک شد | تبچی خاموش شد" if count > 0 else "🧹 تبچی خاموش شد")
        command_handled = True
        return
    
    elif words and words[0] == "پاک" and "بنر" in words:
        if len(words) >= 4 and words[1] == "کردن" and words[2] == "بنر" and words[3].isdigit():
            bid = int(words[3])
            if bid in banners:
                if bid in active_tasks:
                    active_tasks[bid].cancel()
                    del active_tasks[bid]
                del banners[bid]
                save_data(BANNERS_FILE, banners)
                await m.edit_text(f"🗑️ بنر #{bid} حذف شد")
            else:
                await m.edit_text("❌ بنر یافت نشد")
            command_handled = True
            return
    
    elif words and words[0] == "حالت" and "بنر" in words:
        if len(words) >= 4 and words[1] == "بنر" and words[2].isdigit():
            bid = int(words[2])
            umode = words[3] if len(words) > 3 else None
            if umode and umode not in ['کپی', 'فور', 'فوروارد']:
                umode = None
            if umode:
                mode = 'copy' if umode == 'کپی' else 'forward'
                if bid in banners:
                    banners[bid]['mode'] = mode
                    save_data(BANNERS_FILE, banners)
                    mtext = 'کپی' if mode == 'copy' else 'فوروارد'
                    await m.edit_text(f"☄️ حالت بنر #{bid} به {mtext} تنظیم شد")
                    command_handled = True
                    return
            await m.edit_text("❌ فرمت: حالت بنر <id> [کپی|فور|فوروارد]")
            command_handled = True
            return

    # ==================== اکشن ====================
    elif text == "اکشن روشن":
        config["action_mode"] = "on"
        save_data(CONFIG_FILE, config)
        await m.edit_text("✅ حالت اکشن روشن شد")
        command_handled = True
        return
    elif text == "اکشن خاموش":
        config["action_mode"] = "off"
        save_data(CONFIG_FILE, config)
        await m.edit_text("❌ حالت اکشن خاموش شد")
        command_handled = True
        return
    elif text.startswith("حالت اکشن "):
        action_type = text[10:].strip()
        valid_actions = ["تایپ", "ویس", "ویدیو", "عکس", "سند", "استیکر", "بازی"]
        if action_type in valid_actions:
            action_map = {
                "تایپ": "typing",
                "ویس": "voice",
                "ویدیو": "video",
                "عکس": "photo",
                "سند": "document",
                "استیکر": "sticker",
                "بازی": "game"
            }
            config["action_type"] = action_map[action_type]
            save_data(CONFIG_FILE, config)
            await m.edit_text(f"👾 حالت اکشن {action_type} انتخاب شد")
        else:
            await m.edit_text("❌ نوع اکشن نامعتبر. موارد مجاز: تایپ, ویس, ویدیو, عکس, سند, استیکر, بازی")
        command_handled = True
        return

    # ==================== ساعت بیو ====================
    elif text == "ساعت بیو روشن":
        config["clock_bio"] = "on"
        save_data(CONFIG_FILE, config)
        me = await app.get_me()
        if not config.get("original_bio"):
            config["original_bio"] = me.bio or ""
            save_data(CONFIG_FILE, config)
        await m.edit_text("📝 ساعت در بیو روشن شد")
        command_handled = True
        return
    elif text == "ساعت بیو خاموش":
        config["clock_bio"] = "off"
        save_data(CONFIG_FILE, config)
        try:
            original_bio = config.get("original_bio", "")
            await app.update_profile(bio=original_bio or None)
        except:
            pass
        await m.edit_text("📝 ساعت در بیو خاموش شد")
        command_handled = True
        return
    elif text.startswith("ثبت بیو "):
        bio_text = text[7:].strip()
        if bio_text:
            config["bio_text"] = bio_text
            save_data(CONFIG_FILE, config)
            if config.get("clock_bio") == "on":
                await TimeBio()
            await m.edit_text("متن بیوگرافی شما ثبت شد")
        else:
            await m.edit_text("❌ متن خالی است! ثبت بیو [متن]")
        command_handled = True
        return

    # ==================== فونت ساعت ====================
    elif text.startswith("فونت ساعت "):
        font_str = text[10:].strip()
        if font_str.lower() == "random":
            config["clock_font"] = random.randint(1, 49)
            save_data(CONFIG_FILE, config)
            sample = format_time_with_font("13:25", config["clock_font"] - 1)
            await m.edit_text(f"🔤 فونت ساعت Random تنظیم شد | نمونه {sample}")
        elif font_str.isdigit():
            font_num = int(font_str)
            if 1 <= font_num <= 49:
                config["clock_font"] = font_num
                save_data(CONFIG_FILE, config)
                sample = format_time_with_font("13:25", font_num - 1)
                await m.edit_text(f"🔤 فونت ساعت {font_num} | نمونه {sample}")
            else:
                await m.edit_text("❌ عدد باید بین 1 تا 49 باشد")
        else:
            await m.edit_text("❌ فرمت: فونت ساعت [عدد 1-49] یا فونت ساعت Random")
        command_handled = True
        return

    # ==================== بال ساعت ====================
    elif text.startswith("بال "):
        bal_str = text[3:].strip()
        if bal_str == "خاموش":
            config["clock_bal"] = 0
            save_data(CONFIG_FILE, config)
            await m.edit_text("❌ بال ساعت خاموش شد")
        elif bal_str.isdigit():
            bal_num = int(bal_str)
            if 1 <= bal_num <= 194:
                config["clock_bal"] = bal_num
                save_data(CONFIG_FILE, config)
                sample = format_time_with_bal("13:25", config.get("clock_font", 8) - 1, bal_num - 1)
                await m.edit_text(f"» بال ساعت تنظیم شد | نمونه {sample}")
            else:
                await m.edit_text("❌ عدد باید بین 1 تا 194 باشد")
        else:
            await m.edit_text("❌ فرمت: بال [عدد 1-194] یا بال خاموش")
        command_handled = True
        return

    # ==================== ساعت نام ====================
    elif text == "ساعت روشن" or text == "TimeName on":
        config["clock_name"] = "on"
        save_data(CONFIG_FILE, config)
        me = await app.get_me()
        if not config.get("original_last_name"):
            config["original_last_name"] = me.last_name or ""
            save_data(CONFIG_FILE, config)
        await m.edit_text("⏰ ساعت نام روشن شد")
        await TimeName()
        command_handled = True
        return
    elif text == "ساعت خاموش" or text == "TimeName off":
        config["clock_name"] = "off"
        save_data(CONFIG_FILE, config)
        try:
            original_last = config.get("original_last_name", "")
            await app.update_profile(last_name=original_last or None)
        except:
            pass
        await m.edit_text("⏰ ساعت نام خاموش شد")
        command_handled = True
        return

    # ==================== ریبوت ====================
    elif text == "ریبوت" or text == "ربات" or text == "ریست" or text == "ریست سلف":
        await m.edit_text("ربات خاموش و روشن شد")
        import sys
        os.execl(sys.executable, sys.executable, *sys.argv)

    # ==================== تاس ====================
    elif text.startswith("تاس"):
        parts = text.split()
        target_number = None
        
        if len(parts) > 1:
            try:
                num = int(parts[1])
                if 1 <= num <= 6:
                    target_number = num
            except ValueError:
                pass
        
        reply_to_message = m.reply_to_message
        
        await m.delete()
        
        if target_number:
            while True:
                if reply_to_message:
                    msg = await app.send_dice(
                        chat_id, 
                        "🎲",
                        reply_to_message_id=reply_to_message.id
                    )
                else:
                    msg = await app.send_dice(chat_id, "🎲")
                
                if msg.dice.value == target_number:
                    break
                else:
                    await msg.delete()
        else:
            if reply_to_message:
                await app.send_dice(
                    chat_id, 
                    "🎲",
                    reply_to_message_id=reply_to_message.id
                )
            else:
                await app.send_dice(chat_id, "🎲")
        
        command_handled = True
            
    # ==================== دارت ====================
    elif text == "دارت":
        reply_to_message = m.reply_to_message
        
        await m.delete()
        
        while True:
            if reply_to_message:
                msg = await app.send_dice(
                    chat_id, 
                    "🎯",
                    reply_to_message_id=reply_to_message.id
                )
            else:
                msg = await app.send_dice(chat_id, "🎯")
            
            if msg.dice.value == 6:
                break
            else:
                await msg.delete()
        
        command_handled = True

    # ==================== بولینگ ====================
    elif text == "بولینگ":
        reply_to_message = m.reply_to_message
        
        await m.delete()
        
        while True:
            if reply_to_message:
                msg = await app.send_dice(
                    chat_id, 
                    "🎳",
                    reply_to_message_id=reply_to_message.id
                )
            else:
                msg = await app.send_dice(chat_id, "🎳")
            
            if msg.dice.value == 6:
                break
            else:
                await msg.delete()
        
        command_handled = True

    # ==================== بسکتبال ====================
    elif text == "بسکتبال":
        reply_to_message = m.reply_to_message
        
        await m.delete()
        
        while True:
            if reply_to_message:
                msg = await app.send_dice(
                    chat_id, 
                    "🏀",
                    reply_to_message_id=reply_to_message.id
                )
            else:
                msg = await app.send_dice(chat_id, "🏀")
            
            if msg.dice.value == 4:
                break
            else:
                await msg.delete()
        
        command_handled = True

    # ==================== فوتبال ====================
    elif text.startswith("فوتبال"):
        parts = text.split()
        target_number = None
        
        if len(parts) > 1:
            try:
                num = int(parts[1])
                if num in [1, 4]:
                    target_number = num
            except ValueError:
                pass
        
        reply_to_message = m.reply_to_message
        
        await m.delete()
        
        if target_number:
            while True:
                if reply_to_message:
                    msg = await app.send_dice(
                        chat_id, 
                        "⚽",
                        reply_to_message_id=reply_to_message.id
                    )
                else:
                    msg = await app.send_dice(chat_id, "⚽")
                
                if msg.dice.value == target_number:
                    break
                else:
                    await msg.delete()
        else:
            await app.send_message(chat_id, "لطفاً عدد 1 یا 4 بفرستید: فوتبال [1/4]")
        
        command_handled = True
            
    # ==================== خایمال ====================
    elif text == "خایمال":
        await m.edit_text("در لیست خایمال ثبت شد.")
        command_handled = True 

    # ==================== کازینو ====================
    elif text.startswith("کازینو"):
        await m.delete()
        target_emoji = None
        
        if "لیمو" in text:
            target_emoji = "🍋"
        elif "777" in text or "سه هفت" in text:
            target_emoji = "🎰"
        elif "بار" in text:
            target_emoji = "BAR"
        elif "انگور" in text:
            target_emoji = "🍇"
        
        loop_count = 0
        max_attempts = 200
        
        reply_to_message = m.reply_to_message
        
        while loop_count < max_attempts:
            if reply_to_message:
                msg = await app.send_dice(
                    chat_id, 
                    "🎰",
                    reply_to_message_id=reply_to_message.id
                )
            else:
                msg = await app.send_dice(chat_id, "🎰")
            
            if not target_emoji:
                if msg.dice.value == 64:
                    break
                else:
                    await msg.delete()
            
            else:
                emoji_values = {
                    "🍋": 1,
                    "BAR": 22,
                    "🍇": 63,
                    "🎰": 64
                }
                
                target_value = emoji_values.get(target_emoji, 64)
                
                if msg.dice.value == target_value:
                    break
                else:
                    await msg.delete()
            
            loop_count += 1
            await asyncio.sleep(0.1)
        
        if loop_count >= max_attempts:
            error_msg = "❌ بعد از 200 تلاش نتوانستم ست مورد نظرت رو بیارم!"
            if reply_to_message:
                await app.send_message(chat_id, error_msg, reply_to_message_id=reply_to_message.id)
            else:
                await app.send_message(chat_id, error_msg)
        
        command_handled = True

    # ==================== پینگ ====================
    elif text == "پینگ":
        start_time = time.time()
        ping_msg = await app.send_message("me", "پینگ")
        end_time = time.time()
        await ping_msg.delete()
        ping_duration = end_time - start_time
        await m.edit_text(f"پینگ {ping_duration:.3f} ثانیه")
        command_handled = True

    elif text == "تگ ادمین" and chat_type in [ChatType.GROUP, ChatType.SUPERGROUP]:
        if not await is_admin_cached(chat_id):
            await m.edit_text("❌ شما ادمین یا مالک نیستید!")
            command_handled = True
            return
        try:
            await m.delete()
            admins = []
            async for member in app.get_chat_members(chat_id, filter="administrators"):
                user = member.user
                if user.username:
                    mention = f"@{user.username}"
                else:
                    mention = f'<a href="tg://user?id={user.id}">{user.first_name or "Unknown"}</a>'
                admins.append(mention)
            if admins:
                tag_text = "👥 ادمین‌ها:\n" + "\n".join(admins)
                await app.send_message(chat_id, tag_text, parse_mode=ParseMode.HTML)
            else:
                await app.send_message(chat_id, "❌ هیچ ادمینی یافت نشد!")
        except Exception as e:
            await app.send_message(chat_id, f"❌ خطا در تگ ادمین: {e}")
        command_handled = True

    elif text == "تگ اعضا" and chat_type in [ChatType.GROUP, ChatType.SUPERGROUP]:
        if not await is_admin_cached(chat_id):
            await m.edit_text("❌ شما ادمین یا مالک نیستید!")
            command_handled = True
            return
        try:
            await m.delete()
            members = []
            count = 0
            async for member in app.get_chat_members(chat_id):
                if count >= 100:
                    break
                user = member.user
                if user.username:
                    mention = f"@{user.username}"
                else:
                    mention = f'<a href="tg://user?id={user.id}">{user.first_name or "Unknown"}</a>'
                members.append(mention)
                count += 1
            if members:
                tag_text = f"👥 اعضا ({len(members)} نفر):\n" + "\n".join(members[:200])
                await app.send_message(chat_id, tag_text, parse_mode=ParseMode.HTML)
                if len(members) > 50:
                    await app.send_message(chat_id, f"🔄 و {len(members) - 200} عضو دیگر... (محدودیت نمایش)")
            else:
                await app.send_message(chat_id, "❌ هیچ عضوی یافت نشد!")
        except Exception as e:
            await app.send_message(chat_id, f"❌ خطا در تگ اعضا: {e}")
        command_handled = True

    elif text == "افکت متن روشن":
        config["text_effect"] = "on"
        save_data(CONFIG_FILE, config)
        await m.edit_text("✨ افکت متن روشن شد")
        command_handled = True
        return

    elif text == "افکت متن خاموش":
        config["text_effect"] = "off"
        save_data(CONFIG_FILE, config)
        await m.edit_text("✨ افکت متن خاموش شد")
        command_handled = True
        return

    elif text.startswith("نوع افکت"):
        parts = text.split()
        if len(parts) > 2:
            effect_name = " ".join(parts[2:])
            valid_effects = ["تدریجی", "تایپ", "نقل قول", "اسپویلر", "بولد", "ایتالیک", "زیرخط", "خط خورده"]
            if effect_name in valid_effects:
                config["current_effect"] = effect_name
                save_data(CONFIG_FILE, config)
                if effect_name == "تایپ":
                    await apply_typing_effect(m, "افکت انتخاب شد")
                else:
                    formatted, pm = apply_effect("افکت انتخاب شد", effect_name)
                    await m.edit_text(formatted, parse_mode=pm)
                command_handled = True
                return
            else:
                await m.edit_text("افکت نامعتبر. افکت‌های موجود: تدریجی, تایپ, نقل قول, اسپویلر, بولد, ایتالیک, زیرخط, خط خورده")
                command_handled = True
                return
        else:
            await m.edit_text("لطفاً نوع افکت را مشخص کنید: نوع افکت [نام]")
            command_handled = True
            return

    elif text == "سین خودکار روشن":
        config["auto_seen"] = "on"
        save_data(CONFIG_FILE, config)
        await m.edit_text("👀 سین خودکار روشن")
        command_handled = True
        return
    elif text == "سین خودکار خاموش":
        config["auto_seen"] = "off"
        save_data(CONFIG_FILE, config)
        await m.edit_text("👀 سین خودکار خاموش")
        command_handled = True
        return

    # کپی پروفایل
    elif reply and text == "کپی پروفایل":
        user = reply.from_user
        try:
            await app.update_profile(
                first_name=user.first_name,
                last_name=user.last_name,
                bio=user.bio
            )
            photos = await app.get_user_profile_photos(user.id, limit=1)
            if photos:
                photo_file = await app.download_media(photos[0].file_id)
                await app.set_profile_photo(photo_file)
                os.remove(photo_file)
            await m.edit_text("🕶 پروفایل کاربر با موفقیت کپی شد")
        except Exception as e:
            await m.edit_text(f"❌ خطا در کپی پروفایل: {e}")
        command_handled = True
        return

    # تنظیم دشمن (همه جا)
    elif reply and text == "تنظیم دشمن":
        if user_id == me_id:
            await m.edit_text("❌ نمی‌توانید خودتان را دشمن کنید!")
            command_handled = True
            return
            
        # اضافه کردن به لیست کلی
        if user_id not in enemies["pvs"]:
            enemies["pvs"].append(user_id)
            name = await get_user_name(user_id)
            await m.edit_text(f"☠️ {name} به لیست دشمنان اضافه شد")
        else:
            await m.edit_text("❌ این کاربر قبلاً در لیست دشمنان است")
        save_data(ENEMY_FILE, enemies)
        command_handled = True
        return

    # حذف دشمن
    elif reply and text == "حذف دشمن":
        if user_id in enemies["pvs"]:
            enemies["pvs"].remove(user_id)
            name = await get_user_name(user_id)
            await m.edit_text(f"🗑 {name} از لیست دشمنان حذف شد")
            save_data(ENEMY_FILE, enemies)
        else:
            await m.edit_text("❌ این کاربر در لیست دشمنان نیست")
        command_handled = True
        return

    # لیست دشمن
    elif text == "لیست دشمن":
        if enemies["pvs"]:
            names = [await get_user_name(uid) for uid in enemies["pvs"]]
            list_str = "☠️ " + "☠️ ".join(names)
            await m.edit_text(f"📌 لیست دشمنان: {list_str}")
        else:
            await m.edit_text("📌 لیست دشمنان: خالی")
        command_handled = True
        return

    # پاکسازی لیست دشمن
    elif text == "پاکسازی لیست دشمن":
        enemies["pvs"] = []
        enemies["groups"] = {}
        save_data(ENEMY_FILE, enemies)
        await m.edit_text("🧹 لیست دشمنان پاکسازی شد")
        command_handled = True
        return

    # تنظیم دوست (همه جا)
    elif reply and text == "تنظیم دوست":
        if user_id == me_id:
            await m.edit_text("❌ نمی‌توانید خودتان را دوست کنید!")
            command_handled = True
            return
            
        # اضافه کردن به لیست کلی
        if user_id not in friends["pvs"]:
            friends["pvs"].append(user_id)
            name = await get_user_name(user_id)
            await m.edit_text(f"💞 {name} به لیست دوستان اضافه شد")
        else:
            await m.edit_text("❌ این کاربر قبلاً در لیست دوستان است")
        save_friends()
        command_handled = True
        return

    # حذف دوست
    elif reply and text == "حذف دوست":
        if user_id in friends["pvs"]:
            friends["pvs"].remove(user_id)
            name = await get_user_name(user_id)
            await m.edit_text(f"🗑 {name} از لیست دوستان حذف شد")
            save_friends()
        else:
            await m.edit_text("❌ این کاربر در لیست دوستان نیست")
        command_handled = True
        return

    # لیست دوست
    elif text == "لیست دوست":
        if friends["pvs"]:
            names = [await get_user_name(uid) for uid in friends["pvs"]]
            list_str = "💞 " + "💞 ".join(names)
            await m.edit_text(f"📌 لیست دوستان: {list_str}")
        else:
            await m.edit_text("📌 لیست دوستان: خالی")
        command_handled = True
        return

    # پاکسازی لیست دوست
    elif text == "پاکسازی لیست دوست":
        friends["pvs"] = []
        friends["groups"] = {}
        save_friends()
        await m.edit_text("🧹 لیست دوستان پاکسازی شد")
        command_handled = True
        return

    elif text == "قفل پیوی روشن":
        config["pv_lock"] = "on"
        save_data(CONFIG_FILE, config)
        await m.edit_text("🔒 قفل پیوی روشن شد")
        command_handled = True
        return

    elif text == "قفل پیوی خاموش":
        config["pv_lock"] = "off"
        save_data(CONFIG_FILE, config)
        await m.edit_text("🔓 قفل پیوی خاموش شد")
        command_handled = True
        return

    elif text.startswith("اسپم"):
        parts = text.split(maxsplit=2)
        if len(parts) == 3:
            try:
                count = int(parts[1])
                spam_text = parts[2]
                await m.delete()
                for _ in range(count):
                    await app.send_message(chat_id, spam_text)
                    await asyncio.sleep(0.01)
                command_handled = True
                return
            except ValueError:
                pass

    elif text.startswith("اسپم سریع"):
        parts = text.split(maxsplit=2)
        if len(parts) == 3:
            try:
                count = int(parts[1])
                spam_text = parts[2]
                await m.delete()
                for _ in range(count):
                    await app.send_message(chat_id, spam_text)
                    await asyncio.sleep(0.01)
                command_handled = True
                return
            except ValueError:
                pass

    # ==================== دستور ایدی - پشتیبانی از ریپلای و یوزرنیم ====================
    # بررسی دستور "ایدی" با ریپلای یا با یوزرنیم
    if text == "ایدی" or text == ".id":
        if reply:
            # ریپلای شده
            user = reply.from_user
        else:
            # بدون ریپلای - بررسی کنید آیا یوزرنیم در متن هست
            # اینجا چون دستور دقیقاً "ایدی" هست، بدون پارامتر
            # اما کاربر ممکن است "ایدی @username" بزنه که باید در بخش بعدی مدیریت بشه
            # اگر اینجا رسیدیم یعنی کاربر فقط "ایدی" زده
            user = await app.get_me()
        
        info = f"""👤 نام: {user.first_name or ''}
👥 نام خانوادگی: {user.last_name or ''}
🔗 یوزرنیم: @{user.username or 'ندارد'}
🆔 آیدی عددی: `{user.id}`"""
        await m.edit_text(info)
        command_handled = True
        return
    
    # دستور "ایدی" با یوزرنیم - مثال: ایدی @OWNER_VEXEL
    if text.startswith("ایدی ") and not reply:
        username_input = text[4:].strip()
        if username_input:
            # حذف @ اضافی
            username = username_input.replace('@', '').strip()
            try:
                user = await app.get_users(username)
                info = f"""👤 نام: {user.first_name or ''}
👥 نام خانوادگی: {user.last_name or ''}
🔗 یوزرنیم: @{user.username or 'ندارد'}
🆔 آیدی عددی: `{user.id}`"""
                await m.edit_text(info)
            except Exception as e:
                await m.edit_text(f"❌ کاربر @{username} یافت نشد: {str(e)[:50]}")
        else:
            await m.edit_text("❌ لطفاً یک یوزرنیم وارد کنید")
        command_handled = True
        return
    
    if reply and text == "ایدی":
        # اینجا همون بخش قبلی مدیریت میشه
        pass

    elif text.startswith("دانلود "):
        parts = text.split(maxsplit=1)
        if len(parts) != 2:
            await m.edit_text("❌ فرمت: دانلود [لینک پست]")
            command_handled = True
            return
        link = parts[1].strip()
        entity = None
        msg_id = None
        match = re.search(r'https://t\.me/c/(\d+)/(\d+)', link)
        if match:
            channel_num = match.group(1)
            msg_id = int(match.group(2))
            channel_id = int(f"-100{channel_num}")
            try:
                entity = await app.get_chat(channel_id)
            except Exception as e:
                await m.edit_text(f"❌ خطا در دسترسی به کانال: {str(e)[:50]}...")
                command_handled = True
                return
        else:
            match = re.search(r'https://t\.me/([^/]+)/(\d+)', link)
            if match:
                channel = match.group(1)
                msg_id = int(match.group(2))
                try:
                    entity = await app.get_chat(channel)
                except Exception as e:
                    await m.edit_text(f"❌ خطا در یافتن کانال: {str(e)[:50]}...")
                    command_handled = True
                    return
            else:
                await m.edit_text("❌ لینک نامعتبر! فرمت: https://t.me/channel/123 یا https://t.me/c/123456/789")
                command_handled = True
                return
        
        if entity and msg_id:
            try:
                msg = await app.get_messages(entity.id, msg_id)
                if not msg:
                    await m.edit_text("❌ پست یافت نشد!")
                    command_handled = True
                    return
                
                original_text = msg.text or ''
                
                if msg.media:
                    path = await msg.download()
                    try:
                        await app.send_document(
                            "me",
                            path,
                            caption=original_text,
                            reply_to_message_id=m.id
                        )
                        print(f"✅ پست {msg_id} (media) از {entity.id} کپی شد")
                    finally:
                        os.unlink(path)
                else:
                    await app.copy_message("me", entity.id, msg_id, reply_to_message_id=m.id)
                    print(f"✅ پست {msg_id} (text) از {entity.id} کپی شد")
                await m.edit_text("✅ پست مدیا با موفقیت کپی شد")
            except Exception as e:
                print(f"❌ خطا در کپی پست: {e}")
                await m.edit_text(f"❌ خطا در کپی: {str(e)[:50]}...")
            command_handled = True
        else:
            await m.edit_text("❌ خطا در پارس لینک!")
            command_handled = True

    #_________________________Helper_____________________________________
    elif "پنل" == text or "راهنما" == text:
        try:
            await m.delete()
            bot_results = await app.get_inline_bot_results(bot_id, "panel")
            await app.send_inline_bot_result(
                m.chat.id, 
                bot_results.query_id, 
                bot_results.results[0].id
            )
        except Exception as e:
            print(f"خطا در پنل اینلاین: {e}")
        command_handled = True
        return
        
    # ==================== انقضا به روز و ساعت ====================
    elif ".انقضا" == text or "انقضا" == text:
        try:
            await m.delete()
            # دریافت زمان انقضا از API یا محاسبه خودکار
            # محاسبه به روز و ساعت
            current_time = datetime.now()
            # فرض می‌کنیم 30 روز دیگر منقضی می‌شود
            expiry_date = current_time + timedelta(days=30)
            days_left = (expiry_date - current_time).days
            hours_left = (expiry_date - current_time).seconds // 3600
            
            expiry_text = f"⏳ **زمان باقی‌مانده:**\n"
            expiry_text += f"📅 {days_left} روز و {hours_left} ساعت"
            
            # ارسال به صورت اینلاین
            bot_results = await app.get_inline_bot_results(bot_id, "expire")
            await app.send_inline_bot_result(
                m.chat.id, 
                bot_results.query_id, 
                bot_results.results[0].id
            )
        except Exception as e:
            print(f"خطا در پنل اینلاین: {e}")
        command_handled = True
        return

    elif text == ".بیو" or text == "بیو":
        url = f'https://api.codebazan.ir/bio'
        response = requests.get(url)
        html_output = response.text
        msg = f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n **{html_output}** \n▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
        await app.send_message(m.chat.id, msg, reply_to_message_id=m.id)
        command_handled = True
        return

    # ==================== ماشین حساب ====================
    if text.startswith("e ") or text.startswith("محاسبه "):
        expression = text.replace("محاسبه ", "").replace("e ", "").strip()
        if not expression:
            await m.edit_text("❌ لطفاً عبارت ریاضی را وارد کنید")
            command_handled = True
            return
        
        await m.edit_text(f"🧮 در حال محاسبه: `{expression}`...")
        result, error = calculate(expression)
        
        if error:
            await m.edit_text(f"❌ خطا: {error}")
        else:
            await m.edit_text(f"🧮 **نتیجه:**\n`{expression}` = `{result}`")
        command_handled = True
        return

    # تبدیل استیکر به عکس
    elif text == "تبدیل استیکر به عکس":
        try:
            if not reply or not reply.sticker:
                await m.edit_text("**خطا!**\n\n__لطفاً روی یک استیکر ریپلای کنید__")
                return
            
            down = await app.download_media(reply)
            if down is None:
                await m.edit_text("**خطا!**\n\n__دانلود استیکر ناموفق بود__")
            else:
                os.rename(down, 'sticker.jpg')
                await app.send_photo(
                    m.chat.id, 
                    "sticker.jpg",
                    caption="**تبدیل استیکر به عکس**", 
                    reply_to_message_id=m.id
                )
                os.remove("sticker.jpg")
                await m.delete()
        except Exception as er:
            await m.edit_text(f"❖ **خطا** :\n(`{er}`)")
        command_handled = True
        return

    # تبدیل عکس به استیکر
    elif text == "تبدیل عکس به استیکر":
        try:
            if not reply or not reply.photo:
                await m.edit_text("**خطا!**\n\n__لطفاً روی یک عکس ریپلای کنید__")
                return
            
            down = await app.download_media(reply)
            if down is None:
                await m.edit_text("**خطا!**\n\n__دانلود عکس ناموفق بود__")
            else:
                os.rename(down, 'sticker.webp')
                await app.send_sticker(
                    m.chat.id, 
                    "sticker.webp", 
                    reply_to_message_id=m.id
                )
                os.remove("sticker.webp")
                await m.delete()
        except Exception as er:
            await m.edit_text(f"❖ **خطا** :\n(`{er}`)")
        command_handled = True
        return

    # تبدیل عکس به گیف
    elif text == "تبدیل عکس به گیف":
        try:
            if not reply or not reply.photo:
                await m.edit_text("**خطا!**\n\n__لطفاً روی یک عکس ریپلای کنید__")
                return
            
            down = await app.download_media(reply)
            if down is None:
                await m.edit_text("**خطا!**\n\n__دانلود عکس ناموفق بود__")
            else:
                os.rename(down, 'animation.gif')
                await app.send_animation(
                    m.chat.id, 
                    "animation.gif", 
                    reply_to_message_id=m.id
                )
                os.remove("animation.gif")
                await m.delete()
        except Exception as er:
            await m.edit_text(f"❖ **خطا** :\n(`{er}`)")
        command_handled = True
        return

    # خاطره
    elif text == "خاطره":
        url = f'http://api.codebazan.ir/jok/khatere'
        response = requests.get(url)
        html_output = response.text
        msg = f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n **{html_output}** \n▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
        await app.send_message(m.chat.id, msg, reply_to_message_id=m.id)
        command_handled = True
        return

    # ==================== دستورات جدید از سورس دوم ====================
    
    # ==================== .melo ====================
    elif text.startswith(".melo "):
        try:
            query = text.replace('.melo ', '')
            wait = await m.edit_text("⏳ در حال دریافت...")
            result = await app.get_inline_bot_results("melobot", query)
            if result.results:
                voice_result = result.results[0]
                gett = await app.send_inline_bot_result("me", result.query_id, voice_result.id)
                await asyncio.sleep(2)
                async for voice_msg in app.get_chat_history("me", limit=1):
                    if voice_msg.voice:
                        file_path = await app.download_media(voice_msg.voice)
                        await wait.delete()
                        await app.send_voice(m.chat.id, file_path, reply_to_message_id=m.id)
                        os.remove(file_path)
                        await app.delete_messages("me", gett.updates[0].id)
                    else:
                        await wait.edit("❌ ویسی یافت نشد")
            else:
                await wait.edit("❌ نتیجه‌ای یافت نشد")
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== کامنت اول ====================
    elif text.startswith("متن کامنت"):
        if reply:
            if reply.animation:
                firstcomment_data["type"] = "animation"
                firstcomment_data["content"] = reply.animation.file_id
                save_firstcomment()
                await m.edit_text("✅ گیف کامنت اول ذخیره شد")
            elif reply.sticker:
                firstcomment_data["type"] = "sticker"
                firstcomment_data["content"] = reply.sticker.file_id
                save_firstcomment()
                await m.edit_text("✅ استیکر کامنت اول ذخیره شد")
            elif reply.text:
                firstcomment_data["type"] = "text"
                firstcomment_data["content"] = reply.text
                save_firstcomment()
                await m.edit_text(f"✅ متن کامنت اول ذخیره شد: {reply.text}")
            else:
                await m.edit_text("❌ لطفاً روی گیف، استیکر یا متن ریپلای کنید")
        else:
            await m.edit_text("❌ لطفاً روی پیام مورد نظر ریپلای کنید")
        command_handled = True
        return
    
    elif text == "کامنت اول روشن":
        config["firstcom"] = "on"
        save_data(CONFIG_FILE, config)
        await m.edit_text("✅ کامنت اول روشن شد")
        command_handled = True
        return
    
    elif text == "کامنت اول خاموش":
        config["firstcom"] = "off"
        save_data(CONFIG_FILE, config)
        await m.edit_text("❌ کامنت اول خاموش شد")
        command_handled = True
        return

    # ==================== خوشامدگویی ====================
    elif text.startswith("متن خوشامد"):
        if reply and reply.text:
            welcome_data["text"] = reply.text
            save_welcome()
            await m.edit_text(f"✅ متن خوشامدگویی ذخیره شد: {reply.text}")
        elif text[12:].strip():
            welcome_text = text[12:].strip()
            welcome_data["text"] = welcome_text
            save_welcome()
            await m.edit_text(f"✅ متن خوشامدگویی ذخیره شد: {welcome_text}")
        else:
            await m.edit_text("❌ لطفاً متن را وارد کنید یا روی پیام ریپلای کنید")
        command_handled = True
        return
    
    elif text == "خوشامد روشن":
        config["welcome"] = "on"
        save_data(CONFIG_FILE, config)
        await m.edit_text("✅ خوشامدگویی روشن شد")
        command_handled = True
        return
    
    elif text == "خوشامد خاموش":
        config["welcome"] = "off"
        save_data(CONFIG_FILE, config)
        await m.edit_text("❌ خوشامدگویی خاموش شد")
        command_handled = True
        return
    
    elif text == "پاکسازی خوشامد":
        welcome_data["text"] = ""
        save_welcome()
        await m.edit_text("✅ متن خوشامدگویی پاک شد")
        command_handled = True
        return
    
    elif text == "لیست خوشامد":
        if welcome_data.get("text"):
            await m.edit_text(f"📝 متن خوشامدگویی:\n{welcome_data['text']}")
        else:
            await m.edit_text("📝 متن خوشامدگویی تنظیم نشده است")
        command_handled = True
        return

    # ==================== هشدار تگ ====================
    elif text == "هشدار تگ روشن":
        tagalert_data["enabled"] = True
        if m.chat.id not in tagalert_data.get("chats", []):
            if "chats" not in tagalert_data:
                tagalert_data["chats"] = []
            tagalert_data["chats"].append(m.chat.id)
        save_tagalert()
        await m.edit_text("✅ هشدار تگ در این چت روشن شد")
        command_handled = True
        return
    
    elif text == "هشدار تگ خاموش":
        if m.chat.id in tagalert_data.get("chats", []):
            tagalert_data["chats"].remove(m.chat.id)
            if not tagalert_data["chats"]:
                tagalert_data["enabled"] = False
        save_tagalert()
        await m.edit_text("❌ هشدار تگ در این چت خاموش شد")
        command_handled = True
        return
    
    # ==================== افزایش ====================
    if text.startswith(".افزایش "):
        user_input = text.replace(".افزایش ", "").strip()
        target_id = None
        
        # جدا کردن مقدار و آیدی
        parts = user_input.split()
        if len(parts) >= 2:
            amount = parts[0]
            user_input = parts[1]
        else:
            amount = parts[0]
        
        if reply:
            target_id = reply.from_user.id
        elif user_input:
            if user_input.isdigit():
                target_id = int(user_input)
            else:
                try:
                    user = await app.get_users(user_input)
                    target_id = user.id
                except:
                    await m.edit_text("❌ کاربر یافت نشد")
                    command_handled = True
                    return
        else:
            await m.edit_text("❌ لطفاً کاربر را مشخص کنید")
            command_handled = True
            return
        
        await m.edit_text(f"🔄 در حال انجام عملیات...")
        try:
            await app.unblock_user("TabchiLandBot")
            msg = await app.send_message("TabchiLandBot", f"افزایش {amount} {target_id}")
            await asyncio.sleep(3)
            
            async for history_msg in app.get_chat_history("TabchiLandBot", limit=2):
                if history_msg.id != msg.id:
                    creation_date = history_msg.text
                    break
            else:
                creation_date = "نامشخص"
            
            await m.edit_text(f"{creation_date}")
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return
        
    # ==================== کسر ====================
    if text.startswith(".کسر "):
        user_input = text.replace(".کسر ", "").strip()
        target_id = None
        
        # جدا کردن مقدار و آیدی
        parts = user_input.split()
        if len(parts) >= 2:
            amount = parts[0]
            user_input = parts[1]
        else:
            amount = parts[0]
        
        if reply:
            target_id = reply.from_user.id
        elif user_input:
            if user_input.isdigit():
                target_id = int(user_input)
            else:
                try:
                    user = await app.get_users(user_input)
                    target_id = user.id
                except:
                    await m.edit_text("❌ کاربر یافت نشد")
                    command_handled = True
                    return
        else:
            await m.edit_text("❌ لطفاً کاربر را مشخص کنید")
            command_handled = True
            return
        
        await m.edit_text(f"🔄 در حال انجام عملیات...")
        try:
            await app.unblock_user("TabchiLandBot")
            msg = await app.send_message("TabchiLandBot", f"کسر {amount} {target_id}")
            await asyncio.sleep(3)
            
            async for history_msg in app.get_chat_history("TabchiLandBot", limit=2):
                if history_msg.id != msg.id:
                    creation_date = history_msg.text
                    break
            else:
                creation_date = "نامشخص"
            
            await m.edit_text(f"{creation_date}")
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    # ==================== پاسخ خودکار ====================
    elif text == "پاسخ روشن":
        config["autoan"] = "on"
        save_data(CONFIG_FILE, config)
        await m.edit_text("✅ پاسخگویی خودکار روشن شد")
        command_handled = True
        return
    
    elif text == "پاسخ خاموش":
        config["autoan"] = "off"
        save_data(CONFIG_FILE, config)
        await m.edit_text("❌ پاسخگویی خودکار خاموش شد")
        command_handled = True
        return
    
    elif text.startswith("افزودن پاسخ "):
        parts = text[10:].strip().split(":", 1)
        if len(parts) == 2:
            question = parts[0].strip()
            answer = parts[1].strip()
            if question and answer:
                autoanswer["questions"].append(question)
                autoanswer["answers"].append(answer)
                save_autoanswer()
                await m.edit_text(f"✅ پاسخ اضافه شد:\nسوال: {question}\nپاسخ: {answer}")
            else:
                await m.edit_text("❌ سوال یا پاسخ نمی‌تواند خالی باشد")
        else:
            await m.edit_text("❌ فرمت صحیح: افزودن پاسخ سوال:پاسخ")
        command_handled = True
        return
    
    elif text == "پاکسازی پاسخ":
        autoanswer["questions"] = []
        autoanswer["answers"] = []
        save_autoanswer()
        await m.edit_text("✅ تمام پاسخ‌ها پاک شدند")
        command_handled = True
        return
    
    elif text == "لیست پاسخ":
        if autoanswer["questions"]:
            msg = "📋 **لیست پاسخ‌ها:**\n\n"
            for i, (q, a) in enumerate(zip(autoanswer["questions"], autoanswer["answers"]), 1):
                msg += f"{i}. سوال: {q}\n   پاسخ: {a}\n\n"
            await m.edit_text(msg + "| Self Ali")
        else:
            await m.edit_text("📝 لیست پاسخ‌ها خالی است")
        command_handled = True
        return

    # ==================== اطلاعات سیستم ====================
    elif text == "سیستم" or text == ".sys":
        try:
            uname = os.uname()
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            
            msg = "💻 **اطلاعات سیستم**\n\n"
            msg += f"🖥 سیستم: {uname.sysname}\n"
            msg += f"📡 نام: {uname.nodename}\n"
            msg += f"📀 نسخه: {uname.release}\n"
            msg += f"⚙️ معماری: {uname.machine}\n"
            msg += f"🔥 CPU: {cpu_percent}%\n"
            msg += f"🧠 RAM: {memory.percent}% ({sizeof_fmt(memory.used)}/{sizeof_fmt(memory.total)})\n"
            msg += f"🐍 Python: {sys.version.split()[0]}\n"
            msg += "\n| Self Ali"
            await m.edit_text(msg)
        except Exception as e:
            await m.edit_text(f"❌ خطا: {str(e)[:50]}")
        command_handled = True
        return

    if not command_handled:
        if config["text_effect"] == "on":
            effect = config["current_effect"]
            if effect == "تایپ":
                await apply_typing_effect(m, text)
            else:
                formatted, pm = apply_effect(text, effect)
                await m.edit_text(formatted, parse_mode=pm)

# ایجاد فایل‌ها
if not os.path.exists("downloads"):
    os.makedirs("downloads")
if not os.path.exists("awnser"):
    os.makedirs("awnser")

scheduler = AsyncIOScheduler()
scheduler.add_job(TimeName, "interval", seconds=1)
scheduler.add_job(TimeBio, "interval", seconds=1)
scheduler.add_job(mak, "interval", hours=2)
scheduler.start()

app.start()
print("started")
app.send_message("me", f"""**سلف شما با موفقیت برای شما فعال شد ✔️ 
⤾ با استفاده از دستور « پنل » یا « راهنما » پنل براتون باز میشه.**""")
idle()
app.stop()