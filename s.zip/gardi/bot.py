import asyncio
import os
import sqlite3
from telethon import TelegramClient, events, Button
from telethon.sessions import StringSession
from telethon.errors import SessionPasswordNeededError, PhoneCodeInvalidError, UserNotParticipantError, PeerIdInvalidError, RPCError
import subprocess
import re
import random
import time
import glob
import sys
import json
from datetime import datetime, timedelta

API_ID = 39900197
API_HASH = 'f2d6bcf2a1ce4bef29ddd415975d7021'
BOT_TOKEN = '8649187876:AAFQcpXuouxS6vfcj1fzMoAB0qBvxQ_TjJU'
ADMIN_ID = 7074367029
OWNER_IDS = [7074367029]

active_games = {}
BOT_IMAGE_PATH = 'bot.jpg'

# ==================== تنظیمات قیمت‌ها ====================
SELF_PRICE = 48
BLACK_TO_TOMAN_RATE = 40
REFERRAL_REWARD = 25
COMMISSION_RATE = 0.05

# ==================== دیتابیس اصلی ====================
MAIN_DB = 'main_data.db'

def get_main_db():
    db = sqlite3.connect(MAIN_DB)
    cursor = db.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS force_joins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            channel_id TEXT,
            channel_username TEXT,
            channel_link TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS admins (
            user_id INTEGER PRIMARY KEY,
            added_by INTEGER,
            added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS banned_users (
            user_id INTEGER PRIMARY KEY,
            banned_by INTEGER,
            reason TEXT,
            banned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            type TEXT,
            amount INTEGER,
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS backups (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # تنظیمات پیشفرض
    defaults = [
        ('bot_enabled', '1'),
        ('join_mandatory', '0'),
        ('card_number', '6219861850283416'),
        ('channel_username', ''),
        ('self_price', '48'),
        ('black_rate', '40'),
        ('referral_reward', '25'),
        ('commission_rate', '0.05')
    ]
    
    for key, value in defaults:
        cursor.execute('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)', (key, value))
    
    db.commit()
    return db

def get_main_setting(key, default=None):
    db = get_main_db()
    cursor = db.cursor()
    cursor.execute('SELECT value FROM settings WHERE key = ?', (key,))
    result = cursor.fetchone()
    db.close()
    return result[0] if result else default

def set_main_setting(key, value):
    db = get_main_db()
    cursor = db.cursor()
    cursor.execute('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', (key, value))
    db.commit()
    db.close()

def add_force_join(channel_id, channel_username, channel_link):
    db = get_main_db()
    cursor = db.cursor()
    cursor.execute('''
        INSERT INTO force_joins (channel_id, channel_username, channel_link)
        VALUES (?, ?, ?)
    ''', (channel_id, channel_username, channel_link))
    db.commit()
    db.close()

def remove_force_join(channel_id):
    db = get_main_db()
    cursor = db.cursor()
    cursor.execute('DELETE FROM force_joins WHERE channel_id = ?', (channel_id,))
    db.commit()
    db.close()

def get_force_joins():
    db = get_main_db()
    cursor = db.cursor()
    cursor.execute('SELECT * FROM force_joins')
    result = cursor.fetchall()
    db.close()
    return result

def add_admin(user_id, added_by):
    db = get_main_db()
    cursor = db.cursor()
    cursor.execute('INSERT OR REPLACE INTO admins (user_id, added_by) VALUES (?, ?)', (user_id, added_by))
    db.commit()
    db.close()

def remove_admin(user_id):
    db = get_main_db()
    cursor = db.cursor()
    cursor.execute('DELETE FROM admins WHERE user_id = ?', (user_id,))
    db.commit()
    db.close()

def get_admins():
    db = get_main_db()
    cursor = db.cursor()
    cursor.execute('SELECT user_id FROM admins')
    result = [row[0] for row in cursor.fetchall()]
    db.close()
    return list(set(result + OWNER_IDS))

def is_admin(user_id):
    return user_id in get_admins()

def ban_user(user_id, banned_by, reason=""):
    db = get_main_db()
    cursor = db.cursor()
    cursor.execute('INSERT OR REPLACE INTO banned_users (user_id, banned_by, reason) VALUES (?, ?, ?)', 
                   (user_id, banned_by, reason))
    db.commit()
    db.close()
    
    try:
        db_user = get_user_db(user_id)
        cursor = db_user.cursor()
        cursor.execute('UPDATE users SET banned = 1 WHERE user_id = ?', (user_id,))
        db_user.commit()
        db_user.close()
    except:
        pass

def unban_user(user_id):
    db = get_main_db()
    cursor = db.cursor()
    cursor.execute('DELETE FROM banned_users WHERE user_id = ?', (user_id,))
    db.commit()
    db.close()
    
    try:
        db_user = get_user_db(user_id)
        cursor = db_user.cursor()
        cursor.execute('UPDATE users SET banned = 0 WHERE user_id = ?', (user_id,))
        db_user.commit()
        db_user.close()
    except:
        pass

def is_banned_main(user_id):
    db = get_main_db()
    cursor = db.cursor()
    cursor.execute('SELECT user_id FROM banned_users WHERE user_id = ?', (user_id,))
    result = cursor.fetchone()
    db.close()
    return result is not None

def add_transaction(user_id, type, amount, description=""):
    db = get_main_db()
    cursor = db.cursor()
    cursor.execute('''
        INSERT INTO transactions (user_id, type, amount, description)
        VALUES (?, ?, ?, ?)
    ''', (user_id, type, amount, description))
    db.commit()
    db.close()

def get_transactions(user_id=None, limit=50):
    db = get_main_db()
    cursor = db.cursor()
    if user_id:
        cursor.execute('''
            SELECT * FROM transactions 
            WHERE user_id = ? 
            ORDER BY created_at DESC 
            LIMIT ?
        ''', (user_id, limit))
    else:
        cursor.execute('''
            SELECT * FROM transactions 
            ORDER BY created_at DESC 
            LIMIT ?
        ''', (limit,))
    result = cursor.fetchall()
    db.close()
    return result

if not os.path.exists('database_users'):
    os.makedirs('database_users')

def get_user_db(user_id):
    return sqlite3.connect(f'database_users/user_{user_id}.db')

def init_user_db(user_id):
    db = get_user_db(user_id)
    cursor = db.cursor()
    cursor.execute('PRAGMA foreign_keys = ON')

    cursor.execute('CREATE TABLE IF NOT EXISTS users (user_id INTEGER PRIMARY KEY, balance INTEGER DEFAULT 0, banned INTEGER DEFAULT 0, invited_by INTEGER DEFAULT 0, self_start_time INTEGER DEFAULT 0)')
    try:
        cursor.execute('ALTER TABLE users ADD COLUMN self_start_time INTEGER DEFAULT 0')
    except sqlite3.OperationalError:
        pass

    cursor.execute('CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)')
    
    cursor.execute('CREATE TABLE IF NOT EXISTS self_sessions (session_string TEXT, sub_type INTEGER, is_active INTEGER DEFAULT 1, start_time INTEGER DEFAULT 0)')
    try:
        cursor.execute('ALTER TABLE self_sessions ADD COLUMN start_time INTEGER DEFAULT 0')
    except sqlite3.OperationalError:
        pass
            
    cursor.execute('CREATE TABLE IF NOT EXISTS referrals (referrer_id INTEGER, referred_id INTEGER PRIMARY KEY, reward_claimed INTEGER DEFAULT 0)')
    
    cursor.execute('INSERT OR IGNORE INTO users (user_id, balance, banned, invited_by, self_start_time) VALUES (?, 0, 0, 0, 0)', (user_id,))
    db.commit()
    return db

def get_setting(user_id, key, default=None):
    db = get_user_db(user_id)
    cursor = db.cursor()
    cursor.execute('SELECT value FROM settings WHERE key = ?', (key,))
    result = cursor.fetchone()
    db.close()
    return result[0] if result else default

def set_setting(user_id, key, value):
    db = get_user_db(user_id)
    cursor = db.cursor()
    cursor.execute('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', (key, value))
    db.commit()
    db.close()

def save_self_session(user_id, session_string, sub_type):
    db = get_user_db(user_id)
    cursor = db.cursor()
    cursor.execute('UPDATE self_sessions SET is_active = 0')
    cursor.execute('INSERT INTO self_sessions (session_string, sub_type, is_active, start_time) VALUES (?, ?, 1, ?)', (session_string, sub_type, int(time.time())))
    db.commit()
    cursor.execute('UPDATE users SET self_start_time = ? WHERE user_id = ?', (int(time.time()), user_id))
    db.commit()
    db.close()

def get_self_session(user_id):
    db = get_user_db(user_id)
    cursor = db.cursor()
    cursor.execute('SELECT session_string, sub_type, start_time FROM self_sessions WHERE is_active = 1')
    result = cursor.fetchone()
    db.close()
    return result

def deactivate_self_session(user_id):
    db = get_user_db(user_id)
    cursor = db.cursor()
    cursor.execute('UPDATE self_sessions SET is_active = 0 WHERE is_active = 1')
    cursor.execute('UPDATE users SET self_start_time = 0 WHERE user_id = ?', (user_id,))
    db.commit()
    db.close()

def delete_user_data(user_id):
    try:
        db_path = f'database_users/user_{user_id}.db'
        if os.path.exists(db_path):
            os.remove(db_path)
        return True
    except:
        return False

def run_self_py(session_string, sub_type, user_id):
    try:
        command = [sys.executable, 'self.py', session_string, str(sub_type), str(user_id)]
        process = subprocess.Popen(command, 
                                 start_new_session=True, 
                                 stdout=subprocess.PIPE, 
                                 stderr=subprocess.PIPE)
        return True
    except Exception as e:
        print(f"Error running self.py for user {user_id}: {e}")
        return False

def stop_self_py(user_id):
    try:
        subprocess.run(['pkill', '-f', f'self.py.*{user_id}'], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return True
    except subprocess.CalledProcessError:
        return True
    except Exception as e:
        print(f"General Error stopping self.py for user {user_id}: {e}")
        return False

def get_all_active_sessions():
    sessions = []
    for db_file in glob.glob('database_users/user_*.db'):
        try:
            match = re.search(r'user_(\d+)\.db', db_file)
            if match:
                user_id = int(match.group(1))
                db = sqlite3.connect(db_file)
                cursor = db.cursor()
                cursor.execute('SELECT session_string, sub_type FROM self_sessions WHERE is_active = 1')
                result = cursor.fetchone()
                db.close()
                if result:
                    sessions.append((user_id, result[0], result[1]))
        except Exception as e:
            print(f"Error reading session from {db_file}: {e}")
            continue
    return sessions

async def restart_all_selfs():
    sessions = get_all_active_sessions()
    restart_count = 0
    for user_id, session_string, sub_type in sessions:
        stop_self_py(user_id)
        await asyncio.sleep(0.5) 
        if run_self_py(session_string, sub_type, user_id):
            restart_count += 1
        else:
            print(f"Failed to restart self.py for user {user_id}")
    return restart_count

async def get_user_info_for_group(user_id):
    init_user_db(user_id) 
    
    db = get_user_db(user_id)
    cursor = db.cursor()
    cursor.execute('SELECT balance, self_start_time FROM users WHERE user_id = ?', (user_id,))
    result = cursor.fetchone()
    balance = result[0] if result else 0
    self_start_time = result[1] if result else 0
    db.close()
    
    session_data = get_self_session(user_id)
    has_active_self = "فعال" if session_data else "غیرفعال"
    
    if self_start_time and self_start_time > 0:
        current_time = int(time.time())
        elapsed_time = current_time - self_start_time
        days = elapsed_time // 86400
        hours = (elapsed_time % 86400) // 3600
        time_info = f"\nآمار سیاه: {days} روز و {hours} ساعت"
    else:
        time_info = ""
    
    return f"""
اطلاعات حساب شما در ربات سلف ساز سیاه به شرح زیر میباشد.

آیدی عددی : {user_id}

موجودی (سیاه) : {balance:,}

موجودی نقدی : {balance * BLACK_TO_TOMAN_RATE:,} تومان

وضعیت سلف فعال : {has_active_self}{time_info}
"""

async def delete_game_on_timeout(chat_id, message_id, organizer_id, amount):
    await asyncio.sleep(300)

    game_key = (chat_id, message_id)
    if game_key in active_games:
        db = get_user_db(organizer_id)
        cursor = db.cursor()
        cursor.execute('UPDATE users SET balance = balance + ? WHERE user_id = ?', (amount, organizer_id))
        db.commit()
        db.close()

        try:
            await bot.delete_messages(chat_id, message_id)
            await bot.send_message(organizer_id, f'نبرد سیاه با تعداد{amount:,} سیاه در گروه {chat_id} به دلیل عدم حضور حریف در طول ۵ دقیقه لغو شد. تعداد {amount:,} سیاه به حساب شما برگشت داده شد.')
        except Exception:
            pass

        del active_games[game_key]

async def handle_game_cancel(chat_id, message_id, organizer_id, event_to_edit):
    game_key = (chat_id, message_id)
    if game_key in active_games:
        active_games[game_key]['timer'].cancel()

        amount = active_games[game_key]['amount']
        db = get_user_db(organizer_id)
        cursor = db.cursor()
        cursor.execute('UPDATE users SET balance = balance + ? WHERE user_id = ?', (amount, organizer_id))
        db.commit()
        db.close()
        
        try:
            await bot.delete_messages(chat_id, message_id)
            await bot.send_message(organizer_id, f'نبرد سیاه با تعداد {amount:,} سیاه لغو شد. تعداد {amount:,} سیاه به حساب شما برگشت داده شد.')
        except Exception:
            try:
                await event_to_edit.edit('نبرد سیاه با موفقیت لغو و تعداد سیاه بسته شده به حساب شما بازگشت داده شد.')
            except:
                pass

        del active_games[game_key]
        return True
    return False

init_user_db(ADMIN_ID)

bot = TelegramClient('bot', API_ID, API_HASH).start(bot_token=BOT_TOKEN)

user_clients = {}
user_purchase_amount = {}

async def code_timer(user_id):
    await asyncio.sleep(60)
    if user_id in user_clients and user_clients[user_id].get('step') == 'code':
        await bot.send_message(user_id, 'زمان کد ورود به پایان رسید.')
        try:
             client = user_clients[user_id].get('client')
             if client:
                 await client.disconnect()
        except:
             pass
        finally:
             if user_id in user_clients:
                 del user_clients[user_id]

async def handle_login_success(user_id, sub_type):
    client = user_clients[user_id]['client']
    session_string = client.session.save()
    
    if not session_string or session_string.strip() == '':
        await bot.send_message(user_id, 'خطا: سشن استرینگ ایجاد نشده یا نامعتبر است. لطفاً مجدد تلاش کنید.')
        try:
            await client.disconnect()
        except:
             pass
        finally:
             if user_id in user_clients:
                 del user_clients[user_id]
        return

    success = run_self_py(session_string, sub_type, user_id)
    
    if success:
        save_self_session(user_id, session_string, sub_type)
        price = SELF_PRICE
        db = get_user_db(user_id)
        cursor = db.cursor()
        cursor.execute('UPDATE users SET balance = balance - ? WHERE user_id = ?', (price, user_id))
        db.commit()
        db.close()
        
        await bot.send_message(user_id, f'سلف سیاه با موفقیت بر روی اکانت شما فعال شد.')
    else:
        await bot.send_message(user_id, 'خطای راه اندازی سلف | لطفا به @ZadehMarG پیام دهید و خطا را گزارش دهید.)')
    
    try:
        await client.disconnect()
    except:
        pass
    if user_id in user_clients:
        del user_clients[user_id]

@bot.on(events.NewMessage)
async def handle_all_messages(event):
    if event.is_private:
        await handle_private_messages(event)
    elif event.is_group or event.is_channel:
        await handle_group_commands(event)

async def handle_group_commands(event):
    chat_id = event.chat_id
    text = event.text

    if text and text.strip() == 'حساب سیاه':
        user_id = event.sender_id
        
        target_user_id = None
        if event.is_reply:
            reply_message = await event.get_reply_message()
            if reply_message and reply_message.sender_id:
                 target_user_id = reply_message.sender_id
        
        if target_user_id is None:
            target_user_id = user_id
        
        try:
            target_user_entity = await bot.get_entity(target_user_id)
        except Exception:
            await event.reply('اطلاعات حساب کاربر مورد نظر پیدا نشد.')
            return

        try:
            account_text = await get_user_info_for_group(target_user_id)
            
            if os.path.exists(BOT_IMAGE_PATH):
                await bot.send_file(
                    event.chat_id,
                    BOT_IMAGE_PATH,
                    caption=account_text,
                    reply_to=event.id
                )
            else:
                 await event.reply(account_text)
        except Exception as e:
            print(f"Error fetching user info for group: {e}")
            await event.reply('خطا در دریافت اطلاعات حساب کاربر.')
        return

    game_match = re.match(r'بازی\s+(\d+)$', text.strip(), re.IGNORECASE)

    if game_match:
        organizer_id = event.sender_id
        amount = int(game_match.group(1))

        if amount < 88:
            await event.reply('مبلغ نبرد باید حداقل 88 سیاه باشد.')
            return

        init_user_db(organizer_id)
        db = get_user_db(organizer_id)
        cursor = db.cursor()
        cursor.execute('SELECT balance FROM users WHERE user_id = ?', (organizer_id,))
        result = cursor.fetchone()
        organizer_balance = result[0] if result else 0
        db.close()

        if organizer_balance < amount:
            await event.reply(f'موجودی سیاه شما ({organizer_balance:,}) برای شروع نبرد با مبلغ {amount:,} کافی نیست.')
            return

        db = get_user_db(organizer_id)
        cursor = db.cursor()
        cursor.execute('UPDATE users SET balance = balance - ? WHERE user_id = ?', (amount, organizer_id))
        db.commit()
        db.close()

        organizer_mention = f"[{event.sender.first_name}](tg://user?id={organizer_id})"

        game_text = f"""
نبرد سیاه

برگزار کننده : {organizer_mention}
مبلغ نبرد : {amount:,} سیاه
جایزه کل : {amount * 2:,} سیاه
مهلت پیوستن : 5 دقیقه

جهت پیوستن به نبرد سیاه لطفا روی پیوستن به نبرد کلیک کنید.
"""
        buttons = [
            [Button.inline('✅ پیوستن به نبرد', f'game_join_{amount}_{organizer_id}'.encode())],
            [Button.inline('❌ لغو نبرد', f'game_cancel_{amount}_{organizer_id}'.encode())]
        ]
        
        if os.path.exists(BOT_IMAGE_PATH):
            sent_message = await bot.send_file(
                event.chat_id,
                BOT_IMAGE_PATH,
                caption=game_text,
                buttons=buttons,
                parse_mode='md',
                reply_to=event.id
            )
        else:
             sent_message = await event.reply(game_text, buttons=buttons, parse_mode='md')
        
        game_key = (chat_id, sent_message.id)
        timer_task = asyncio.create_task(delete_game_on_timeout(chat_id, sent_message.id, organizer_id, amount))
        
        active_games[game_key] = {
            'organizer_id': organizer_id,
            'amount': amount,
            'timer': timer_task
        }
        return

@bot.on(events.CallbackQuery(pattern=b'game_(join|cancel)_(\\d+)_(\\d+)'))
async def handle_game_callbacks(event):
    data_parts = event.data.decode().split('_')
    action = data_parts[1]
    amount_or_id = int(data_parts[2])
    organizer_id = int(data_parts[3])
    
    chat_id = event.chat_id
    message_id = event.message_id
    game_key = (chat_id, message_id)
    
    user_id = event.sender_id
    
    if action == 'cancel':
        if user_id != organizer_id:
            await event.answer('❌ دوست عزیز فقط برگزار کننده میتواند نبرد را لغو نماید.', alert=True)
            return

        success = await handle_game_cancel(chat_id, message_id, organizer_id, event)
        if success:
             await event.answer('✅ نبرد سیاه لغو شد و تعداد سیاه بسته شده به حساب شما برگشت داده شد.', alert=False)
        else:
             await event.answer('⚠️ این نبرد قبلاً لغو یا انجام شده است.', alert=True)

    elif action == 'join':
        amount = amount_or_id
        
        if user_id == organizer_id:
            await event.answer('❌ شما برگزار کننده هستید و نمی توانید به نبرد خودتان بپیوندید.', alert=True)
            return

        if game_key not in active_games:
            await event.answer('⚠️ این نبرد منقضی شده یا انجام شده است.', alert=True)
            try:
                await bot.delete_messages(chat_id, message_id)
            except:
                pass
            return

        init_user_db(user_id)
        db = get_user_db(user_id)
        cursor = db.cursor()
        cursor.execute('SELECT balance FROM users WHERE user_id = ?', (user_id,))
        result = cursor.fetchone()
        joiner_balance = result[0] if result else 0
        db.close()

        if joiner_balance < amount:
            await event.answer(f'❌ موجودی سیاه شما ({joiner_balance:,}) برای پیوستن به نبرد با مبلغ {amount:,} کافی نیست.', alert=True)
            return
        
        db = get_user_db(user_id)
        cursor = db.cursor()
        cursor.execute('UPDATE users SET balance = balance - ? WHERE user_id = ?', (amount, user_id))
        db.commit()
        db.close()
        
        participants = [organizer_id, user_id]
        
        try:
            organizer_info = await bot.get_entity(organizer_id)
            joiner_info = await bot.get_entity(user_id)
            
            organizer_mention = f"[{organizer_info.first_name}](tg://user?id={organizer_id})"
            joiner_mention = f"[{joiner_info.first_name}](tg://user?id={user_id})"
        except Exception:
            organizer_mention = f"کاربر [{organizer_id}]"
            joiner_mention = f"کاربر [{user_id}]"

        active_games[game_key]['timer'].cancel()

        wait_text = f"""
نبرد سیاه

برگزار کننده : {organizer_mention}
حریف (پیوستن) : {joiner_mention}
 مبلغ نبرد : {amount:,} سیاه
مهلت : مشخص کردن برنده...
"""
        
        try:
            await event.edit(wait_text, buttons=None, parse_mode='md')
            await asyncio.sleep(5) 
        except Exception:
            pass 

        winner_id = random.choice(participants)
        total_prize = amount * 2
        
        commission = int(total_prize * COMMISSION_RATE)
        net_winnings = total_prize - commission
        
        db = get_user_db(winner_id)
        cursor = db.cursor()
        cursor.execute('UPDATE users SET balance = balance + ? WHERE user_id = ?', (net_winnings, winner_id))
        db.commit()
        db.close()
        
        del active_games[game_key]
        
        winner_mention = organizer_mention if winner_id == organizer_id else joiner_mention
            
        result_text = f"""
نتیجه نبرد سیاه

برگزار کننده : {organizer_mention}
حریف (پیوستن) : {joiner_mention}
مبلغ نبرد : {amount:,} سیاه
جایزه کل : {total_prize:,} سیاه
کمیسیون (5٪) : {commission:,} سیاه
جایزه خالص برنده : {net_winnings:,} سیاه

برنده نبرد : {winner_mention}

نکته: مبلغ {net_winnings:,} سیاه به حساب برنده اضافه شد.
"""
        try:
            await event.edit(result_text, buttons=None, parse_mode='md')
            await event.answer('✅ با موفقیت به نبرد پیوستید! برنده مشخص شد.', alert=False)
        except Exception as e:
            print(f"Error editing game message: {e}")
            await event.answer('⚠️ خطا در نمایش نتیجه. نبرد انجام شد، و مبلغ به حساب برنده اضافه شد.', alert=True)

async def check_force_joins(user_id):
    """بررسی عضویت در کانال‌های جوین اجباری"""
    force_joins = get_force_joins()
    if not force_joins:
        return True
    
    for channel in force_joins:
        channel_username = channel[2]
        if channel_username:
            try:
                entity = await bot.get_entity(channel_username)
                await bot.get_participant(entity, user_id)
            except UserNotParticipantError:
                return False
            except Exception:
                return False
    return True

def get_force_join_keyboard():
    """ساخت کیبورد جوین اجباری"""
    force_joins = get_force_joins()
    buttons = []
    
    for channel in force_joins:
        channel_link = channel[3]
        if channel_link:
            buttons.append([Button.url(f'📢 عضویت در کانال', channel_link)])
    
    buttons.append([Button.inline('✅ عضو شدم', b'check_force_join')])
    return buttons

async def handle_private_messages(event):
    user_id = event.sender_id
    text = event.text
    
    if text and text.startswith('/start'):
        
        init_user_db(user_id) 

        if get_main_setting('bot_enabled', '1') == '0':
            await event.reply('⚠️ ربات توسط مالک ( @ZadehMarG ) درحال ویرایش میباشد...')
            return

        # جوین اجباری
        join_mandatory = get_main_setting('join_mandatory', '0')
        if join_mandatory == '1' and user_id not in get_admins():
            if not await check_force_joins(user_id):
                buttons = get_force_join_keyboard()
                await event.reply('📢 برای استفاده از ربات باید در کانال‌های زیر عضو شوید:', buttons=buttons)
                return

        db = get_user_db(user_id)
        cursor = db.cursor()
        cursor.execute('SELECT banned FROM users WHERE user_id = ?', (user_id,))
        result = cursor.fetchone()
        
        if result and result[0] == 1:
            await event.reply('⛔ شما توسط مالک از سلف ساز سیاه بلاک شده اید.')
            db.close()
            return

        args = text.split()
        if len(args) > 1 and args[1].isdigit():
            referrer_id = int(args[1])

            if referrer_id != user_id:
                cursor.execute('SELECT invited_by FROM users WHERE user_id = ?', (user_id,))
                current_invited_by_result = cursor.fetchone()
                current_invited_by = current_invited_by_result[0] if current_invited_by_result else 0
                
                cursor.execute('SELECT referred_id FROM referrals WHERE referred_id = ?', (user_id,))
                already_referred = cursor.fetchone()
                
                if current_invited_by == 0 and not already_referred:
                    cursor.execute('UPDATE users SET invited_by = ? WHERE user_id = ?', (referrer_id, user_id))
                    db.commit()
                    
                    cursor.execute('INSERT INTO referrals (referrer_id, referred_id, reward_claimed) VALUES (?, ?, 1)', (referrer_id, user_id))
                    db.commit()
                    
                    init_user_db(referrer_id)
                    referrer_db = get_user_db(referrer_id)
                    referrer_cursor = referrer_db.cursor()
                    referrer_cursor.execute('UPDATE users SET balance = balance + ? WHERE user_id = ?', (REFERRAL_REWARD, referrer_id))
                    referrer_db.commit()
                    referrer_db.close()
                    
                    try:
                        await bot.send_message(referrer_id, f'🎉 هورااا ، تعداد {REFERRAL_REWARD} سیاه بابت دعوت کاربر جدید دریافت کردید')
                    except:
                        pass
        
        db.close()

        buttons = [
            [Button.inline('🛒 خرید سلف', b'buy_self')],
            [Button.inline('👤 حساب کاربری', b'user_account'), Button.inline('⚙️ مدیریت سلف', b'manage_self')],
            [Button.inline('📨 زیرمجموعه گیری', b'referral_system')],
            [Button.inline('👑 پنل مدیریت', b'admin_panel')] if user_id in get_admins() else []
        ]
        
        await event.reply('ســـــلف ساز | 𝐒𝐞𝐥𝐟 𝐒𝐢𝐨𝐡\n——————————————————————————————\n\n« اکانت خود را با سلف سیاه مدیریت کنید. »', buttons=buttons)
        return
    
    # ==================== CHECK FORCE JOIN CALLBACK ====================
    if text and text.startswith('/check_join'):
        if await check_force_joins(user_id):
            await event.reply('✅ عضویت شما تایید شد! حالا می‌توانید از ربات استفاده کنید.')
            buttons = [
                [Button.inline('🛒 خرید سلف', b'buy_self')],
                [Button.inline('👤 حساب کاربری', b'user_account'), Button.inline('⚙️ مدیریت سلف', b'manage_self')],
                [Button.inline('📨 زیرمجموعه گیری', b'referral_system')],
                [Button.inline('👑 پنل مدیریت', b'admin_panel')] if user_id in get_admins() else []
            ]
            await event.reply('ســـــلف ساز | 𝐒𝐞𝐥𝐟 𝐒𝐢𝐨𝐡\n——————————————————————————————\n\n« اکانت خود را با سلف سیاه مدیریت کنید. »', buttons=buttons)
        else:
            await event.reply('❌ هنوز عضو کانال‌ها نشده‌اید! لطفاً ابتدا عضو شوید.')
        return

    if user_id in user_clients and user_clients[user_id].get('step') == 'receipt':
        if event.photo:
            receipt_path = None
            try:
                receipt_path = await event.download_media()
                sender = event.sender
                user_info = f"آیدی: {user_id}\nنام: {sender.first_name}\nیوزرنیم: @{sender.username if sender.username else 'ندارد'}"

                amount = user_clients[user_id]['amount']
                black_amount = user_clients[user_id]['black_amount']
                
                buttons = [
                    [Button.inline('✅ تایید پرداخت', f'confirm_{user_id}_{amount}_{black_amount}'.encode())],
                    [Button.inline('❌ رد پرداخت', f'reject_{user_id}_{amount}'.encode())]
                ]
                
                invoice_text = f"""فاکتور خرید موجودی

{user_info}

تعداد سیاه: {black_amount:,}
مبلغ: {amount:,} تومان
تاریخ: {event.date.strftime('%Y/%m/%d %H:%M')}

رسید پرداخت:"""
                
                await bot.send_message(ADMIN_ID, invoice_text, file=receipt_path, buttons=buttons)
                await event.reply('✅ فاکتور شما برای مالک ارسال شد. منتظر تأیید باشید.')
            except Exception as e:
                print(f"Error sending receipt: {e}")
                await event.reply('⚠️ خطا در ارسال فاکتور. لطفاً با پشتیبانی تماس بگیرید.')
            
            finally:
                if receipt_path and os.path.exists(receipt_path):
                    os.remove(receipt_path)
                if user_id in user_clients:
                    del user_clients[user_id]
        else:
            await event.reply('⚠️ لطفاً عکس فیش واریزی را ارسال نمایید.')
        return
        
    if user_id not in user_clients:
        return

    step = user_clients[user_id].get('step')

    if step == 'phone':
        phone = text.strip()
        if not phone.startswith('+'):
            await event.reply('⚠️ شماره اکانت باید با + شروع شود.')
            return

        client = TelegramClient(StringSession(), API_ID, API_HASH)

        try:
            await client.connect()
            await client.send_code_request(phone)
        except Exception as e:
            await event.reply(f'⚠️ خطا در ارسال کد: {e}')
            try:
                await client.disconnect()
            except:
                 pass
            finally:
                 if user_id in user_clients:
                     del user_clients[user_id]
            return

        user_clients[user_id].update({
            'client': client,
            'phone': phone,
            'step': 'code',
            'timer': asyncio.create_task(code_timer(user_id))
        })
        await event.reply('📱 کد ورود را به فرمت 1.3.8.8.3.1 وارد کنید:')

    elif step == 'code':
        code = text.replace('.', '')
        client = user_clients[user_id]['client']
        if 'timer' in user_clients[user_id]:
            user_clients[user_id]['timer'].cancel()
        try:
            await client.sign_in(user_clients[user_id]['phone'], code)
            await handle_login_success(user_id, user_clients[user_id]['sub_type'])
        except SessionPasswordNeededError:
            user_clients[user_id]['step'] = 'password'
            await event.reply('🔐 رمز دو مرحله ای را وارد کنید:')
        except PhoneCodeInvalidError:
            await event.reply('❌ کد وارد شده اشتباه میباشد ، #لطفا مجدد تلاش کنید.')
            if 'client' in user_clients[user_id]:
                try:
                    await user_clients[user_id]['client'].disconnect()
                except:
                    pass
            del user_clients[user_id]
        except Exception as e:
            await event.reply(f'⚠️ خطا: {e}')
            try:
                await client.disconnect()
            except:
                pass
            del user_clients[user_id]

    elif step == 'password':
        password = text
        client = user_clients[user_id]['client']
        try:
            await client.sign_in(password=password)
            await handle_login_success(user_id, user_clients[user_id]['sub_type'])
        except Exception as e:
            await event.reply(f'❌ رمز اشتباه است: {e}')
            try:
                await client.disconnect()
            except:
                pass
            del user_clients[user_id]
            
    elif user_id in get_admins():
        if step == 'ban':
            try:
                target_id = int(text)
                ban_user(target_id, user_id, "بن توسط ادمین")
                await event.reply('✅ کاربر بن شد.')
            except ValueError:
                await event.reply('❌ آیدی نامعتبر میباشد.')
            del user_clients[user_id]
            await send_panel(event)
    
        elif step == 'unban':
            try:
                target_id = int(text)
                unban_user(target_id)
                await event.reply('✅ کاربر آن بن شد.')
            except ValueError:
                await event.reply('❌ آیدی نامعتبر.')
            del user_clients[user_id]
            await send_panel(event)
    
        elif step == 'add_force_join':
            channel_input = text.strip()
            try:
                channel_entity = await bot.get_entity(channel_input)
                channel_id = str(channel_entity.id)
                channel_username = channel_entity.username or channel_input
                channel_link = f"https://t.me/{channel_username}" if channel_username else ""
                
                add_force_join(channel_id, channel_username, channel_link)
                await event.reply(f'✅ کانال {channel_username} با موفقیت به لیست جوین اجباری اضافه شد.')
            except Exception as e:
                await event.reply(f'❌ خطا در افزودن کانال: {e}')
            del user_clients[user_id]
            await send_panel(event)
    
        elif step == 'remove_force_join':
            channel_input = text.strip()
            try:
                channel_entity = await bot.get_entity(channel_input)
                channel_id = str(channel_entity.id)
                remove_force_join(channel_id)
                await event.reply(f'✅ کانال با موفقیت از لیست جوین اجباری حذف شد.')
            except Exception as e:
                await event.reply(f'❌ خطا در حذف کانال: {e}')
            del user_clients[user_id]
            await send_panel(event)
    
        elif step == 'add_admin':
            try:
                target_id = int(text)
                if target_id in get_admins():
                    await event.reply('❌ این کاربر قبلاً ادمین است.')
                else:
                    add_admin(target_id, user_id)
                    await event.reply(f'✅ کاربر {target_id} با موفقیت به لیست ادمین‌ها اضافه شد.')
                    try:
                        await bot.send_message(target_id, '🎉 شما به عنوان ادمین ربات سلف ساز سیاه اضافه شدید.')
                    except:
                        pass
            except ValueError:
                await event.reply('❌ آیدی نامعتبر.')
            del user_clients[user_id]
            await send_panel(event)
    
        elif step == 'remove_admin':
            try:
                target_id = int(text)
                if target_id in OWNER_IDS:
                    await event.reply('❌ نمی‌توانید مالک را حذف کنید.')
                elif target_id not in get_admins():
                    await event.reply('❌ این کاربر ادمین نیست.')
                else:
                    remove_admin(target_id)
                    await event.reply(f'✅ کاربر {target_id} از لیست ادمین‌ها حذف شد.')
                    try:
                        await bot.send_message(target_id, '❌ شما از لیست ادمین‌های ربات سلف ساز سیاه حذف شدید.')
                    except:
                        pass
            except ValueError:
                await event.reply('❌ آیدی نامعتبر.')
            del user_clients[user_id]
            await send_panel(event)
    
        elif step == 'set_channel':
            channel = text.strip()
            if not channel.startswith('@'):
                 channel = '@' + channel
            set_main_setting('channel_username', channel)
            await event.reply('✅ کانال تنظیم شد.')
            del user_clients[user_id]
            await send_panel(event)
    
        elif step == 'set_card':
            card = text.strip()
            if not re.match(r'^\d{16}$|^\d{4}-\d{4}-\d{4}-\d{4}$', card.replace('-', '')):
                await event.reply('❌ شماره کارت نامعتبر. باید 16 رقم باشد.')
                return
            set_main_setting('card_number', card)
            await event.reply('✅ شماره کارت با موفقیت تنظیم شد.')
            del user_clients[user_id]
            await send_panel(event)
    
        elif step == 'broadcast':
            text_to_send = text
            users = []
            for db_file in glob.glob('database_users/user_*.db'):
                try:
                    match = re.search(r'user_(\d+)\.db', db_file)
                    if match:
                        users.append(int(match.group(1)))
                except:
                    continue
            
            sent = 0
            failed = 0
            for uid in users:
                try:
                    await bot.send_message(uid, text_to_send)
                    sent += 1
                    await asyncio.sleep(0.05)
                except:
                    failed += 1
            
            await event.reply(f'📢 ارسال همگانی انجام شد.\n✅ موفق: {sent}\n❌ ناموفق: {failed}')
            del user_clients[user_id]
            await send_panel(event)
        
        elif step == 'delete_user':
            try:
                target_id = int(text)
                if target_id in OWNER_IDS:
                    await event.reply('❌ نمی‌توانید مالک را حذف کنید.')
                else:
                    delete_user_data(target_id)
                    await event.reply(f'✅ کاربر {target_id} با موفقیت حذف شد.')
            except ValueError:
                await event.reply('❌ آیدی نامعتبر.')
            del user_clients[user_id]
            await send_panel(event)

@bot.on(events.CallbackQuery(data=b'buy_self'))
async def buy_self(event):
    user_id = event.sender_id
    
    db = get_user_db(user_id)
    cursor = db.cursor()
    cursor.execute('SELECT balance FROM users WHERE user_id = ?', (user_id,))
    result = cursor.fetchone()
    balance = result[0] if result else 0
    db.close()
    
    if balance < SELF_PRICE:
        await event.answer(f'❌ سیاه کافی ندارید!\nسیاه شما: {balance:,}\nسیاه مورد نیاز برای فعالسازی سلف : {SELF_PRICE}', alert=True)
        return

    await event.edit(f'🛒 برای خرید سلف لطفاً شماره اکانت خود را ارسال نمایید (با + شروع شود):')
    user_clients[user_id] = {'step': 'phone', 'sub_type': 0}

@bot.on(events.CallbackQuery(data=b'back'))
async def back(event):
    user_id = event.sender_id
    
    if user_id in user_clients and user_clients[user_id].get('step') in ['ban', 'unban', 'set_channel', 'set_card', 'add_force_join', 'remove_force_join', 'add_admin', 'remove_admin', 'broadcast', 'delete_user']:
        del user_clients[user_id]

    buttons = [
        [Button.inline('🛒 خرید سلف', b'buy_self')],
        [Button.inline('👤 حساب کاربری', b'user_account'), Button.inline('⚙️ مدیریت سلف', b'manage_self')],
        [Button.inline('📨 زیرمجموعه گیری', b'referral_system')],
        [Button.inline('👑 پنل مدیریت', b'admin_panel')] if user_id in get_admins() else []
    ]
    
    await event.edit('ســـــلف ساز | 𝐒𝐞𝐥𝐟 𝐒𝐢𝐨𝐡\n——————————————————————————————\n\n« اکانت خود را با سلف سیاه مدیریت کنید. »', buttons=buttons)

@bot.on(events.CallbackQuery(data=b'user_account'))
async def user_account(event):
    user_id = event.sender_id
    
    account_text = await get_user_info_for_group(user_id)
    
    buttons = [
        [Button.inline('💳 خرید موجودی', b'buy_balance_menu')],
        [Button.inline('🔙 برگشت', b'back')]
    ]
    
    try:
        await event.edit(account_text, buttons=buttons)
    except Exception as e:
        print(f"Error editing user account: {e}")

@bot.on(events.CallbackQuery(data=b'referral_system'))
async def referral_system(event):
    user_id = event.sender_id
    db = get_user_db(user_id)
    cursor = db.cursor()
    
    cursor.execute('SELECT COUNT(*) FROM referrals WHERE referrer_id = ?', (user_id,))
    total_referrals = cursor.fetchone()[0]
    db.close()
    
    bot_username = (await bot.get_me()).username
    referral_link = f"https://t.me/{bot_username}?start={user_id}"
    
    referral_text = f"""با دعوت دوستان خود به ربات سلف ساز سیاه {REFERRAL_REWARD} سیاه دریافت کنید..

کل دعوتی های پاداش دار: {total_referrals}
پاداش دریافتی به ازای هر نفر: {REFERRAL_REWARD} سیاه
لینک دعوت: 
`{referral_link}`

متن بنر زیر مجموعه گیری"""
    
    buttons = [
        [Button.inline('🔙 برگشت', b'back')]
    ]
    try:
        await event.edit(referral_text, buttons=buttons)
    except Exception as e:
        print(f"Error editing referral system: {e}")

@bot.on(events.CallbackQuery(data=b'buy_balance_menu'))
async def buy_balance_menu(event):
    user_id = event.sender_id
    
    if user_id not in user_purchase_amount or isinstance(user_purchase_amount.get(user_id), dict):
        user_purchase_amount[user_id] = '0'
        
    current_amount = user_purchase_amount.get(user_id, '0')
    
    try:
        black_amount = int(current_amount)
    except ValueError:
        black_amount = 0
        user_purchase_amount[user_id] = '0'
            
    amount = black_amount * BLACK_TO_TOMAN_RATE
    
    buttons = [
        [Button.inline('1', b'num_1'), Button.inline('2', b'num_2'), Button.inline('3', b'num_3')],
        [Button.inline('4', b'num_4'), Button.inline('5', b'num_5'), Button.inline('6', b'num_6')],
        [Button.inline('7', b'num_7'), Button.inline('8', b'num_8'), Button.inline('9', b'num_9')],
        [Button.inline('0', b'num_0'), Button.inline('۰۰', b'num_00')],
        [Button.inline('✅ تایید', b'confirm_amount'), Button.inline('🗑 حذف', b'clear_amount')],
        [Button.inline('🔙 برگشت', b'back')]
    ]
    
    display_text = f"خرید موجودی\n\nتعداد سیاه: {black_amount:,}\nمبلغ: {amount:,} تومان\n\nلطفاً تعداد سیاه مورد نظر را انتخاب کنید:"
    
    try:
        await event.edit(display_text, buttons=buttons)
    except Exception as e:
        print(f"Error editing buy balance menu: {e}")

@bot.on(events.CallbackQuery(pattern=b'num_(.+)$'))
async def number_input(event):
    user_id = event.sender_id
    number = event.data.decode().split('_')[1]
    
    current_amount = user_purchase_amount.get(user_id, '0')
    
    if isinstance(current_amount, dict):
        current_amount = '0'
        
    if number == '00':
        if current_amount == '0':
            new_amount = '0'
        else:
            new_amount = current_amount + '00'
    else:
        new_amount = current_amount + number
    
    if len(new_amount) > 10:
        await event.answer('⚠️ مقدار وارد شده جهت خرید بسیار بزرگ است!', alert=True)
        return
    
    if new_amount.startswith('0') and len(new_amount) > 1:
        new_amount = new_amount.lstrip('0')
    if not new_amount:
        new_amount = '0'
        
    user_purchase_amount[user_id] = new_amount

    
    buttons = [
        [Button.inline('1', b'num_1'), Button.inline('2', b'num_2'), Button.inline('3', b'num_3')],
        [Button.inline('4', b'num_4'), Button.inline('5', b'num_5'), Button.inline('6', b'num_6')],
        [Button.inline('7', b'num_7'), Button.inline('8', b'num_8'), Button.inline('9', b'num_9')],
        [Button.inline('0', b'num_0'), Button.inline('۰۰', b'num_00')],
        [Button.inline('✅ تایید', b'confirm_amount'), Button.inline('🗑 حذف', b'clear_amount')],
        [Button.inline('🔙 برگشت', b'back')]
    ]
    
    current_amount_str = user_purchase_amount.get(user_id, '0')
    if isinstance(current_amount_str, dict):
        current_amount_str = '0'
    try:
        black_amount = int(current_amount_str)
    except ValueError:
        black_amount = 0
    amount = black_amount * BLACK_TO_TOMAN_RATE
    
    display_text = f"خرید موجودی\n\nتعداد سیاه: {black_amount:,}\nمبلغ: {amount:,} تومان\n\nلطفاً تعداد سیاه مورد نظر را انتخاب کنید:"
    
    try:
        await event.edit(display_text, buttons=buttons)
        await event.answer()
    except Exception as e:
        print(f"Error editing number input: {e}")

@bot.on(events.CallbackQuery(data=b'clear_amount'))
async def clear_amount(event):
    user_id = event.sender_id
    user_purchase_amount[user_id] = '0'
    
    buttons = [
        [Button.inline('1', b'num_1'), Button.inline('2', b'num_2'), Button.inline('3', b'num_3')],
        [Button.inline('4', b'num_4'), Button.inline('5', b'num_5'), Button.inline('6', b'num_6')],
        [Button.inline('7', b'num_7'), Button.inline('8', b'num_8'), Button.inline('9', b'num_9')],
        [Button.inline('0', b'num_0'), Button.inline('۰۰', b'num_00')],
        [Button.inline('✅ تایید', b'confirm_amount'), Button.inline('🗑 حذف', b'clear_amount')],
        [Button.inline('🔙 برگشت', b'back')]
    ]
    
    display_text = f"خرید موجودی\n\nتعداد سیاه: 0\nمبلغ: 0 تومان\n\nلطفاً تعداد سیاه مورد نظر را انتخاب کنید:"
    
    try:
        await event.edit(display_text, buttons=buttons)
        await event.answer()
    except Exception as e:
        print(f"Error editing clear amount: {e}")

@bot.on(events.CallbackQuery(data=b'confirm_amount'))
async def confirm_amount(event):
    user_id = event.sender_id
    current_amount_str = user_purchase_amount.get(user_id, '0')
    
    if isinstance(current_amount_str, dict):
        await event.answer('⚠️ خطای داخلی: مقدار خرید نامعتبر.', alert=True)
        return

    try:
        black_amount = int(current_amount_str)
    except ValueError:
        black_amount = 0
    
    if black_amount <= 0:
        await event.answer('⚠️ لطفاً مقدار معتبر وارد کنید!', alert=True)
        return
    
    amount = black_amount * BLACK_TO_TOMAN_RATE
    card_number = get_main_setting('card_number', 'تنظیم نشده')
    
    invoice_text = f"""فاکتور خرید موجودی

اطلاعات خریدار:
آیدی: {user_id}
نام: {event.sender.first_name}
یوزرنیم: @{event.sender.username if event.sender.username else 'ندارد'}

تعداد سیاه: {black_amount:,}
مبلغ قابل پرداخت: {amount:,} تومان
شماره کارت: {card_number}

لطفاً پس از پرداخت، عکس فیش واریزی را ارسال نمایید."""

    buttons = [
        [Button.inline('💳 پرداخت', b'proceed_payment')],
        [Button.inline('❌ لغو', b'cancel_payment')]
    ]
    
    user_purchase_amount[user_id] = {'black_amount': black_amount, 'amount': amount}
    
    try:
        await event.edit(invoice_text, buttons=buttons)
        await event.answer()
    except Exception as e:
        print(f"Error editing confirm amount: {e}")

@bot.on(events.CallbackQuery(data=b'proceed_payment'))
async def proceed_payment(event):
    user_id = event.sender_id
    
    if user_id not in user_purchase_amount or isinstance(user_purchase_amount[user_id], str):
        await event.answer('⚠️ خطای داخلی: مقدار خرید نامعتبر.', alert=True)
        return

    purchase_data = user_purchase_amount[user_id]
    black_amount = purchase_data['black_amount']
    amount = purchase_data['amount']
    
    user_clients[user_id] = {
        'step': 'receipt',
        'amount': amount,
        'black_amount': black_amount
    }
    
    card_number = get_main_setting('card_number', 'تنظیم نشده')
    
    try:
        await event.edit(f'💳 لطفاً مبلغ {amount:,} تومان (معادل {black_amount:,} سیاه) را به کارت {card_number} واریز کنید و عکس فیش واریزی خود را ارسال نمایید.')
        await event.answer()
    except Exception as e:
        print(f"Error editing proceed payment: {e}")
    finally:
        if user_id in user_purchase_amount and not isinstance(user_purchase_amount[user_id], str):
             del user_purchase_amount[user_id]


@bot.on(events.CallbackQuery(data=b'cancel_payment'))
async def cancel_payment(event):
    user_id = event.sender_id
    if user_id in user_purchase_amount:
        del user_purchase_amount[user_id]
    
    buttons = [
        [Button.inline('💳 خرید موجودی', b'buy_balance_menu')],
        [Button.inline('🔙 برگشت', b'back')]
    ]
    try:
        await event.edit('❌ خرید لغو شد.', buttons=buttons)
        await event.answer('خرید لغو شد.')
    except Exception as e:
        print(f"Error editing cancel payment: {e}")

@bot.on(events.CallbackQuery(data=b'manage_self'))
async def manage_self(event):
    user_id = event.sender_id
    session_data = get_self_session(user_id)
    
    if not session_data:
        await event.answer('⚠️ رفیق سلف فعال نکردی درسته ؟', alert=True)
        return
    
    session_string, sub_type, start_time = session_data
    
    current_time = int(time.time())
    elapsed_time = current_time - start_time
    
    days = elapsed_time // 86400
    hours = (elapsed_time % 86400) // 3600
    
    db = get_user_db(user_id)
    cursor = db.cursor()
    cursor.execute('SELECT balance FROM users WHERE user_id = ?', (user_id,))
    result = cursor.fetchone()
    balance = result[0] if result else 0
    db.close()
    
    remaining_hours = balance // 2 
    
    status_text = f"""
وضعیت سلف فعال

⏱ مدت زمان فعال بودن: {days} روز و {hours} ساعت
💰 موجودی سیاه: {balance:,}
⏳ زمان باقی مانده: {remaining_hours} ساعت

مدیریت سلف:
"""
    
    buttons = [
        [Button.inline('🔴 خاموش کردن سلف', b'disable_self')],
        [Button.inline('🔙 برگشت', b'back')]
    ]
    
    try:
        await event.edit(status_text, buttons=buttons)
        await event.answer()
    except Exception as e:
        print(f"Error editing manage self: {e}")

@bot.on(events.CallbackQuery(data=b'disable_self'))
async def disable_self(event):
    user_id = event.sender_id
    deactivate_self_session(user_id)
    stop_self_py(user_id)
    try:
        await event.edit('✅ سلف با موفقیت خاموش شد.')
        await event.answer('سلف خاموش شد.')
    except Exception as e:
        print(f"Error editing disable self: {e}")
    await back(event)

@bot.on(events.CallbackQuery(pattern=b'confirm_(\\d+)_(\\d+)_(\\d+)'))
async def confirm(event):
    if event.sender_id != ADMIN_ID:
        return
    try:
        data_parts = event.data.decode().split('_')
        user_id = int(data_parts[1])
        amount = int(data_parts[2])
        black_amount = int(data_parts[3])
    except:
        await event.answer('⚠️ خطای داده!', alert=True)
        return
    
    init_user_db(user_id)
    db = get_user_db(user_id)
    cursor = db.cursor()
    cursor.execute('UPDATE users SET balance = balance + ? WHERE user_id = ?', (black_amount, user_id))
    db.commit()
    db.close()
    
    add_transaction(user_id, 'deposit', black_amount, f'شارژ {black_amount} سیاه')
    
    try:
        await bot.send_message(user_id, f'✅ پرداخت شما تأیید شد!\n{black_amount:,} سیاه به حساب شما اضافه شد.')
    except Exception as e:
        print(f"Error sending message to user {user_id}: {e}")
    
    try:
        await event.edit(f'✅ پرداخت کاربر {user_id} برای {black_amount:,} سیاه تأیید شد.')
    except Exception as e:
        print(f"Error editing confirm: {e}")
    await send_panel(event)

@bot.on(events.CallbackQuery(pattern=b'reject_(\\d+)_(\\d+)'))
async def reject(event):
    if event.sender_id != ADMIN_ID:
        return
    try:
        data_parts = event.data.decode().split('_')
        user_id = int(data_parts[1])
    except:
        await event.answer('⚠️ خطای داده!', alert=True)
        return
        
    try:
        await bot.send_message(user_id, '❌ پرداخت شما رد شد. لطفاً با پشتیبانی تماس بگیرید.')
    except Exception as e:
        print(f"Error sending message to user {user_id}: {e}")
    
    try:
        await event.edit(f'❌ پرداخت کاربر {user_id} رد شد.')
    except Exception as e:
        print(f"Error editing reject: {e}")
    await send_panel(event)

@bot.on(events.CallbackQuery(data=b'restart_self_all'))
async def restart_all_selfs_handler(event):
    if event.sender_id not in get_admins():
        await event.answer('⛔ شما دسترسی ندارید!', alert=True)
        return
    
    initial_text = '⏳ در حال شروع فرآیند ریستارت سلف های فعال کاربران...'
    try:
        await event.edit(initial_text)
    except Exception:
        await event.answer('در حال ریستارت...')
        
    try:
        count = await restart_all_selfs()
        await event.edit(f'✅ فرآیند ریستارت با موفقیت انجام شد. {count} سلف کاربر ریستارت شدند.')
    except Exception as e:
        print(f"Error restarting all selfs: {e}")
        try:
            await event.edit('⚠️ خطا در ریستارت سلف ها. جزئیات خطا در کنسول ثبت شد.')
        except:
             pass
        
    await asyncio.sleep(3)
    await send_panel(event)

@bot.on(events.CallbackQuery(data=b'check_force_join'))
async def check_force_join_callback(event):
    """بررسی عضویت بعد از کلیک روی دکمه عضو شدم"""
    user_id = event.sender_id
    
    if await check_force_joins(user_id):
        await event.answer('✅ عضویت شما تایید شد!', alert=True)
        buttons = [
            [Button.inline('🛒 خرید سلف', b'buy_self')],
            [Button.inline('👤 حساب کاربری', b'user_account'), Button.inline('⚙️ مدیریت سلف', b'manage_self')],
            [Button.inline('📨 زیرمجموعه گیری', b'referral_system')],
            [Button.inline('👑 پنل مدیریت', b'admin_panel')] if user_id in get_admins() else []
        ]
        try:
            await event.edit('✅ عضویت شما تایید شد! حالا می‌توانید از ربات استفاده کنید.', buttons=buttons)
        except:
            await event.edit('ســـــلف ساز | 𝐒𝐞𝐥𝐟 𝐒𝐢𝐨𝐡\n——————————————————————————————\n\n« اکانت خود را با سلف سیاه مدیریت کنید. »', buttons=buttons)
    else:
        await event.answer('❌ هنوز عضو کانال‌ها نشده‌اید!', alert=True)

async def send_panel(event):
    if event.sender_id not in get_admins():
        return
        
    bot_enabled = get_main_setting('bot_enabled', '1')
    join_mandatory = get_main_setting('join_mandatory', '0')
    channel = get_main_setting('channel_username', 'تنظیم نشده')
    card = get_main_setting('card_number', 'تنظیم نشده')
    self_price = int(get_main_setting('self_price', SELF_PRICE))
    black_rate = int(get_main_setting('black_rate', BLACK_TO_TOMAN_RATE))
    
    db_path = 'database_users'
    total_users = 0
    if os.path.exists(db_path):
        for filename in os.listdir(db_path):
            if filename.startswith('user_') and filename.endswith('.db'):
                total_users += 1

    active_sessions = get_all_active_sessions()
    active_self_count = len(active_sessions)
    
    total_balance = 0
    for db_file in glob.glob('database_users/user_*.db'):
        try:
            db = sqlite3.connect(db_file)
            cursor = db.cursor()
            cursor.execute('SELECT SUM(balance) FROM users')
            result = cursor.fetchone()
            if result and result[0]:
                total_balance += result[0]
            db.close()
        except:
            pass
    
    force_joins = get_force_joins()
    force_count = len(force_joins)
    
    admins = get_admins()
    admin_count = len(admins)
    
    banned_count = 0
    for db_file in glob.glob('database_users/user_*.db'):
        match = re.search(r'user_(\d+)\.db', db_file)
        if match:
            if is_banned_main(int(match.group(1))):
                banned_count += 1

    status_text = f"""
👑 پنل مدیریت پیشرفته

📊 آمار ربات:
┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄
👥 کاربران کل: {total_users:,}
🟢 سلف‌های فعال: {active_self_count:,}
💰 کل سیاه در گردش: {total_balance:,}
💰 ارزش کل سیاه: {total_balance * black_rate:,} تومان
👑 تعداد ادمین‌ها: {admin_count}
⛔ کاربران بن شده: {banned_count}
📢 کانال‌های جوین: {force_count}

⚙️ تنظیمات:
┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄
🔌 وضعیت ربات: {"🟢 روشن" if bot_enabled == "1" else "🔴 خاموش"}
📢 جوین اجباری: {"✅ فعال" if join_mandatory == "1" else "❌ غیرفعال"}
📢 کانال پیشفرض: {channel}
💳 شماره کارت: {card}
💰 قیمت سلف: {self_price} سیاه
💰 نرخ تبدیل: هر سیاه = {black_rate} تومان
💰 پاداش دعوت: {REFERRAL_REWARD} سیاه
💰 کمیسیون نبرد: {int(COMMISSION_RATE * 100)}%

📋 منوی مدیریت:
┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄
"""
    
    buttons = [
        [Button.inline(f'🔌 ربات {"🟢 روشن" if bot_enabled == "1" else "🔴 خاموش"}', b'toggle_bot')],
        [Button.inline('⛔ بن کاربر', b'ban_user'), Button.inline('✅ آن بن کاربر', b'unban_user')],
        [Button.inline('📢 مدیریت جوین اجباری', b'manage_force_join')],
        [Button.inline('👑 مدیریت ادمین‌ها', b'manage_admins')],
        [Button.inline('💳 تنظیم کارت', b'set_card')],
        [Button.inline('📢 تنظیم کانال', b'set_channel')],
        [Button.inline('📊 تراکنش‌ها', b'view_transactions')],
        [Button.inline('📨 ارسال همگانی', b'broadcast')],
        [Button.inline('🔄 ریستارت سلف کاربران', b'restart_self_all')],
        [Button.inline('🗑 حذف کاربر', b'delete_user')],
        [Button.inline('🔙 برگشت', b'back')]
    ]
    
    try:
        await event.edit(status_text, buttons=buttons)
    except Exception as e:
        print(f"Error editing send panel: {e}")

@bot.on(events.CallbackQuery(data=b'admin_panel'))
async def admin_panel_handler(event):
    if event.sender_id not in get_admins():
        await event.answer('⛔ شما دسترسی ندارید!', alert=True)
        return
    await send_panel(event)

@bot.on(events.CallbackQuery(data=b'toggle_bot'))
async def toggle_bot(event):
    if event.sender_id not in get_admins():
        return
    current = get_main_setting('bot_enabled', '1')
    new = '0' if current == '1' else '1'
    set_main_setting('bot_enabled', new)
    await send_panel(event)

@bot.on(events.CallbackQuery(data=b'toggle_join'))
async def toggle_join(event):
    if event.sender_id not in get_admins():
        return
    current = get_main_setting('join_mandatory', '0')
    new = '0' if current == '1' else '1'
    set_main_setting('join_mandatory', new)
    await send_panel(event)

@bot.on(events.CallbackQuery(data=b'ban_user'))
async def ban_user_handler(event):
    if event.sender_id not in get_admins():
        return
    await event.edit('⛔ آیدی کاربر را وارد کنید:\n(برای بن کردن کاربر)')
    user_clients[event.sender_id] = {'step': 'ban'}

@bot.on(events.CallbackQuery(data=b'unban_user'))
async def unban_user_handler(event):
    if event.sender_id not in get_admins():
        return
    await event.edit('✅ آیدی کاربر را وارد کنید:\n(برای آنبن کردن کاربر)')
    user_clients[event.sender_id] = {'step': 'unban'}

@bot.on(events.CallbackQuery(data=b'manage_force_join'))
async def manage_force_join(event):
    if event.sender_id not in get_admins():
        return
    
    force_joins = get_force_joins()
    text = "📢 مدیریت جوین اجباری\n\n"
    
    if force_joins:
        text += "کانال‌های فعلی:\n"
        for ch in force_joins:
            text += f"• {ch[2]} - {ch[3]}\n"
    else:
        text += "هیچ کانالی ثبت نشده است.\n"
    
    text += "\nلطفاً یکی از گزینه‌های زیر را انتخاب کنید:"
    
    buttons = [
        [Button.inline('➕ افزودن کانال', b'add_force_join')],
        [Button.inline('➖ حذف کانال', b'remove_force_join')],
        [Button.inline('🔙 برگشت', b'back_to_panel')]
    ]
    
    try:
        await event.edit(text, buttons=buttons)
    except Exception as e:
        print(f"Error editing manage force join: {e}")

@bot.on(events.CallbackQuery(data=b'add_force_join'))
async def add_force_join_handler(event):
    if event.sender_id not in get_admins():
        return
    await event.edit('➕ یوزرنیم یا لینک کانال را وارد کنید:')
    user_clients[event.sender_id] = {'step': 'add_force_join'}

@bot.on(events.CallbackQuery(data=b'remove_force_join'))
async def remove_force_join_handler(event):
    if event.sender_id not in get_admins():
        return
    await event.edit('➖ یوزرنیم یا آیدی کانال را وارد کنید:')
    user_clients[event.sender_id] = {'step': 'remove_force_join'}

@bot.on(events.CallbackQuery(data=b'manage_admins'))
async def manage_admins(event):
    if event.sender_id not in get_admins():
        return
    
    admins = get_admins()
    text = "👑 مدیریت ادمین‌ها\n\n"
    text += f"تعداد ادمین‌ها: {len(admins)}\n\n"
    
    if admins:
        text += "لیست ادمین‌ها:\n"
        for admin_id in admins:
            if admin_id in OWNER_IDS:
                text += f"• {admin_id} 👑 (مالک)\n"
            else:
                text += f"• {admin_id}\n"
    else:
        text += "هیچ ادمینی ثبت نشده است.\n"
    
    buttons = [
        [Button.inline('➕ افزودن ادمین', b'add_admin')],
        [Button.inline('➖ حذف ادمین', b'remove_admin')],
        [Button.inline('🔙 برگشت', b'back_to_panel')]
    ]
    
    try:
        await event.edit(text, buttons=buttons)
    except Exception as e:
        print(f"Error editing manage admins: {e}")

@bot.on(events.CallbackQuery(data=b'add_admin'))
async def add_admin_handler(event):
    if event.sender_id not in get_admins():
        return
    await event.edit('➕ آیدی عددی کاربر جدید را وارد کنید:')
    user_clients[event.sender_id] = {'step': 'add_admin'}

@bot.on(events.CallbackQuery(data=b'remove_admin'))
async def remove_admin_handler(event):
    if event.sender_id not in get_admins():
        return
    await event.edit('➖ آیدی عددی ادمین را وارد کنید:')
    user_clients[event.sender_id] = {'step': 'remove_admin'}

@bot.on(events.CallbackQuery(data=b'set_card'))
async def set_card_handler(event):
    if event.sender_id not in get_admins():
        return
    await event.edit('💳 شماره کارت را به صورت 16 رقمی وارد کنید:')
    user_clients[event.sender_id] = {'step': 'set_card'}

@bot.on(events.CallbackQuery(data=b'set_channel'))
async def set_channel_handler(event):
    if event.sender_id not in get_admins():
        return
    await event.edit('📢 یوزرنیم کانال را با @ وارد کنید:')
    user_clients[event.sender_id] = {'step': 'set_channel'}

@bot.on(events.CallbackQuery(data=b'view_transactions'))
async def view_transactions(event):
    if event.sender_id not in get_admins():
        return
    
    transactions = get_transactions(limit=20)
    text = "📊 آخرین تراکنش‌ها:\n\n"
    
    if not transactions:
        text += "هیچ تراکنشی ثبت نشده است."
    else:
        for t in transactions[:20]:
            text += f"• کاربر {t[1]}: {t[2]} {t[3]:,} - {t[4]}\n{t[5]}\n\n"
    
    buttons = [
        [Button.inline('🔙 برگشت', b'back_to_panel')]
    ]
    
    try:
        await event.edit(text, buttons=buttons)
    except Exception as e:
        print(f"Error editing view transactions: {e}")

@bot.on(events.CallbackQuery(data=b'broadcast'))
async def broadcast_handler(event):
    if event.sender_id not in get_admins():
        return
    await event.edit('📨 متن پیام برای ارسال همگانی را وارد کنید:')
    user_clients[event.sender_id] = {'step': 'broadcast'}

@bot.on(events.CallbackQuery(data=b'delete_user'))
async def delete_user_handler(event):
    if event.sender_id not in get_admins():
        return
    await event.edit('🗑 آیدی عددی کاربر را برای حذف کامل وارد کنید:\n⚠️ این عمل غیرقابل بازگشت است!')
    user_clients[event.sender_id] = {'step': 'delete_user'}

@bot.on(events.CallbackQuery(data=b'back_to_panel'))
async def back_to_panel(event):
    if event.sender_id not in get_admins():
        return
    await send_panel(event)

@bot.on(events.NewMessage(pattern='/panel'))
async def panel_command(event):
    if event.sender_id not in get_admins():
        await event.reply('⛔ شما دسترسی ندارید!')
        return
    
    buttons = [
        [Button.inline('👑 پنل مدیریت', b'admin_panel')],
        [Button.inline('🔙 منو اصلی', b'back')]
    ]
    await event.reply('برای دسترسی به پنل مدیریت روی دکمه زیر کلیک کنید:', buttons=buttons)

@bot.on(events.NewMessage(pattern=r'/sioh\s+(\d+)\s+(\d+)'))
async def transfer_sioh(event):
    user_id = event.sender_id
    try:
        match = event.pattern_match
        amount = int(match.group(1))
        target_id = int(match.group(2))
        
        if amount <= 0:
            await event.reply('❌ مقدار باید بیشتر از صفر باشد.')
            return
            
        if user_id == target_id:
            await event.reply('❌ نمی توانید به خودتان سیاه انتقال دهید.')
            return
        
        db = get_user_db(user_id)
        cursor = db.cursor()
        cursor.execute('SELECT balance FROM users WHERE user_id = ?', (user_id,))
        result = cursor.fetchone()
        sender_balance = result[0] if result else 0
        db.close()
        
        if sender_balance < amount:
            await event.reply(f'❌ سیاه کافی ندارید!\nسیاه شما: {sender_balance:,}')
            return
        
        init_user_db(target_id)
        target_db = get_user_db(target_id)
        target_cursor = target_db.cursor()
        target_cursor.execute('UPDATE users SET balance = balance + ? WHERE user_id = ?', (amount, target_id))
        target_db.commit()
        target_db.close()
        
        db = get_user_db(user_id)
        cursor = db.cursor()
        cursor.execute('UPDATE users SET balance = balance - ? WHERE user_id = ?', (amount, user_id))
        db.commit()
        db.close()
        
        await event.reply(f'✅ انتقال موفق!\n{amount:,} سیاه به کاربر {target_id} انتقال یافت.')
        try:
            await bot.send_message(target_id, f'💰 دریافت سیاه!\nکاربر {user_id} به شما {amount:,} سیاه انتقال داد.')
        except:
            pass
        
    except Exception as e:
        await event.reply(f'⚠️ خطا در انتقال: {e}')

print("Bot is running...")
bot.run_until_disconnected()