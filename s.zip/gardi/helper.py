# helper1.py - جدید با ساختار helper2 ولی دکمه‌ها و متون خودش

from telethon import TelegramClient, functions, events, errors
from telethon.tl import types
from telethon.tl.custom import Button
import os, sqlite3, json, asyncio
from config import *

event = TelegramClient("Helper", api_id, api_hash)
event.start(bot_token=token)

# ==================== دیتابیس ====================
time_default = json.dumps({'time_name': 'off', 'time_bio': 'off'})
pvblock_default = json.dumps({'lockpv': 'off', 'block': 'off', 'delmessage': 'on'})
action_default = json.dumps({
    'typing': 'off', 'upload_photo': 'off', 'record_video': 'off',
    'upload_video': 'off', 'record_audio': 'off', 'upload_audio': 'off',
    'upload_document': 'off', 'choose_sticker': 'off', 'record_note': 'off',
    'upload_note': 'off', 'gamming': 'off', 'choose_contact': 'off'
})
mode_default = json.dumps({
    'boldmode': 'off', 'codemode': 'off',
    'underline': 'off', 'strikemode': 'off', 'spoilermode': 'off'
})
time_int_default = json.dumps({
    '1': 'on', '2': 'off', '3': 'off', '4': 'off', '5': 'off',
    '6': 'off', '7': 'off', '8': 'off', '9': 'off', '10': 'off'
})

authorized_users = set()

def get_user_db_path(user_id):
    if not os.path.exists('database_users'):
        os.makedirs('database_users')
    return f'database_users/data_{user_id}.db'

def query(user_id, x):
    db_path = get_user_db_path(user_id)
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        result = cursor.execute(f"SELECT {x} FROM SELF").fetchall()[0][0]
        conn.close()
        if result is None:
            raise IndexError
        return result
    except:
        if x == 'time': return time_default
        if x == 'mode': return mode_default
        if x == 'action': return action_default
        if x in ['time_int_name', 'time_int_bio']: return time_int_default
        if x == 'lockpv': return pvblock_default
        if x in ['enemy_list', 'mute_list', 'answer_list']: return "[]"
        if x == 'insult_list': return json.dumps(['fuck your mother'])
        if x == 'gpt' or x == 'answer': return "off"
        if x == 'lang': return "en"
        return None

def update_SQLITE(user_id, x, y):
    db_path = get_user_db_path(user_id)
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute(f"UPDATE SELF SET {x}=?", (y,))
    conn.commit()
    conn.close()

# ==================== متون راهنما (همون متون helper1) ====================
help_info_user = """
<blockquote>🆔 اطلاعات کاربر

با این دستور اطلاعات کامل کاربر رو پیدا کن.

↲ دستور:
`ایدی` + ریپلای
`ایدی` @یوزرنیم</blockquote>
"""

help_antilogin = """
<blockquote>🔐 ضد لاگین

از ورود غیرمجاز به اکانتت جلوگیری کن!

↲ دستور:
`ضد لاگین روشن`  
`ضد لاگین خاموش`</blockquote>
"""

help_online = """
<blockquote>🟢 انلاینی

با این بخش میتونید همیشه اکانتونو آنلاین نگه دارید

↲ دستور:
`انلاینی روشن`
`انلاینی خاموش`</blockquote>
"""

help_clone = """
<blockquote>🧬 کلون

با این دستور میتونید پروفایل هر شخصی رو کپی کنید!

↲ دستور:
`کلون` + ریپلای</blockquote>
"""

help_delete = """
<blockquote>🗑 حذف پیام انبوه

چندتا پیام آخر چت رو سریع پاک کن!

↲ دستور:
`حذف` [تعداد]  
`حذف` + ریپلای</blockquote>
"""

help_animation = """
<blockquote>🎮 سرگرمی

دستورهای فان و باحال برای چت

↲ دستور:
`جق`</blockquote>
"""

help_riket = """
<blockquote>👍 ریکت خودکار

هر کی بهت پیام بده یا توی گروه چیزی بفرسته،  
خودکار ریکت دلخواهت رو براش بذار!

↲ دستور:
`ریکت روشن`  
`ریکت خاموش`  
`ریکت` [ایموجی] + ریپلای  
`حذف ریکت` + ریپلای  
`لیست ریکت`  
`پاکسازی لیست ریکت`</blockquote>
"""

help_spam = """
<blockquote>🚀 اسپم پیام

پیامتو انقدر تکرار کن که طرف دیوونه بشه

↲ دستور:
`اسپم` [تعداد] [متن]  
`اسپم سریع` [تعداد] [متن]</blockquote>
"""

help_download = """
<blockquote>📥 دانلودر و کپی پست

هر پستی که بخوای از هر کانال یا گروهی دانلود کن یا کپی کن توی سیو مسیجت

↲ دستور:
`دانلود` [لینک پست]</blockquote>
"""

help_logo = """
<blockquote>🎨 ساخت لوگو

با اسم انگلیسی و یه طرح خفن، تو چند ثانیه لوگو بساز!

↲ دستور:
`لوگو` [اسم انگلیسی] [عدد طرح]</blockquote>
"""

help_game = """
<blockquote>🎲 تقلب در بازی‌های تلگرام

هر چی دلت خواست تو تاس، دارت، بولینگ و ... برنده شو!

↲ دستور:
`تاس` [عدد ۱-۶]  
`دارت`  
`بولینگ`  
`بسکتبال`  
`فوتبال` [۱ یا ۴]  
`کازینو`</blockquote>
"""

help_convert = """
<blockquote>🔄 تبدیل های مدیا

استیکر، عکس، گیف رو به هم تبدیل کن!

↲ دستور:
`تبدیل استیکر به عکس` + ریپلای  
`تبدیل عکس به استیکر` + ریپلای  
`فیلم به گیف` + ریپلای</blockquote>
"""

help_management = """
<blockquote>🚫 مدیریت اکانت

کاربرای مزاحم رو کنترل کن!

↲ دستور:
`بلاک` + ریپلای  
`انبلاک` + ریپلای</blockquote>
"""

help_sakot = """
<blockquote>🔇 سکوت کردن کاربر

پیامای طرف رو خودکار حذف کن!

↲ دستور:
`سکوت` + ریپلای  
`حذف سکوت` + ریپلای  
`لیست سکوت`  
`پاکسازی لیست سکوت`</blockquote>
"""

help_enemy_friend = """
<blockquote>😈 دشمن و دوست

دشمناتو اذیت کن، دوستاتو خوشحال!

**دشمن:**
`تنظیم دشمن` + ریپلای  
`حذف دشمن` + ریپلای  
`لیست دشمن`  
`پاکسازی لیست دشمن`

**دوست:**
`تنظیم دوست` + ریپلای  
`حذف دوست` + ریپلای  
`لیست دوست`  
`پاکسازی لیست دوست`</blockquote>
"""

help_pvlock = """
<blockquote>🔒 قفل‌ها

ارسال بعضی نوع پیام‌ها رو کامل ببند!

↲ دستور:
`قفل پیوی` روشن/خاموش
`قفل استیکر` روشن/خاموش
`قفل فوروارد` روشن/خاموش
`قفل گیف` روشن/خاموش
`قفل لینک` روشن/خاموش
`قفل عکس` روشن/خاموش
`قفل ویدیو` روشن/خاموش
`قفل ریپلای` روشن/خاموش</blockquote>
"""

help_secretary = """
<blockquote>👩‍💼 منشی پیشرفته

هر کی بهت پیام داد، خودکار جواب بده!

↲ دستور:
`منشی` روشن/خاموش
`متن منشی` [متن]</blockquote>
"""

help_filter = """
<blockquote>🚫 فیلترکلمات

کلمات ممنوعه رو حذف کن!

↲ دستور:
`فیلتر کلمات` روشن/خاموش
`فیلتر کلمه` [کلمه]  
`حذف فیلتر` [کلمه]  
`لیست فیلتر`  
`پاکسازی کلمات فیلتر`</blockquote>
"""

help_timesave = """
<blockquote>📸 ذخیره تایمی

عکس و ویدیوهای تایم‌دار رو خودکار سیو کن!

↲ دستور:
`ذخیره تایمی` روشن/خاموش</blockquote>
"""

help_texteffect = """
<blockquote>✨ حالت‌متن

پیامات رو با افکت‌های خفن بفرست!

↲ دستور:
`افکت متن` روشن/خاموش
`نوع افکت` [بولد، ایتالیک، زیرخط، اسپویلر، تدریجی، تایپ]</blockquote>
"""

help_autoseen = """
<blockquote>👁️ سین خودکار

هر پیامی که بیاد، خودکار سین بشه!

↲ دستور:
`سین خودکار` روشن/خاموش</blockquote>
"""

help_action = """
<blockquote>🎭 اکشن چت

وقتی تایپ می‌کنی، اکشن خفن نشون بده!

↲ دستور:
`اکشن` روشن/خاموش
`حالت اکشن`
[تایپ، ویس، ویدیو، عکس، سند، استیکر، بازی]</blockquote>
"""

help_tabchi = """
<blockquote>📢 تبچی پیشرفته

بنر هاتو راحت و بدون دردسر تبلغ کن با این قابلیت !

↲ دستور:
`تبچی` روشن/خاموش
`بنر` [ثانیه] [فور|کپی] + ریپلای  
`لیست بنر`  
`پاک کردن بنر` [کد]  
`پاکسازی کل تبچی`</blockquote>
"""

help_tools = """
<blockquote>🛠 ابزارهای جانبی

ابزارهای کاربردی و باحال سلف

↲ دستور:
`پینگ`  
`ایدی` + ریپلای  
`بیو`  
`تگ ادمین`  
`تگ اعضا`
`سیستم` - اطلاعات سیستم
`ماشین حساب` یا `e` [عبارت]</blockquote>
"""

help_info = """
<blockquote>👤 اطلاعات کاربر

این دستور فقط برای ادمین و مالک است

↲ دستور:
`تگ ادمین`  
`تگ اعضا`</blockquote>
"""

help_autoreply = """
<blockquote>🤖 پاسخ خودکار

هر کی بهت پیام بده، خودکار جواب بده!

↲ دستور:
`پاسخ خودکار` روشن/خاموش
`افزودن پاسخ` [سوال]:[پاسخ]  
`لیست پاسخ`  
`پاکسازی پاسخ`</blockquote>
"""

help_profile = """
<blockquote>👤 تنظیمات پروفایل

تغییر نام، بیو و عکس پروفایل اکانتت!

↲ دستور:
`تنظیم نام` [متن]  
`تنظیم نام خانوادگی` [متن]  
`تنظیم بیو` [متن]  
`تنظیم پروفایل` + ریپلای  
`حذف پروفایل`</blockquote>
"""

help_firstcomment = """
<blockquote>💬 کامنت اول

وقتی یک کانال پست گزاشت، کامنت اولش باش!

↲ دستور:
`کامنت اول` روشن/خاموش
`متن کامنت` [ریپلای]</blockquote>
"""

help_welcome = """
<blockquote>👋 خوشامدگویی

وقتی کسی به گروه اضافه میشه، خودکار خوش‌آمد بگو!

↲ دستور:
`خوشامد` روشن/خاموش
`تنظیم خوشامد` [متن]</blockquote>
"""

help_screenshot = """
<blockquote>📸 اسکرین‌شات از متن

هرچیز دلخواهت رو به عکس تبدیل کن!

↲ دستور:
`اسکرین` + ریپلای</blockquote>
"""

help_voice = """
<blockquote>🎤 تبدیل متن به ویس

متن فارسی رو به ویس تبدیل کن!

↲ دستور:
`ملیکا` [متن]  
`فرید` [متن]</blockquote>
"""

help_saat = """
<blockquote>🕒 ساعت پروفایل

ساعت رو با فونت‌های خفن کنار اسمت یا توی بیو نشون بده

↲ دستور:
`ساعت` روشن/خاموش
`ساعت بیو` روشن/خاموش
`فونت ساعت` [عدد]  
`بال` [عدد]  
`بال خاموش`  
`ثبت بیو` [متن]</blockquote>
"""

help_balsaat = """
<blockquote>🪽 بال ساعت

بال‌های خفن و فانتزی رو دور ساعت اسمت بذار

↲ دستور:
`بال` [عدد]  
`بال خاموش`

📜 لیست بال‌ها (نمونه):

1: ❰ ⩇⩇:⩇⩇ ❱
2: ✧ ⩇⩇:⩇⩇ ✧
... (ادامه لیست بال‌ها)
</blockquote>
"""

help_font_saat = """
<blockquote>😎 فونت ساعت

ساعتت رو با فونت خفن کن

↲ دستور:
`فونت ساعت` [عدد]

📜 لیست فونت‌ها (نمونه ۰۱:۲۳):

1: 𝟶𝟷:𝟸𝟹
2: ⓪①:②③
... (ادامه لیست فونت‌ها)
</blockquote>
"""

help_expire = """
<blockquote>⏰ دستور انقضا

شما با استفاده از این دستور میتونی انقضای باقی مونده سلفتون رو مشاهده کنی.
زمان بر اساس الماس شما محاسبه میشود (هر ساعت 2 الماس).

↲ دستور:
`انقضا`</blockquote>
"""

help_self = """
<blockquote>📊 دستور سلف

با استفاده از این دستور میتونی پینگ سلفت رو بررسی کنی.

↲ دستور:
`پینگ`</blockquote>
"""

help_restart_self = """
<blockquote>🔄 دستور ریست سلف

شما با این دستور سلف خودتون رو یک دور ریست (خاموش و روشن) میکنید.

↲ دستور:
`ریست`</blockquote>
"""

help_card = """
<blockquote>💳 دستور تنظیم کارت

شما با استفاده از این دستور میتونی کارت بانکی خودت رو تنظیم کنی.

↲ دستور:
`کارت` [ریپلای]
`تنظیم کارت` [شماره 16 رقمی] [نام]</blockquote>
"""

help_tag = """
<blockquote>🏷️ دستور تگ

شما با استفاده از این دستور میتونی تمامی ممبر هارو با یه متن تگ بکنی.

↲ دستور:
`تگ اعضا` [ریپلای]
`تگ ادمین` [ریپلای]</blockquote>
"""

help_proxy = """
<blockquote>🔗 دستور پروکسی

شما با استفاده از این دستور میتونی پروکسی رایگان دریافت کنی.

↲ دستور:
`پروکسی`</blockquote>
"""

help_filter_words = """
<blockquote>🚫 دستور فیلتر کردن متن

با این دستور ها میتونید کلمه هارو برای پیویتون فیلتر کنید و در صورتی که ارسال بکنند حذف میکنه.

↲ دستور:
`فیلتر کلمه` [کلمه]
`حذف فیلتر` [کلمه]
`لیست فیلتر`
`پاکسازی کلمات فیلتر`</blockquote>
"""

help_auto_response = """
<blockquote>🤖 دستور کنترل پاسخ خودکار

در این دستور میتونید کلمه/جمله تنظیم کنید که اگر پیوی اون رو ارسال کنن پاسخ میده و برای گروه اگر روی شما ریپلای بزنن پاسخ میده.

↲ دستور:
`افزودن پاسخ` [کلمه]:[پاسخ]
`لیست پاسخ`
`پاکسازی پاسخ`</blockquote>
"""

help_name = """
<blockquote>📛 دستور تنظیم نام

شما با استفاده از این دستور میتونی نام اول اکانت تلگرامت رو تغییر بدی.

↲ دستور:
`تنظیم نام` [متن]</blockquote>
"""

help_lastname = """
<blockquote>👤 دستور تنظیم نام خانوادگی

شما با استفاده از این دستور میتونی نام خانوادگی اکانت تلگرامت رو تغییر بدی.

↲ دستور:
`تنظیم نام خانوادگی` [متن]</blockquote>
"""

help_bio = """
<blockquote>📝 دستور تنظیم بیو

شما با استفاده از این دستور میتونی بیوگرافی اکانت تلگرامت رو تغییر بدی.

↲ دستور:
`ثبت بیو` [متن]</blockquote>
"""

help_profile_pic = """
<blockquote>🖼️ دستور عکس پروفایل

شما با استفاده از این دستور میتونی عکس پروفایل اکانتت رو تنظیم کنی.

↲ دستور:
`تنظیم پروفایل` [ریپلای]</blockquote>
"""

help_delete_profile = """
<blockquote>🗑️ دستور حذف پروفایل

شما با استفاده از این دستور میتونی عکس پروفایل اکانتت رو حذف کنی.

↲ دستور:
`حذف پروفایل`</blockquote>
"""

help_time_bio = """
<blockquote>🕒 دستور تایم بیو

در دست آپدیت هستش.</blockquote>
"""

help_silence = """
<blockquote>🔇 دستور سکوت

شما با استفاده از این دستور میتونی کاربر رو در گروه سکوت کنی.

↲ دستور:
`سکوت` [ریپلای/یوزرنیم]</blockquote>
"""

help_unsilence = """
<blockquote>🔊 دستور حذف سکوت

شما با استفاده از این دستور میتونی سکوت کاربر رو در گروه حذف کنی.

↲ دستور:
`حذف سکوت` [ریپلای/یوزرنیم]</blockquote>
"""

help_clear_silence = """
<blockquote>🧹 دستور پاکسازی سکوت

شما با استفاده از این دستور میتونی لیست کاربران سکوت شده رو پاکسازی کنی و لیست سکوت رو ببینی.

↲ دستور:
`لیست سکوت`
`پاکسازی لیست سکوت`</blockquote>
"""

help_block = """
<blockquote>🚫 دستور بلاک

شما با استفاده از این دستور میتونی کاربر رو بلاک کنی.

↲ دستور:
`بلاک` [ریپلای/یوزرنیم]</blockquote>
"""

help_unblock = """
<blockquote>✅ دستور آنبلاک

شما با استفاده از این دستور میتونی کاربر رو آنبلاک کنی.

↲ دستور:
`انبلاک` [ریپلای/یوزرنیم]</blockquote>
"""

help_enemy = """
<blockquote>👿 دستور دشمن

شما با استفاده از این دستور میتونی کاربر رو به لیست دشمنان اضافه کنی.

↲ دستور:
`تنظیم دشمن` [ریپلای]
`حذف دشمن` [ریپلای]
`لیست دشمن`
`پاکسازی لیست دشمن`</blockquote>
"""

help_friend = """
<blockquote>💖 دستور دوست

شما با استفاده از این دستور میتونی کاربر رو به لیست دوستان اضافه کنی.

↲ دستور:
`تنظیم دوست` [ریپلای]
`حذف دوست` [ریپلای]
`لیست دوست`
`پاکسازی لیست دوست`</blockquote>
"""

help_secretary_main = """
<blockquote>👩‍💼 دستور منشی

شما با استفاده از این دستور میتونی منشی برای پاسخگویی خودکار تنظیم کنی.

↲ دستور:
`منشی` روشن/خاموش
`متن منشی` [متن]
`تایم منشی` [عدد]</blockquote>
"""

help_tag_alert = """
<blockquote>🔔 دستور هشدار تگ

شما با استفاده از این دستور میتونی هشدار تگ شدن رو فعال کنی.

↲ دستور:
`هشدار تگ` روشن/خاموش</blockquote>
"""

help_offline = """
<blockquote>⏸️ دستور آفلاین

شما با استفاده از این دستور میتونی سلفت رو در حالت آفلاین قرار بدی.

↲ دستور:
`آفلاین` روشن/خاموش</blockquote>
"""

help_create_channel = """
<blockquote>📢 دستور ساخت کانال

شما با استفاده از این دستور میتونی کانال جدید بسازی.

↲ دستور:
`ساخت کانال` [نام]</blockquote>
"""

help_create_group = """
<blockquote>👥 دستور ساخت گروه

شما با استفاده از این دستور میتونی گروه جدید بسازی.

↲ دستور:
`ساخت گروه` [نام]</blockquote>
"""

help_create_supergroup = """
<blockquote>🌟 دستور ساخت سوپرگروه

شما با استفاده از این دستور میتونی سوپرگروه جدید بسازی.

↲ دستور:
`ساخت سوپر گروه` [نام]</blockquote>
"""

help_spam_main = """
<blockquote>💥 دستور اسپم

شما با استفاده از این دستور میتونی پیام اسپم ارسال کنی.
مثال: `اسپم 2 سلام`

↲ دستور:
`اسپم` [تعداد] [متن]</blockquote>
"""

help_welcome_main = """
<blockquote>🎉 دستور خوش آمدگویی

شما با استفاده از این دستور میتونی پیام خوش آمدگویی تنظیم کنی.

↲ دستور:
`خوشامد` روشن/خاموش
`متن خوشامد` [متن][ریپلای]</blockquote>
"""

help_first_comment = """
<blockquote>💬 دستور کامنت اول

شما با استفاده از این دستور میتونی کامنت اول رو تنظیم کنی.

↲ دستور:
`کامنت اول` روشن/خاموش
`متن کامنت` [ریپلای]</blockquote>
"""

help_ban = """
<blockquote>🚷 دستور بن

شما با استفاده از این دستور میتونی کاربر رو بن کنی.

↲ دستور:
`بن` [ریپلای/یوزرنیم]</blockquote>
"""

help_unban = """
<blockquote>✅ دستور آنبن

شما با استفاده از این دستور میتونی کاربر رو آنبن کنی.

↲ دستور:
`انبن` [ریپلای/یوزرنیم]</blockquote>
"""

help_set_silence = """
<blockquote>🔇 دستور تنظیم سکوت

شما با استفاده از این دستور میتونی سکوت کاربر رو تنظیم کنی.

↲ دستور:
`سکوت` [ریپلای]
`حذف سکوت` [ریپلای]
`لیست سکوت`
`پاکسازی لیست سکوت`</blockquote>
"""

help_set_group_pic = """
<blockquote>🖼️ دستور تنظیم پروفایل گروه

شما با استفاده از این دستور میتونی پروفایل گروه رو تنظیم کنی.

↲ دستور:
`تنظیم عکس گروه` [ریپلای]</blockquote>
"""

help_set_group_name = """
<blockquote>📛 دستور تنظیم نام گروه

شما با استفاده از این دستور میتونی نام گروه رو تغییر بدی.

↲ دستور:
`تنظیم نام گروه` [متن]</blockquote>
"""

help_set_group_bio = """
<blockquote>📝 دستور تنظیم بیو گروه

شما با استفاده از این دستور میتونی بیو گروه رو تغییر بدی.

↲ دستور:
`تنظیم بیو گروه` [متن]</blockquote>
"""

help_set_group_username = """
<blockquote>🔗 دستور تنظیم یوزرنیم گروه

شما با استفاده از این دستور میتونی یوزرنیم گروه رو تنظیم کنی.

↲ دستور:
`تنظیم یوزرنیم گروه` [یوزرنیم]</blockquote>
"""

help_pin = """
<blockquote>📌 دستور پین

شما با استفاده از این دستور میتونی پیام رو پین کنی.

↲ دستور:
`پین` [ریپلای]</blockquote>
"""

help_unpin_all = """
<blockquote>🧹 دستور حذف همه پین

شما با استفاده از این دستور میتونی همه پیام های پین شده رو حذف کنی.

↲ دستور:
`حذف پین همه`</blockquote>
"""

help_unpin = """
<blockquote>❌ دستور حذف پین

شما با استفاده از این دستور میتونی پیام پین شده رو حذف کنی.

↲ دستور:
`حذف پین` [ریپلای]</blockquote>
"""

help_delete_main = """
<blockquote>🗑️ دستور حذف

شما با استفاده از این دستور میتونی پیام ها رو حذف کنی.

↲ دستور:
`حذف` [تعداد/ریپلای]</blockquote>
"""

help_tag_admin = """
<blockquote>👨‍💼 دستور تگ ادمین

شما با استفاده از این دستور میتونی ادمین ها رو تگ کنی.

↲ دستور:
`تگ ادمین` [ریپلای]</blockquote>
"""

help_tag_members = """
<blockquote>👤 دستور تگ اعضا

شما با استفاده از این دستور میتونی کاربر ها رو تگ کنی.

↲ دستور:
`تگ اعضا` [ریپلای]</blockquote>
"""

help_extract_file = """
<blockquote>📦 دستور استخراج فایل

شما با استفاده از این دستور میتونی فایل رو از حالت فشرده خارج کنی.

↲ دستور:
`استخراج فایل` [ریپلای]</blockquote>
"""

help_car_price = """
<blockquote>🚗 دستور قیمت ماشین

شما با استفاده از این دستور میتونی قیمت ماشین رو چک کنی.

↲ دستور:
`قیمت ماشین` [نام ماشین]</blockquote>
"""

help_rename_file = """
<blockquote>📝 دستور تغییر نام فایل

شما با استفاده از این دستور میتونی نام فایل رو تغییر بدی.

↲ دستور:
`تغییر نام فایل` [اسم جدید] [ریپلای]</blockquote>
"""

help_number_checker = """
<blockquote>📞 دستور چکر شماره

این بخش درحال آپدیت میباشد.</blockquote>
"""

help_text_screenshot = """
<blockquote>📸 دستور اسکرین شات متن

شما با استفاده از این دستور میتونی از متن اسکرین شات بگیری.

↲ دستور:
`.q` [ریپلای]</blockquote>
"""

help_custom_screenshot = """
<blockquote>🖼️ دستور اسکرین شات دلخواه

شما با استفاده از این دستور میتونی از متن دلخواه اسکرین شات بگیری.

↲ دستور:
`.qq` [متن]</blockquote>
"""

help_cricket = """
<blockquote>🏏 دستور نتایج کریکت

شما با استفاده از این دستور میتونی نتایج کریکت رو ببینی.

↲ دستور:
`کریکت`</blockquote>
"""

help_weather = """
<blockquote>🌤️ دستور وضعیت هوا

شما با استفاده از این دستور میتونی وضعیت هوا رو چک کنی.

↲ دستور:
`وضعیت هوا` [نام شهر]</blockquote>
"""

help_azan = """
<blockquote>🕌 دستور اذان

شما با استفاده از این دستور میتونی زمان اذان رو ببینی.

↲ دستور:
`اذان` [نام شهر]</blockquote>
"""

help_currency = """
<blockquote>💰 دستور قیمت ارز

شما با استفاده از این دستور میتونی قیمت ارز رو ببینی.

↲ دستور:
`نرخ ارز`</blockquote>
"""

help_calculator = """
<blockquote>🧮 دستور ماشین حساب

شما با استفاده از این دستور میتونی محاسبات ریاضی انجام بدی.

↲ دستور:
`e` [عبارت ریاضی]
`محاسبه` [عبارت ریاضی]</blockquote>
"""

help_get_ip = """
<blockquote>🌐 دستور دریافت آیپی

شما با استفاده از این دستور میتونی آیپی سایت رو دریافت کنی.

↲ دستور:
`آیپی` [دامنه]</blockquote>
"""

help_ip_info = """
<blockquote>🔍 دستور اطلاعات آیپی

شما با استفاده از این دستور میتونی اطلاعات آیپی رو ببینی.

↲ دستور:
`اطلاعات آیپی` [آی‌پی]</blockquote>
"""

help_site_ping = """
<blockquote>📡 دستور پینگ سایت

شما با استفاده از این دستور میتونی پینگ سایت رو چک کنی.

↲ دستور:
`پینگ` [دامنه]</blockquote>
"""

help_site_screenshot = """
<blockquote>🖥️ دستور اسکرین شات سایت

شما با استفاده از این دستور میتونی از سایت اسکرین شات بگیری.

↲ دستور:
`اسکرین شات سایت` [دامنه]</blockquote>
"""

help_account_date = """
<blockquote>📅 دستور تاریخ ساخت اکانت

شما با استفاده از این دستور میتونی تاریخ ساخت اکانت رو ببینی.

↲ دستور:
`تاریخ ساخت` [ریپلای]</blockquote>
"""

help_copy_profile = """
<blockquote>👤 دستور کپی پروفایل

شما با استفاده از این دستور میتونی پروفایل کاربر رو کپی کنی.

↲ دستور:
`کلون` [آی‌دی] [ریپلای]</blockquote>
"""

help_limit_status = """
<blockquote>🚫 دستور وضعیت محدودیت

شما با استفاده از این دستور میتونی وضعیت محدودیت اکانت رو ببینی.

↲ دستور:
`وضعیت محدودیت`</blockquote>
"""

help_country_info = """
<blockquote>🌍 دستور اطلاعات کشور

شما با استفاده از این دستور میتونی اطلاعات کشور رو ببینی.

↲ دستور:
`اطلاعات کشور` [نام]</blockquote>
"""

help_translate_fa = """
<blockquote>🇮🇷 دستور ترجمه به فارسی

شما با استفاده از این دستور میتونی متن رو به فارسی ترجمه کنی.

↲ دستور:
`ترجمه به فارسی` [متن]</blockquote>
"""

help_translate_en = """
<blockquote>🇺🇸 دستور ترجمه به انگلیسی

شما با استفاده از این دستور میتونی متن رو به انگلیسی ترجمه کنی.

↲ دستور:
`ترجمه انگلیسی` [متن]</blockquote>
"""

help_download_movie = """
<blockquote>🎬 دستور دانلود فیلم

شما با استفاده از این دستور میتونی فیلم دانلود کنی.

↲ دستور:
`دانلود فیلم` [متن]</blockquote>
"""

help_download_anime = """
<blockquote>🎌 دستور دانلود انیمه

شما با استفاده از این دستور میتونی انیمه دانلود کنی.

↲ دستور:
`دانلود انیمه` [متن]</blockquote>
"""

help_create_password = """
<blockquote>🔐 دستور ساخت پسورد

شما با استفاده از این دستور میتونی پسورد بسازی.

↲ دستور:
`ساخت پسورد` [تعداد]</blockquote>
"""

help_morse_to_text = """
<blockquote>🔤 دستور تبدیل مورس به متن

شما با استفاده از این دستور میتونی مورس رو به متن تبدیل کنی.

↲ دستور:
`مورس به متن` [کد]</blockquote>
"""

help_text_to_morse = """
<blockquote>🔡 دستور تبدیل متن به مورس

شما با استفاده از این دستور میتونی متن رو به مورس تبدیل کنی.

↲ دستور:
`متن به مورس` [متن]</blockquote>
"""

help_get_date = """
<blockquote>📅 دستور دریافت تاریخ

شما با استفاده از این دستور میتونی تاریخ رو ببینی.

↲ دستور:
`تاریخ`</blockquote>
"""

help_account_info = """
<blockquote>👤 دستور دریافت اطلاعات اکانت

شما با استفاده از این دستور میتونی اطلاعات اکانت رو ببینی.

↲ دستور:
`ایدی` [ریپلای]</blockquote>
"""

help_message_info = """
<blockquote>💬 دستور دریافت اطلاعات پیام

شما با استفاده از این دستور میتونی اطلاعات پیام رو ببینی.

↲ دستور:
`اطلاعات پیام` [ریپلای]</blockquote>
"""

help_mention_user = """
<blockquote>👥 دستور منشن کاربر

شما با استفاده از این دستور میتونی کاربر رو منشن کنی.

↲ دستور:
`منشن` [آی‌دی] [ریپلای]</blockquote>
"""

help_national_code = """
<blockquote>🆔 دستور بررسی کد ملی

شما با استفاده از این دستور میتونی کد ملی رو بررسی کنی.

↲ دستور:
`بررسی کد ملی` [شماره]</blockquote>
"""

help_card_inquiry = """
<blockquote>💳 دستور استعلام کارت بانکی

شما با استفاده از این دستور میتونی کارت بانکی رو استعلام کنی.

↲ دستور:
`استعلام کارت` [شماره]</blockquote>
"""

help_instagram_download = """
<blockquote>📸 دستور دانلود اینستا 

شما با استفاده از این دستور میتونی پست اینستاگرامی را دانلود کنی.

↲ دستور:
`دانلود اینستا` [لینک]</blockquote>
"""

help_extract_text = """
<blockquote>📖 دستور استخراج متن از عکس

شما با استفاده از این دستور میتونی متن رو از عکس استخراج کنی.

↲ دستور:
`استخراج متن` [ریپلای]</blockquote>
"""

help_dice = """
<blockquote>🎲 دستور تاس

شما با استفاده از این دستور میتونی تاس بازی کنی.

↲ دستور:
`تاس` [عدد]</blockquote>
"""

help_basketball = """
<blockquote>🏀 دستور بسکتبال

شما با استفاده از این دستور میتونی بسکتبال بازی کنی.

↲ دستور:
`بسکتبال`</blockquote>
"""

help_bowling = """
<blockquote>🎳 دستور بولینگ

شما با استفاده از این دستور میتونی بولینگ بازی کنی.

↲ دستور:
`بولینگ`</blockquote>
"""

help_dart = """
<blockquote>🎯 دستور دارت

شما با استفاده از این دستور میتونی دارت بازی کنی.

↲ دستور:
`دارت`</blockquote>
"""

help_football = """
<blockquote>⚽ دستور فوتبال

شما با استفاده از این دستور میتونی فوتبال بازی کنی.

↲ دستور:
`فوتبال 1`</blockquote>
"""

help_faal = """
<blockquote>📜 دستور فال حافظ

شما با استفاده از این دستور میتونی فال حافظ بگیری.

↲ دستور:
`فال`</blockquote>
"""

help_random_game1 = """
<blockquote>🎲 دستور بازی رندوم 1

شما با استفاده از این دستور میتونی بازی رندوم انجام بدی.

↲ دستور:
`بازی رندوم 1`</blockquote>
"""

help_random_game2 = """
<blockquote>🎲 دستور بازی رندوم 2

شما با استفاده از این دستور میتونی بازی رندوم انجام بدی.

↲ دستور:
`بازی رندوم 2`</blockquote>
"""

help_random_game3 = """
<blockquote>🎲 دستور بازی رندوم 3

شما با استفاده از این دستور میتونی بازی رندوم انجام بدی.

↲ دستور:
`بازی رندوم 3`</blockquote>
"""

help_other_fun = """
<blockquote>🎪 دستور سایر سرگرمی

شما با استفاده از این دستور میتونی از سرگرمی های مختلف استفاده کنی.

↲ دستور:
`جق`</blockquote>
"""

help_photo = """
<blockquote>🔄 دستور عکس

شما با استفاده از این دستور میتونی عکس رو به استیکر تبدیل کنی.

↲ دستور:
`تبدیل عکس به استیکر` [ریپلای روی عکس]</blockquote>
"""

help_sticker = """
<blockquote>🔄 دستور استیکر

شما با استفاده از این دستور میتونی استیکر رو به عکس تبدیل کنی.

↲ دستور:
`تبدیل استیکر به عکس` [ریپلای روی استیکر]</blockquote>
"""

help_gif = """
<blockquote>🎞️ دستور گیف

شما با استفاده از این دستور میتونی ویدئو رو به گیف تبدیل کنی.

↲ دستور:
`فیلم به گیف` [ریپلای روی ویدئو]</blockquote>
"""

help_create_gif = """
<blockquote>🎞️ دستور ساخت گیف

شما با استفاده از این دستور میتونی گیف بسازی.

↲ دستور:
`ساخت گیف` [متن]</blockquote>
"""

help_create_sticker = """
<blockquote>🎞️ دستور ساخت استیکر

شما با استفاده از این دستور میتونی استیکر بسازی.

↲ دستور:
`ساخت استیکر` [متن]</blockquote>
"""

help_tabchi_main = """
<blockquote>🖼️ دستور تنظیم بنر

شما با استفاده از این دستور میتونی تبچی روشن کنید و تبلیغات کنید.

↲ دستور:
`تبچی` روشن/خاموش
`بنر` [ثانیه] [فور | کپی] + ریپلای 
`لیست بنر`
`پاک کردن بنر`
`پاکسازی کل تبچی`</blockquote>
"""

help_ai = """
<blockquote>🧠 دستور هوش مصنوعی

شما با استفاده از این دستور میتونی با هوش مصنوعی چت کنی.

↲ دستور:
`هوش مصنوعی` [متن]</blockquote>
"""

help_private_download = """
<blockquote>🔗 دستور دانلود پرایوت 

شما با استفاده از این دستور میتونی پست هایی که غیرقابل کپی هستند را ذخیره کنی.

↲ دستور:
`دانلود` [لینک]</blockquote>
"""

help_instagram_dl = """
<blockquote>📸 دستور دانلود اینستا 

شما با استفاده از این دستور میتونی پست اینستاگرامی را دانلود کنی.

↲ دستور:
`دانلود اینستا` [لینک]</blockquote>
"""

help_secretary_text = """
<blockquote>📝 دستور متن منشی

با این دستور اون متنی که میخوای منشی هر ۴۵ ثانیه برای هر شخص بفرسته رو میتونی تنظیم بکنی.

↲ دستور:
`متن منشی`</blockquote>
"""

help_secretary_self = """
<blockquote>🤖 دستور فعالسازی منشی

با این دستور میتونی منشی رو روشن بکنی.

↲ دستور:
`منشی` روشن/خاموش</blockquote>
"""

help_secretary_time = """
<blockquote>⏱️ دستور تنظیم تایم منشی

با این دستور میتونی تایم منشی رو تنظیم بکنی.

↲ دستور:
`تایم منشی` (عدد به ثانیه)</blockquote>
"""

help_text_mode = """
<blockquote>📝 دستور حالت متن

شما با استفاده از این دستور میتونی حالت متن رو تنظیم کنی.

↲ دستور:
`افکت متن` روشن/خاموش
`نوع افکت` [نام حالت]
(بولد، ایتالیک، زیرخط، اسپویلر، تدریجی، تایپ)</blockquote>
"""

help_action_mode = """
<blockquote>🎭 دستور حالت اکشن

شما با استفاده از این دستور میتونی حالت اکشن رو تنظیم کنی.

↲ دستور:
`حالت اکشن` روشن/خاموش
`نوع اکشن` [نام حالت]
(تایپ، ویس، ویدیو، عکس، سند، استیکر، بازی)</blockquote>
"""

help_reaction = """
<blockquote>👍 دستور ری‌اکشن

شما با استفاده از این دستور میتونی ری‌اکشن تنظیم کنی.

↲ دستور:
`ریکت` روشن/خاموش
`ریکت` [ایموجی] + ریپلای
`حذف ریکت` [ریپلای]
`لیست ریکت`
`پاکسازی لیست ریکت`</blockquote>
"""

help_time_save = """
<blockquote>💾 دستور ذخیره مدیا تایمدار

شما با استفاده از این دستور میتونی ذخیره تایمدار رو فعال کنی.

↲ دستور:
`ذخیره تایمی` روشن/خاموش</blockquote>
"""

help_anti_login = """
<blockquote>🔐 دستور فعال‌سازی ضدلاگین

شما با استفاده از این دستور میتونی از ورودهای ناشناس جلوگیری کنی.

↲ دستور:
`ضد لاگین` روشن/خاموش</blockquote>
"""

help_auto_seen = """
<blockquote>👁️ دستور فعال‌سازی سین‌خودکار

شما با استفاده از این دستور میتونی هرکی پیام داد بهت سریع ربات سین بزنه.

↲ دستور:
`سین خودکار` روشن/خاموش</blockquote>
"""

help_clear_enemy = """
<blockquote>🗑️ دستور پاکسازی کل دشمن

با استفاده از این دستور شما میتونی کل دشمن های تنظیم شده رو پاکسازی کنی.

↲ دستور:
`پاکسازی لیست دشمن`</blockquote>
"""

help_list_enemy = """
<blockquote>📋 دستور لیست دشمن

با استفاده از این دستور شما میتونی لیست کل دشمن های تنظیم شده رو نگاه کنی.

↲ دستور:
`لیست دشمن`</blockquote>
"""

help_list_friend = """
<blockquote>📋 دستور لیست دوست

با استفاده از این دستور شما میتونی لیست کل دوست های تنظیم شده رو نگاه کنی.

↲ دستور:
`لیست دوست`</blockquote>
"""

help_add_friend = """
<blockquote>❤️ دستور دوست

شما با استفاده از این دستور میتونی کاربر رو به لیست دوستان اضافه کنی.

↲ دستور:
`تنظیم دوست` [ریپلای]
`حذف دوست` [ریپلای]</blockquote>
"""

help_clear_friend = """
<blockquote>🧹 دستور پاکسازی کل دوست

با استفاده از این دستور شما میتونی کل دوست های تنظیم شده رو پاکسازی کنی.

↲ دستور:
`پاکسازی لیست دوست`</blockquote>
"""

help_system = """
<blockquote>💻 اطلاعات سیستم

اطلاعات کامل سیستم و وضعیت سرور رو نمایش میده.

↲ دستور:
`سیستم`</blockquote>
"""

help_gold = """
<blockquote>🪙 قیمت طلا و سکه

قیمت لحظه‌ای طلا و سکه رو نمایش میده.

↲ دستور:
`قیمت طلا`</blockquote>
"""

# ==================== پنل اصلی ====================
openpanelbot = InlineKeyboardMarkup([
    [Button.inline("پنل 📱", b'open_panel')]
])

# ==================== دکمه‌های منوی 1 ====================
def get_menu1_buttons():
    return [
        [Button.inline("❲ مدیریت ❳", b'modiriat'),
         Button.inline("❲ تنظیمات ❳", b'tanzimat')],
        [Button.inline("❲ پروفایل ❳", b'profile_main')],
        [Button.inline("❲ سراسری ❳", b'sarasari'),
         Button.inline("❲ ابزار ❳", b'tools_main')],
        [Button.inline("❲ سرگرمی ❳", b'entertainment')],
        [Button.inline("❲ تغییر ❳", b'taghvir'),
         Button.inline("❲ تبچی ❳", b'tabchi_main')],
        [Button.inline("→", b'menu2'),
         Button.inline("1/3", b'pageinfo'),
         Button.inline("←", b'menu3')],
        [Button.inline("✖️ بستن پنل", b'closepanel')]
    ]

# ==================== دکمه‌های منوی 2 ====================
def get_menu2_buttons():
    return [
        [Button.inline("❲ هوش مصنوعی ❳", b'ai'),
         Button.inline("❲ دانلودر ❳", b'downloader')],
        [Button.inline("❲ ساعت پروفایل ❳", b'saat')],
        [Button.inline("❲ حالت متن ❳", b'text_mode'),
         Button.inline("❲ منشی ❳", b'secretary_main')],
        [Button.inline("❲ اطلاعات ❳", b'info_main')],
        [Button.inline("❲ دشمن ❳", b'enemy_main'),
         Button.inline("❲ دوست ❳", b'friend_main')],
        [Button.inline("❲ حالت اکشن ❳", b'action_mode')],
        [Button.inline("→", b'menu3'),
         Button.inline("2/3", b'pageinfo'),
         Button.inline("←", b'menu1')],
        [Button.inline("✖️ بستن پنل", b'closepanel')]
    ]

# ==================== دکمه‌های منوی 3 ====================
def get_menu3_buttons():
    return [
        [Button.inline("❲ ذخیره تایمدار ❳", b'time_save'),
         Button.inline("❲ سین خودکار ❳", b'auto_seen')],
        [Button.inline("❲ ضدلاگین ❳", b'anti_login')],
        [Button.inline("❲ تقلب ❳", b'game'),
         Button.inline("❲ ذخیره تایمدار ❳", b'time_save2')],
        [Button.inline("❲ ری‌اکشن ❳", b'reaction')],
        [Button.inline("→", b'menu1'),
         Button.inline("3/3", b'pageinfo'),
         Button.inline("←", b'menu2')],
        [Button.inline("✖️ بستن پنل", b'closepanel')]
    ]

# ==================== دکمه‌های زیرمنوها ====================
# ... (ادامه دکمه‌ها مثل helper2)

# ==================== هندلر اینلاین ====================
@event.on(events.InlineQuery)
async def inline_handler(e):
    user_id = e.query.user_id
    
    if e.query.query == 'LANG_SELECTION':
        authorized_users.add(user_id)
        builder = e.builder
        await e.answer([builder.article('Language', text='Please select your language:\nلطفاً زبان خود را انتخاب کنید:', buttons=lang_mark)])
    else:
        if user_id not in authorized_users:
            await e.answer([])
            return
            
        lang = get_lang(user_id)
        builder = e.builder
        await e.answer([builder.article('bot', text=get_text('welcome', lang), buttons=main_menu_buttons(user_id, lang))])

# ==================== هندلر کالبک ====================
@event.on(events.CallbackQuery)
async def callback_handler(m):
    data = m.data.decode()
    user_id = m.sender_id

    if user_id not in authorized_users:
        await m.answer(get_text('unauthorized', 'fa'), alert=True)
        return

    lang = get_lang(user_id)

    if data.startswith('setlang-'):
        lang = data.split('-')[1]
        update_SQLITE(user_id, 'lang', lang)
        await m.edit(text=get_text('welcome', lang), buttons=main_menu_buttons(user_id, lang))
        return

    # ============ منوهای اصلی ============
    if data == 'menu1':
        await m.edit(text="👑 دستورات سلف علی! بخش راهنمای دستورات سلف ✔️", buttons=get_menu1_buttons())
    
    elif data == 'menu2':
        await m.edit(text="👑 دستورات سلف علی! بخش راهنمای دستورات سلف ✔️", buttons=get_menu2_buttons())
    
    elif data == 'menu3':
        await m.edit(text="👑 دستورات سلف علی! بخش راهنمای دستورات سلف ✔️", buttons=get_menu3_buttons())
    
    # ============ تنظیمات ============
    elif data == 'tanzimat':
        await m.edit(text="‹ بخش ﹝ تنظیمات ﹞ ›\n\nلطفاً دستور مورد نظر را انتخاب کنید:", buttons=get_tanzimat_buttons())
    
    # ... (ادامه کالبک‌ها برای همه بخش‌ها)
    
    elif data == 'closepanel':
        await m.edit("**● پنل بسته شد ●**")
    
    elif data == 'pageinfo':
        await m.answer("شما در این صفحه هستید", alert=False)
    
    elif data == 'open_panel':
        await m.edit(text="👑 دستورات سلف علی! بخش راهنمای دستورات سلف ✔️", buttons=get_menu1_buttons())

# ==================== هندلر پیام‌های /start و /panel ====================
@event.on(events.NewMessage(pattern='/start'))
async def start_handler(e):
    user_id = e.sender_id
    await e.reply(f"سلام {e.sender.first_name} 👋\n\nبرای باز کردن پنل، روی دکمه زیر کلیک کنید:", buttons=openpanelbot)

@event.on(events.NewMessage(pattern='/panel'))
async def panel_handler(e):
    user_id = e.sender_id
    if user_id not in authorized_users:
        await e.reply("⛔ دسترسی غیر مجاز!")
        return
    await e.reply("برای باز کردن پنل مدیریت، روی دکمه زیر کلیک کنید:", buttons=openpanelbot)

# ==================== اجرا ====================
print("Helper bot is running...")
event.run_until_disconnected()