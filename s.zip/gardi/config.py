token = "8234050731:AAHXqmrzae9HbrICJxlbJbIHo1tDj3BzxuY"
api_id = 39900197
api_hash = "f2d6bcf2a1ce4bef29ddd415975d7021"
idbot = "@Helperhptlbot"